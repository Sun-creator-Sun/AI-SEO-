/** @type {import('next').NextConfig} */
const nextConfig = {
  // 图片优化配置
  images: {
    // 允许的图片域名
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.pexels.com',
        port: '',
        pathname: '/photos/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: '**',
        port: '',
        pathname: '/**',
      }
    ],
    // 最小缓存时间
    minimumCacheTTL: 60,
  },
  
  // 实验性功能
  experimental: {
    // 优化包大小
    optimizePackageImports: ['lucide-react'],
    // 服务器组件优化
    serverComponentsExternalPackages: [],
  },
  
  // 压缩配置
  compress: true,
  
  // 生产环境优化
  ...(process.env.NODE_ENV === 'production' && {
    // 启用SWC压缩
    swcMinify: true,
    // 输出分析
    output: 'standalone',
  }),
  
  // 环境变量
  env: {
    CUSTOM_KEY: process.env.CUSTOM_KEY || 'default-value',
  },
  
  // 重定向配置
  async redirects() {
    return []
  },
  
  // 重写配置
  async rewrites() {
    return []
  },
  
  // 头部配置
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig 
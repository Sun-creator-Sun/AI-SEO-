# 新工作流机制文档

## 概述

本文档描述了Vertu SEO应用中新增的多工作流机制，该机制允许用户同时进行多个文章创作任务，每个任务都有独立的会话状态。

## 核心功能

### 1. SessionId 管理

- **唯一标识**: 每个工作流会话都有唯一的sessionId
- **URL参数**: sessionId通过URL查询参数传递，格式为 `/?sessionId=abc123`
- **状态隔离**: 每个sessionId对应独立的localStorage存储空间

### 2. 新任务创建

- **新建文章按钮**: 在应用顶部导航栏添加了"新建文章"按钮
- **新标签页打开**: 点击按钮会在新标签页中打开全新的工作流
- **自动生成ID**: 使用自定义的generateSessionId函数生成唯一的sessionId

### 3. 首次访问处理

- **自动重定向**: 当用户直接访问根域名时，自动生成sessionId并重定向
- **无历史记录**: 使用`router.replace`避免在浏览器历史中留下重定向记录
- **加载状态**: 重定向期间显示友好的加载动画

## 技术实现

### 1. ID生成函数

```typescript
// lib/utils.ts
export function generateSessionId(): string {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 15);
  return `${timestamp}-${randomStr}`;
}
```

### 2. URL处理

```typescript
// app/page.tsx
useEffect(() => {
  if (!searchParams.has('sessionId')) {
    const newSessionId = generateSessionId()
    router.replace(`/?sessionId=${newSessionId}`)
  }
}, [searchParams, router])
```

### 3. 状态持久化

```typescript
// hooks/useAppState.ts
function getStorageKey(sessionId: string | null) {
  return sessionId ? `vertu-seo-session-${sessionId}` : null
}

function loadPersistedState(sessionId: string | null) {
  if (!sessionId) return null
  // ... 加载逻辑
}

function persistState(state: Record<string, unknown>, sessionId: string | null) {
  if (!sessionId) return
  // ... 保存逻辑
}
```

### 4. 新任务按钮

```typescript
// components/shared/AppLayout.tsx
const handleNewTask = () => {
  const newSessionId = generateSessionId()
  window.open(`/?sessionId=${newSessionId}`, '_blank')
}
```

## 使用场景

### 1. 多任务并行

用户可以同时进行多个不同的文章创作任务：
- 任务A：技术博客文章
- 任务B：营销文案
- 任务C：产品介绍

### 2. 任务切换

用户可以在不同的标签页之间切换，每个标签页保持独立的状态：
- 关键词设置
- 生成的内容
- 当前步骤
- 所有配置选项

### 3. 任务恢复

关闭浏览器后重新打开，每个任务的状态都会被完整恢复：
- 自动加载对应的sessionId
- 恢复所有已保存的状态
- 继续之前的工作流程

## 测试页面

### 访问地址

访问 `/test-new-workflow` 可以测试新工作流机制的功能。

### 测试功能

1. **当前会话信息**: 显示当前页面的sessionId和URL
2. **创建新工作流**: 测试新任务创建功能
3. **访问主页**: 测试首次访问处理
4. **会话管理**: 查看、删除所有保存的会话
5. **数据查看**: 查看每个会话的详细状态数据

## 存储结构

### localStorage键格式

```
vertu-seo-session-{sessionId}
```

### 存储内容

每个会话存储以下状态信息：
- `currentStep`: 当前工作流步骤
- `keyword`: 关键词
- `targetMarket`: 目标市场
- `targetLanguage`: 目标语言
- `blogIdeas`: 生成的博客想法
- `generatedTitles`: 生成的标题
- `generatedOutline`: 生成的大纲
- 其他所有相关状态...

## 优势

### 1. 用户体验

- **无干扰**: 新任务在新标签页打开，不影响当前工作
- **状态保持**: 每个任务的状态完全独立
- **快速切换**: 可以在多个任务间快速切换

### 2. 开发体验

- **模块化**: 每个会话独立管理
- **可扩展**: 易于添加更多会话管理功能
- **调试友好**: 可以查看每个会话的详细状态

### 3. 性能优化

- **按需加载**: 只加载当前会话的状态
- **内存效率**: 避免状态冲突和内存泄漏
- **缓存友好**: 每个会话有独立的缓存策略

## 注意事项

### 1. 浏览器限制

- localStorage有存储大小限制（通常5-10MB）
- 建议定期清理不需要的会话数据
- 考虑添加会话过期机制

### 2. 安全性

- sessionId是公开的URL参数
- 不要存储敏感信息
- 考虑添加会话验证机制

### 3. 兼容性

- 确保在所有支持的浏览器中正常工作
- 测试localStorage的可用性
- 提供降级方案

## 未来改进

### 1. 会话管理

- 添加会话列表页面
- 实现会话重命名功能
- 添加会话导出/导入功能

### 2. 数据同步

- 考虑添加云端同步
- 实现跨设备状态同步
- 添加协作功能

### 3. 性能优化

- 实现会话数据压缩
- 添加会话数据清理策略
- 优化大量会话时的性能

## 总结

新工作流机制为Vertu SEO应用提供了强大的多任务支持，用户可以同时进行多个文章创作任务，每个任务都有独立的状态管理。这个机制不仅提升了用户体验，也为应用的未来发展奠定了良好的基础。 
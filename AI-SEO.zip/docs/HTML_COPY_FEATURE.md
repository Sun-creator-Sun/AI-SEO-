# HTML复制功能优化

## 功能概述

为Vertu SEO应用优化了"复制全文"功能，现在支持两种格式的复制：
1. **Markdown格式** - 原始的Markdown文本
2. **WordPress HTML格式** - 包含完整HTML标签的内容，可直接粘贴到WordPress后台

## 主要改进

### 1. 双格式复制支持

#### 文章草稿页面
- **复制Markdown** - 复制原始Markdown格式内容
- **复制全文** - 复制WordPress友好的HTML格式内容

#### 历史记录页面
- **复制图标** - 复制Markdown格式内容
- **HTML按钮** - 复制WordPress HTML格式内容

### 2. HTML转换功能

创建了 `lib/html-converter.ts` 模块，提供以下功能：

#### 核心转换函数
- `convertMarkdownToWordPressHTML()` - 将Markdown转换为WordPress友好的HTML
- `generateWordPressHTMLDocument()` - 生成完整的WordPress HTML文档
- `generatePureHTML()` - 生成纯HTML（不包含WordPress特定类）

#### 支持的Markdown元素
- **标题** (H1, H2, H3) - 转换为 `<h1>`, `<h2>`, `<h3>` 标签
- **段落** - 转换为 `<p>` 标签
- **列表** - 无序列表和有序列表
- **强调** - 粗体和斜体文本
- **代码** - 行内代码和代码块
- **链接** - 自动添加 `target="_blank"` 和 `rel="noopener noreferrer"`
- **图片** - 添加WordPress图片类
- **引用** - 转换为 `<blockquote>` 标签
- **表格** - 完整的表格支持
- **分隔线** - 转换为 `<hr>` 标签

### 3. WordPress优化

#### WordPress特定类
- `wp-block-heading` - 标题块类
- `has-medium-font-size` - 段落字体大小类
- `wp-block-list` - 列表块类
- `wp-block-quote` - 引用块类
- `wp-block-code` - 代码块类
- `wp-block-table` - 表格块类
- `wp-block-button__link` - 链接按钮类
- `aligncenter size-full wp-image-1` - 图片对齐和大小类

#### 自动链接处理
- 自动检测并应用自定义锚文本链接
- 确保所有链接都是完整的URL
- 添加适当的安全属性

## 使用方法

### 1. 文章草稿页面
1. 生成文章后，在底部会看到两个按钮：
   - **复制Markdown** - 复制原始Markdown格式
   - **复制全文** - 复制WordPress HTML格式

2. 点击"复制全文"按钮，HTML内容会自动复制到剪贴板

3. 直接粘贴到WordPress后台的编辑器中使用

### 2. 历史记录页面
1. 打开历史记录侧边栏
2. 选择一篇文章
3. 点击眼睛图标查看文章内容
4. 使用复制按钮：
   - **复制图标** - 复制Markdown格式
   - **HTML按钮** - 复制WordPress HTML格式

### 3. 测试页面
访问 `/test-html-converter` 页面可以测试HTML转换功能：
- 输入Markdown内容
- 实时转换为HTML
- 预览转换结果
- 复制转换后的HTML

## 技术实现

### HTML转换算法
1. **内容清理** - 移除多余的换行符和空白
2. **锚文本处理** - 应用自定义链接替换
3. **正则表达式转换** - 使用正则表达式将Markdown转换为HTML
4. **列表包装** - 自动检测并包装列表项
5. **表格处理** - 解析Markdown表格并转换为HTML表格
6. **后处理** - 清理HTML并添加WordPress特定类

### 错误处理
- 转换失败时显示友好的错误提示
- 复制失败时提供手动复制的建议
- 输入验证确保内容格式正确

## 兼容性

### WordPress兼容性
- 支持WordPress 5.0+ 的Gutenberg编辑器
- 兼容经典编辑器
- 自动添加WordPress块编辑器类

### 浏览器兼容性
- 支持现代浏览器的剪贴板API
- 降级到手动复制模式
- 响应式设计适配不同屏幕尺寸

## 未来改进

1. **更多格式支持**
   - 支持导出为PDF
   - 支持导出为Word文档
   - 支持自定义CSS样式

2. **高级功能**
   - 批量导出多篇文章
   - 自定义HTML模板
   - SEO元数据自动生成

3. **用户体验优化**
   - 复制进度提示
   - 格式预览功能
   - 快捷键支持 
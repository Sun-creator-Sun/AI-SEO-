# TanStack Query 集成文档

## 概述

本项目已成功集成 TanStack Query (React Query) 来提供强大的 API 缓存策略。这个集成显著提升了应用性能，减少了不必要的 API 调用，并提供了更好的用户体验。

## 主要特性

### 1. 智能缓存策略
- **搜索查询**: 5分钟缓存时间，10分钟垃圾回收
- **搜索意图分析**: 10分钟缓存时间，20分钟垃圾回收  
- **博客创意生成**: 15分钟缓存时间，30分钟垃圾回收
- **标题生成**: 15分钟缓存时间，30分钟垃圾回收
- **大纲生成**: 20分钟缓存时间，40分钟垃圾回收
- **文章内容提取**: 30分钟缓存时间，1小时垃圾回收

### 2. 自动状态管理
- 自动处理加载状态 (`isLoading`)
- 自动处理错误状态 (`error`)
- 自动处理成功状态 (`isSuccess`)
- 支持后台数据刷新
- 智能重试机制

### 3. 开发工具支持
- 开发环境下自动显示 React Query DevTools
- 实时查看缓存状态和查询信息
- 支持手动清除和刷新缓存

## 文件结构

```
hooks/
├── useApiQueries.ts          # 所有API查询的TanStack Query hooks
├── useAppStateWithCache.ts   # 集成缓存的增强版应用状态hook
└── useAppState.ts           # 原始应用状态hook

components/
└── providers/
    └── QueryProvider.tsx    # TanStack Query 提供者组件

app/
├── layout.tsx               # 根布局，包含QueryProvider
└── test-cache/
    └── page.tsx            # 缓存测试页面
```

## 核心组件

### QueryProvider

```tsx
// components/providers/QueryProvider.tsx
export function QueryProvider({ children }: QueryProviderProps) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 5 * 60 * 1000,        // 5分钟缓存时间
            gcTime: 10 * 60 * 1000,          // 10分钟垃圾回收
            retry: 2,                        // 重试2次
            retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
            retryOnMount: true,
            refetchOnWindowFocus: false,     // 窗口聚焦时不重新获取
            refetchOnReconnect: true,        // 网络重连时重新获取
          },
          mutations: {
            retry: 1,
            retryDelay: 1000,
          },
        },
      })
  )

  return (
    <QueryClientProvider client={queryClient}>
      {children}
      {process.env.NODE_ENV === 'development' && (
        <ReactQueryDevtools initialIsOpen={false} />
      )}
    </QueryClientProvider>
  )
}
```

### API 查询 Hooks

```tsx
// hooks/useApiQueries.ts
export function useSearchKeyword(
  keyword: string,
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.search(keyword, targetMarket, targetLanguage, timeRange),
    queryFn: () => searchKeyword(keyword, targetMarket, targetLanguage, timeRange),
    enabled: enabled && !!keyword.trim(),
    staleTime: 5 * 60 * 1000, // 5分钟
    gcTime: 10 * 60 * 1000,   // 10分钟
  })
}
```

### 查询键管理

```tsx
// 查询键常量，确保缓存键的唯一性和一致性
export const queryKeys = {
  search: (keyword: string, market: string, language: string, timeRange: string) => 
    ['search', keyword, market, language, timeRange],
  blogIdeas: (keyword: string, market: string, language: string, timeRange: string, pageCount: number) => 
    ['blogIdeas', keyword, market, language, timeRange, pageCount],
  // ... 更多查询键
}
```

## 使用方法

### 1. 基本使用

```tsx
import { useAppStateWithCache } from '@/hooks/useAppStateWithCache'

function MyComponent() {
  const {
    searchQuery,
    blogIdeasQuery,
    clearAllCache,
    refreshSearchData
  } = useAppStateWithCache()

  // 使用查询状态
  if (searchQuery.isLoading) {
    return <div>搜索中...</div>
  }

  if (searchQuery.error) {
    return <div>搜索失败: {searchQuery.error.message}</div>
  }

  return (
    <div>
      <h2>搜索结果 ({searchQuery.data?.length || 0})</h2>
      {searchQuery.data?.map(result => (
        <div key={result.url}>{result.title}</div>
      ))}
      
      <button onClick={clearAllCache}>清除缓存</button>
      <button onClick={refreshSearchData}>刷新数据</button>
    </div>
  )
}
```

### 2. 条件查询

```tsx
// 只在特定条件下启用查询
const blogIdeasQuery = useGenerateBlogIdeas(
  keyword,
  searchResults,
  targetMarket,
  targetLanguage,
  timeRange,
  pageCount,
  searchIntent,
  currentStep === AppStep.SEARCHING && !!searchResults.length // 条件启用
)
```

### 3. 缓存管理

```tsx
const { clearAllCache, refreshSearchData, refreshTitleData } = useClearCache()

// 清除所有缓存
clearAllCache()

// 刷新特定类型的缓存
refreshSearchData()
refreshTitleData()
refreshOutlineData()
```

## 缓存策略详解

### 1. 缓存时间配置

| 查询类型 | 缓存时间 | 垃圾回收时间 | 说明 |
|---------|---------|-------------|------|
| 搜索查询 | 5分钟 | 10分钟 | 搜索结果相对稳定 |
| 搜索意图 | 10分钟 | 20分钟 | 用户意图变化较慢 |
| 博客创意 | 15分钟 | 30分钟 | 创意生成成本较高 |
| 标题生成 | 15分钟 | 30分钟 | 标题生成需要AI处理 |
| 大纲生成 | 20分钟 | 40分钟 | 大纲生成最耗时 |
| 内容提取 | 30分钟 | 1小时 | 网页内容相对稳定 |

### 2. 查询键设计原则

- **唯一性**: 确保相同参数的查询使用相同的键
- **层次性**: 使用数组结构便于部分失效
- **可读性**: 键名清晰表达查询含义
- **性能**: 避免过长的键名影响性能

```tsx
// 好的查询键设计
['search', keyword, market, language, timeRange]
['blogIdeas', keyword, market, language, timeRange, pageCount]

// 避免的设计
['search', JSON.stringify({keyword, market, language, timeRange})] // 过长
['search'] // 不够唯一
```

### 3. 启用条件

```tsx
// 智能启用查询，避免不必要的API调用
enabled: enabled && !!keyword.trim() && searchResults.length > 0
```

## 性能优化

### 1. 减少不必要的查询

```tsx
// 只在需要时启用查询
const searchQuery = useSearchKeyword(
  keyword,
  targetMarket,
  targetLanguage,
  timeRange,
  currentStep === AppStep.SEARCHING // 只在搜索步骤启用
)
```

### 2. 依赖查询

```tsx
// 后续查询依赖前面查询的结果
const blogIdeasQuery = useGenerateBlogIdeas(
  keyword,
  searchQuery.data || [], // 依赖搜索结果
  // ... 其他参数
  !!searchQuery.data // 只在有搜索结果时启用
)
```

### 3. 后台刷新

```tsx
// 配置后台刷新，保持数据新鲜度
{
  staleTime: 5 * 60 * 1000, // 5分钟内认为数据新鲜
  gcTime: 10 * 60 * 1000,   // 10分钟后从内存清除
}
```

## 错误处理

### 1. 自动重试

```tsx
{
  retry: 2, // 失败时重试2次
  retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000), // 指数退避
}
```

### 2. 错误状态处理

```tsx
if (query.error) {
  return (
    <div className="error">
      <p>查询失败: {query.error.message}</p>
      <button onClick={() => query.refetch()}>重试</button>
    </div>
  )
}
```

## 开发工具

### React Query DevTools

在开发环境下，React Query DevTools 会自动显示在页面右下角，提供：

- 实时查询状态查看
- 缓存数据浏览
- 手动清除缓存
- 查询时间线
- 性能分析

### 测试页面

访问 `/test-cache` 页面可以：

- 查看所有查询的实时状态
- 测试缓存功能
- 手动清除和刷新缓存
- 了解缓存配置

## 最佳实践

### 1. 查询键管理

```tsx
// 集中管理查询键，便于维护
export const queryKeys = {
  search: (keyword: string, market: string, language: string, timeRange: string) => 
    ['search', keyword, market, language, timeRange],
  // ...
}
```

### 2. 类型安全

```tsx
// 使用TypeScript确保类型安全
const searchQuery = useSearchKeyword(
  keyword: string,
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  enabled: boolean = true
): UseQueryResult<SearchResult[], Error>
```

### 3. 错误边界

```tsx
// 在组件中处理查询错误
if (searchQuery.error) {
  return <ErrorFallback error={searchQuery.error} />
}
```

### 4. 加载状态

```tsx
// 提供良好的加载体验
if (searchQuery.isLoading) {
  return <LoadingSpinner />
}
```

## 监控和分析

### 1. 缓存命中率

通过 React Query DevTools 可以查看：

- 缓存命中次数
- 查询执行时间
- 内存使用情况

### 2. 性能指标

- API 调用次数减少
- 页面响应时间提升
- 用户体验改善

## 故障排除

### 1. 缓存不生效

检查：
- 查询键是否一致
- 启用条件是否正确
- 缓存时间配置

### 2. 数据不更新

检查：
- `staleTime` 配置
- 手动刷新方法
- 依赖查询的启用条件

### 3. 内存泄漏

检查：
- `gcTime` 配置
- 查询数量是否过多
- 组件卸载时是否正确清理

## 总结

TanStack Query 的集成为项目带来了显著的性能提升：

1. **减少API调用**: 相同参数的查询直接从缓存返回
2. **提升用户体验**: 更快的响应时间和更好的加载状态
3. **降低成本**: 减少不必要的API请求
4. **简化开发**: 自动处理加载、错误和缓存状态
5. **类型安全**: 完整的TypeScript支持

这个集成为项目的可扩展性和性能奠定了坚实的基础。 
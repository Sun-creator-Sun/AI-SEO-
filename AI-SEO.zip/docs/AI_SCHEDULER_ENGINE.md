# 智能AI调度引擎 (V2.0) 实现文档

## 概述

智能AI调度引擎是一个全自动的AI模型选择和故障转移系统，旨在提升用户体验和系统可靠性。它移除了前端AI模型选择器，由后端自动处理模型选择和故障转移，对用户完全透明。

## 核心特性

### 🚀 自动故障转移
- **智能重试**: 当一个AI模型失败时，自动尝试下一个模型
- **零干预**: 用户无需手动选择模型，系统自动处理
- **高可靠性**: 通过多模型备份确保生成任务的高成功率

### 🔄 模型优先级管理
- **成本优化**: 按照API成本和性能排序，优先使用性价比高的模型
- **性能平衡**: 在成本、速度和质量之间找到最佳平衡点
- **动态调整**: 支持运行时调整模型优先级

### 📊 详细日志记录
- **尝试日志**: 记录每次模型调用尝试
- **成功统计**: 跟踪成功率和响应时间
- **错误诊断**: 详细的错误信息和故障分析

## 技术架构

### 文件结构
```
lib/
├── ai-scheduler.ts         # 核心调度引擎
├── types.ts               # 类型定义
└── content-generation.ts  # 集成调度引擎

app/api/
├── gemini-generate/       # Gemini API端点
├── openai-generate/       # OpenAI API端点  
├── claude-generate/       # Claude API端点
└── deepseek-generate/     # DeepSeek API端点

app/test-ai-scheduler/     # 测试页面
```

### 核心组件

#### 1. AI模型配置 (`AIModelConfig`)
```typescript
interface AIModelConfig {
  name: AIModel;           // 模型名称
  priority: number;        // 优先级 (1=最高)
  maxTokens?: number;      // 最大令牌数
  temperature?: number;    // 温度参数
}
```

#### 2. 调用结果 (`AICallResult`)
```typescript
interface AICallResult {
  success: boolean;        // 是否成功
  content?: string;        // 生成内容
  model: AIModel;         // 使用的模型
  error?: string;         // 错误信息
  responseTime?: number;   // 响应时间
}
```

#### 3. 智能调度函数 (`generateWithFailover`)
主要功能：
- 按优先级遍历所有可用模型
- 记录每次尝试的详细日志
- 处理成功/失败情况
- 返回第一个成功的结果

## 模型优先级配置

### 默认优先级顺序
1. **gemini-1.5-flash** (首选) - 成本低，速度快
2. **gpt-4o** (备用) - 质量高，成本中等
3. **claude-3-sonnet** (备用) - 质量优秀，成本较高
4. **deepseek-chat** (最后备用) - 国产模型，备用选择

### 配置参数
```typescript
const AI_MODEL_PRIORITY: AIModelConfig[] = [
  {
    name: 'gemini-1.5-flash',
    priority: 1,
    maxTokens: 8192,
    temperature: 0.7
  },
  // ... 其他模型配置
]
```

## API端点实现

### 1. Gemini API (`/api/gemini-generate`)
- 使用现有的Gemini直接API调用
- 支持代理配置
- 完整的错误处理

### 2. OpenAI API (`/api/openai-generate`)
- 标准的OpenAI Chat Completions API
- 支持gpt-4o等模型
- 需要配置`OPENAI_API_KEY`环境变量

### 3. Claude API (`/api/claude-generate`)
- Anthropic Messages API
- 支持claude-3-sonnet等模型
- 需要配置`CLAUDE_API_KEY`或`ANTHROPIC_API_KEY`环境变量

### 4. DeepSeek API (`/api/deepseek-generate`)
- DeepSeek Chat Completions API
- 兼容OpenAI格式
- 需要配置`DEEPSEEK_API_KEY`环境变量

## 集成方式

### 1. 内容生成集成
在 `lib/content-generation.ts` 中：
```typescript
import { generateWithFailover } from './ai-scheduler'

// 替换原有的API调用
const generatedContent = await generateWithFailover(prompt, { temperature: 0.7 })
```

### 2. 前端调用
前端无需任何更改，所有AI模型选择逻辑都在后端处理：
```typescript
// 前端只需要发送prompt，无需指定模型
const response = await fetch('/api/generate-content', {
  method: 'POST',
  body: JSON.stringify({ prompt })
})
```

## 日志示例

### 成功调用日志
```
INFO: Starting AI generation with failover for prompt length: 156
INFO: Attempting to use model: gemini-1.5-flash...
SUCCESS: Content generated using gemini-1.5-flash (1250ms)
SUCCESS: Generation completed with gemini-1.5-flash after 1 attempts (total: 1250ms)
```

### 故障转移日志
```
INFO: Starting AI generation with failover for prompt length: 156
INFO: Attempting to use model: gemini-1.5-flash...
WARN: Model gemini-1.5-flash failed: API rate limit exceeded (800ms). Trying next...
INFO: Attempting to use model: gpt-4o...
SUCCESS: Content generated using gpt-4o (2100ms)
SUCCESS: Generation completed with gpt-4o after 2 attempts (total: 2900ms)
```

### 完全失败日志
```
ERROR: All AI models failed after 4 attempts (total: 8500ms)
ERROR: Failure summary: gemini-1.5-flash: API rate limit; gpt-4o: Insufficient quota; claude-3-sonnet: Network timeout; deepseek-chat: Invalid API key
```

## 测试功能

### 测试页面
访问 `/test-ai-scheduler` 可以：
- 查看当前模型优先级配置
- 测试单个模型的可用性
- 测试智能调度功能
- 查看实时日志和结果

### 可用性测试
```typescript
// 测试单个模型
const result = await testModelAvailability('gpt-4o')

// 获取优先级配置
const configs = getModelPriorityConfig()
```

## 环境变量配置

### 必需配置
```env
# Gemini (已配置)
GENERATIVE_AI_KEY=your_gemini_api_key

# OpenAI (可选)
OPENAI_API_KEY=your_openai_api_key

# Claude (可选)  
CLAUDE_API_KEY=your_claude_api_key
# 或
ANTHROPIC_API_KEY=your_anthropic_api_key

# DeepSeek (可选)
DEEPSEEK_API_KEY=your_deepseek_api_key
```

### 配置说明
- 只需配置Gemini密钥即可基本使用
- 配置更多API密钥可以提高故障转移的可靠性
- 未配置的模型会在调用时跳过

## 优势总结

### 用户体验
- ✅ **零决策负担**: 用户无需选择AI模型
- ✅ **透明操作**: 故障转移对用户完全透明
- ✅ **高成功率**: 多模型备份确保任务完成

### 系统可靠性
- ✅ **自动恢复**: API故障时自动切换
- ✅ **成本优化**: 优先使用性价比高的模型
- ✅ **监控友好**: 详细的日志记录便于监控

### 开发维护
- ✅ **模块化设计**: 易于添加新的AI模型
- ✅ **配置灵活**: 支持动态调整优先级
- ✅ **测试完备**: 包含完整的测试功能

## 未来扩展

### 短期计划
- [ ] 添加模型性能监控
- [ ] 实现基于历史表现的智能路由
- [ ] 支持并行调用提高速度

### 长期计划
- [ ] 机器学习优化模型选择
- [ ] 支持流式响应
- [ ] 集成更多AI提供商

## 故障排除

### 常见问题
1. **所有模型都失败**: 检查网络连接和API密钥配置
2. **特定模型不可用**: 检查对应的环境变量配置
3. **响应时间过长**: 调整模型优先级或超时设置

### 调试方法
1. 查看服务器控制台日志
2. 使用测试页面验证模型可用性
3. 检查API密钥的有效性和配额 
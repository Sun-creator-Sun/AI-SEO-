# 大纲生成问题诊断与修复

## 问题描述

用户报告文章大纲生成失败，需要诊断并修复相关API调用问题。

## 诊断步骤

### 1. 找到负责生成大纲的API调用函数

通过代码分析，找到了以下关键文件：

- **主要API函数**: `lib/outline-generation.ts` 中的 `generateBlogOutline` 函数
- **调用入口**: `hooks/useAppState.ts` 中的 `generateOutline` 和 `generateFinalOutline` 函数
- **UI组件**: `components/pages/OutlineGeneratingPage.tsx`

### 2. 添加详细的日志记录

在 `generateBlogOutline` 函数中添加了全面的日志记录：

#### 输入参数检查
```typescript
console.log('=== 开始生成博客大纲 ===');
console.log('📝 输入参数检查:');
console.log('- keyword:', keyword);
console.log('- selectedTitle:', selectedTitle);
console.log('- synthesisReport长度:', synthesisReport?.length || 0);
// ... 其他参数
```

#### API调用日志
```typescript
console.log('📤 发送给Google Generative AI API的完整prompt:');
console.log('prompt长度:', prompt.length);
console.log('prompt内容:');
console.log(prompt);

console.log('🚀 开始调用Google Generative AI API...');
```

#### 响应处理日志
```typescript
console.log('📥 收到Google Generative AI API的原始响应:');
console.log('响应长度:', text.length);
console.log('响应内容:');
console.log(text);
```

#### 错误处理日志
```typescript
console.error('❌ 生成博客大纲失败:');
console.error('错误类型:', error instanceof Error ? error.constructor.name : typeof error);
console.error('错误消息:', error instanceof Error ? error.message : String(error));
console.error('错误堆栈:', error instanceof Error ? error.stack : '无堆栈信息');
```

### 3. 增强错误处理

#### 参数验证
```typescript
// 验证关键参数
if (!keyword || !keyword.trim()) {
  throw new Error('主关键词不能为空');
}
if (!selectedTitle || !selectedTitle.trim()) {
  throw new Error('选中的标题不能为空');
}
if (!wordCount || !wordCount.trim()) {
  throw new Error('目标字数不能为空');
}
```

#### 错误类型识别
```typescript
// 检查是否是API密钥或网络相关错误
const errorMessage = error instanceof Error ? error.message : String(error);
if (errorMessage.includes('API_KEY') || errorMessage.includes('key')) {
  console.error('🔑 可能是API密钥配置问题');
} else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
  console.error('🌐 可能是网络连接问题');
} else if (errorMessage.includes('quota') || errorMessage.includes('limit')) {
  console.error('📊 可能是API配额限制问题');
}
```

### 4. 改进UI错误处理

#### 创建Alert组件
创建了 `components/ui/alert.tsx` 用于显示错误信息：

```typescript
const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    className={cn(alertVariants({ variant }), className)}
    {...props}
  />
))
```

#### 更新大纲生成页面
在 `OutlineGeneratingPage.tsx` 中添加了错误显示和重试功能：

```typescript
interface OutlineGeneratingPageProps {
  outlineGenerationStep: OutlineGenerationSubStep
  outlineGenerationProgress: number
  error?: string | null
  onRetry?: () => void
}
```

#### 错误提示信息
```typescript
const getErrorSuggestion = () => {
  if (!error) return '';
  
  if (error.includes('API_KEY') || error.includes('key')) {
    return '请检查API密钥配置是否正确，或联系管理员确认API密钥状态。';
  } else if (error.includes('network') || error.includes('fetch')) {
    return '请检查网络连接是否正常，或稍后重试。';
  } else if (error.includes('quota') || error.includes('limit')) {
    return 'API配额已用完，请稍后重试或联系管理员。';
  } else if (error.includes('JSON') || error.includes('解析')) {
    return 'AI响应格式异常，请重试。如果问题持续存在，请联系技术支持。';
  } else {
    return '请重试或返回上一步检查输入信息。如果问题持续存在，请联系技术支持。';
  }
};
```

### 5. 状态管理改进

#### 添加错误状态
在 `useAppState` 中添加了错误状态管理：

```typescript
const [outlineGenerationError, setOutlineGenerationError] = useState<string | null>(null)
```

#### 错误处理流程
```typescript
const generateOutline = async () => {
  // 清除之前的错误状态
  setOutlineGenerationError(null);
  
  try {
    // ... 大纲生成逻辑
  } catch (error) {
    console.error('大纲生成失败:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    setOutlineGenerationError(errorMessage);
    // 保持在当前页面，显示错误信息
  }
};
```

## 测试工具

### 创建诊断测试页面
创建了 `app/test-outline-debug/page.tsx` 用于独立测试大纲生成功能：

- 提供测试参数
- 捕获详细日志
- 显示生成结果
- 错误信息展示

## 使用方法

### 1. 查看详细日志
在浏览器开发者工具的控制台中查看详细的API调用日志，包括：
- 输入参数
- 发送的prompt
- API响应
- 错误信息

### 2. 使用测试页面
访问 `/test-outline-debug` 页面进行独立测试：
- 点击"开始测试大纲生成"按钮
- 查看实时日志输出
- 分析生成结果或错误信息

### 3. 错误处理
当大纲生成失败时：
- 页面会显示具体的错误信息
- 提供针对性的解决建议
- 提供重试按钮

## 常见问题诊断

### API密钥问题
- 检查环境变量 `GENERATIVE_AI_KEY` 是否正确设置
- 确认API密钥是否有效且未过期
- 检查API密钥权限

### 网络连接问题
- 检查网络连接是否正常
- 确认是否可以访问Google API
- 检查防火墙设置

### API配额限制
- 检查API使用量是否超限
- 确认账户状态是否正常
- 考虑升级API配额

### JSON解析错误
- 检查AI响应格式是否正确
- 确认prompt是否过于复杂
- 尝试简化请求参数

## 后续优化建议

1. **添加重试机制**: 实现自动重试失败的API调用
2. **缓存机制**: 缓存成功的大纲生成结果
3. **监控告警**: 添加API调用失败监控
4. **用户反馈**: 收集用户反馈以进一步优化错误处理
5. **性能优化**: 优化prompt长度和复杂度

## 总结

通过添加详细的日志记录、增强错误处理和改进UI反馈，我们成功实现了对大纲生成问题的全面诊断能力。现在可以：

- 实时监控API调用过程
- 快速定位问题根源
- 为用户提供清晰的错误信息
- 提供针对性的解决建议
- 支持一键重试功能

这些改进大大提升了系统的可维护性和用户体验。 
# 网页抓取API文档

## 概述

网页抓取功能现在通过Next.js API路由实现，使用Jina.ai的API服务来抓取网页内容。

## API端点

### POST /api/scrape

批量抓取多个网页的内容。

#### 请求格式

```json
{
  "urls": ["https://example.com", "https://another-site.com"],
  "maxConcurrency": 3
}
```

#### 参数说明

- `urls` (必需): 要抓取的URL数组，最多支持10个URL
- `maxConcurrency` (可选): 最大并发数，默认为3

#### 响应格式

成功响应：
```json
{
  "success": true,
  "results": [
    {
      "url": "https://example.com",
      "content": "抓取到的网页内容..."
    },
    {
      "url": "https://failed-site.com", 
      "error": "抓取失败原因"
    }
  ],
  "summary": {
    "total": 2,
    "successful": 1,
    "failed": 1
  }
}
```

错误响应：
```json
{
  "error": "错误信息",
  "details": "详细错误描述"
}
```

## 使用示例

### curl示例

```bash
curl -X POST http://localhost:3000/api/scrape \
  -H "Content-Type: application/json" \
  -d '{
    "urls": ["https://example.com"],
    "maxConcurrency": 1
  }'
```

### JavaScript示例

```javascript
const response = await fetch('/api/scrape', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    urls: ['https://example.com'],
    maxConcurrency: 3
  })
});

const result = await response.json();
console.log(result);
```

## 技术细节

- **抓取服务**: 使用Jina.ai的r.jina.ai API
- **并发控制**: 通过maxConcurrency参数控制同时抓取的数量
- **错误处理**: 单个URL失败不会影响其他URL的抓取
- **限制**: 单次请求最多处理10个URL
- **超时**: 依赖Jina.ai API的超时设置

## 注意事项

1. 确保目标网站允许抓取
2. 遵守robots.txt和相关法律法规
3. 合理设置并发数，避免对目标网站造成过大压力
4. API包含2秒的批次间延迟以防止过于频繁的请求 
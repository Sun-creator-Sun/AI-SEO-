# 知识库搜索功能说明

## 🔍 功能概述

为知识库列表添加了智能搜索功能，支持根据知识库名称和描述进行模糊搜索，提升用户查找目标知识库的效率。

## ✨ 主要特性

### 1. 模糊搜索
- **多字段搜索**: 同时搜索知识库名称和描述内容
- **大小写不敏感**: 自动转换为小写进行匹配
- **实时搜索**: 输入即时显示搜索结果
- **关键词高亮**: 匹配的关键词以黄色背景高亮显示

### 2. 搜索界面
- **搜索图标**: 左侧搜索放大镜图标
- **清除按钮**: 有搜索内容时右侧显示清除×按钮
- **结果统计**: 显示匹配数量和总数
- **使用提示**: 显示快捷键操作提示

### 3. 交互体验
- **快捷键支持**: 按ESC键快速清除搜索
- **状态保护**: 搜索时自动处理选中状态
- **无结果提示**: 友好的无搜索结果界面
- **一键重置**: 支持快速回到完整列表

## 🎯 使用方法

### 基本搜索
1. 在知识库列表顶部找到搜索框
2. 输入要搜索的关键词
3. 实时查看过滤后的结果列表
4. 关键词会在名称和描述中高亮显示

### 快捷操作
- **清除搜索**: 点击搜索框右侧的×按钮
- **键盘快捷键**: 按ESC键快速清除搜索
- **快速重置**: 无搜索结果时点击"清除搜索"按钮

### 搜索范围
搜索功能会在以下字段中查找匹配内容：
- ✅ 知识库名称 (`name`)
- ✅ 知识库描述 (`intro`)

## 🚀 技术实现

### 核心搜索函数
```tsx
/**
 * 模糊搜索知识库
 */
const filterKnowledgeBases = (keyword: string, knowledgeBaseList: KnowledgeBase[]) => {
  if (!keyword.trim()) {
    return knowledgeBaseList
  }

  const lowerKeyword = keyword.toLowerCase()
  return knowledgeBaseList.filter(kb => 
    kb.name.toLowerCase().includes(lowerKeyword) ||
    (kb.intro && kb.intro.toLowerCase().includes(lowerKeyword))
  )
}
```

### 关键词高亮
```tsx
/**
 * 高亮搜索关键词
 */
const highlightSearchKeyword = (text: string, keyword: string) => {
  const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
  const parts = text.split(regex)
  
  return parts.map((part, index) => 
    regex.test(part) ? (
      <mark className="bg-yellow-200 text-yellow-900 px-0.5 rounded">
        {part}
      </mark>
    ) : part
  )
}
```

### 状态管理
```tsx
// 搜索相关状态
const [searchKeyword, setSearchKeyword] = useState('')
const [filteredKnowledgeBases, setFilteredKnowledgeBases] = useState<KnowledgeBase[]>([])

// 处理搜索变化
const handleSearchChange = (value: string) => {
  setSearchKeyword(value)
  const filtered = filterKnowledgeBases(value, knowledgeBases)
  setFilteredKnowledgeBases(filtered)
  
  // 智能处理选中状态
  if (selectedKnowledgeBase && !filtered.find(kb => kb._id === selectedKnowledgeBase._id)) {
    setSelectedKnowledgeBase(null)
    setKnowledgeBaseDetail(null)
  }
}
```

## 🎨 UI 设计特色

### 搜索框设计
- **现代化外观**: 圆角边框，柔和阴影
- **图标指引**: 左侧搜索图标，右侧清除按钮
- **状态反馈**: 聚焦时蓝色边框高亮
- **占位符文本**: 清晰的使用指引

### 搜索结果展示
- **实时统计**: 显示"找到 X 个相关知识库 / 共 Y 个"
- **高亮显示**: 匹配关键词黄色背景标记
- **无结果页面**: 友好的提示和操作引导

### 交互细节
- **即时反馈**: 输入立即更新结果
- **状态保护**: 选中项不在搜索结果时自动清除
- **优雅降级**: 无搜索结果时的友好提示

## 📱 响应式支持

- **移动端适配**: 搜索框在小屏幕上保持良好可用性
- **触摸友好**: 按钮大小适合触摸操作
- **键盘支持**: 完整的键盘导航和快捷键

## 🔄 状态同步

### 搜索状态管理
1. **初始化**: 知识库加载完成后初始化过滤列表
2. **搜索过滤**: 实时更新过滤结果
3. **选中保护**: 自动处理不在搜索结果中的选中项
4. **状态重置**: 弹窗关闭时完整重置所有搜索状态

### 数据一致性
- 原始数据不变更，仅对显示列表进行过滤
- 搜索状态与知识库数据完全同步
- 支持搜索过程中的数据更新

## 💡 使用场景

### 适用情况
- ✅ 知识库数量较多时快速定位
- ✅ 根据功能描述查找相关知识库
- ✅ 按名称模糊查找知识库
- ✅ 浏览和筛选知识库列表

### 搜索技巧
- 使用知识库名称的关键词搜索
- 根据功能描述的关键词搜索
- 支持部分匹配，无需完整输入
- 支持中英文混合搜索

这个搜索功能大大提升了知识库选择的效率，特别是在知识库数量较多的企业环境中，用户可以快速找到需要的目标知识库。 
"use client"

import { Button } from '@/components/ui/button'
import StepIndicator, { AppStep } from './StepIndicator'
import { motion, AnimatePresence } from 'framer-motion'
import { ArticleHistorySheet } from '@/components/ui/article-history-sheet'
import { Plus } from 'lucide-react'
import { nanoid } from 'nanoid'

interface AppLayoutProps {
  currentStep: AppStep
  children: React.ReactNode
  bottomButtons?: React.ReactNode
  onDirectGenerate?: () => void
}

/**
 * 应用布局组件
 */
export default function AppLayout({ currentStep, children, bottomButtons, onDirectGenerate }: AppLayoutProps) {
  // 实现新任务点击逻辑
  const handleNewTask = () => {
    const newSessionId = nanoid()
    // window.open() 会在新标签页打开链接
    window.open(`/?sessionId=${newSessionId}`, '_blank')
  }

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* 固定头部 */}
      <header className="flex-shrink-0 bg-white border-b z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">关键词驱动的智能写作</h1>
              <span className="ml-2 text-sm text-gray-500">博客内容（多个单）</span>
            </div>
            <div className="flex items-center space-x-4">
              {/* 新建文章按钮 */}
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleNewTask}
                className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
              >
                <Plus className="w-4 h-4 mr-1" />
                新建文章
              </Button>
              <Button variant="ghost" size="sm">小提示</Button>
              <ArticleHistorySheet>
                <Button variant="ghost" size="sm">
                  历史记录
                </Button>
              </ArticleHistorySheet>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={onDirectGenerate}
                disabled={!onDirectGenerate}
              >
                直接生成文章
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* 步骤指示器 - 在文章草稿页面时隐藏 */}
      {currentStep !== AppStep.ARTICLE_DRAFT && (
        <div className="flex-shrink-0">
          <StepIndicator currentStep={currentStep} />
        </div>
      )}

      {/* 主内容区域 */}
      <main className="flex-1 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ 
                duration: 0.3,
                ease: "easeInOut"
              }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* 固定底部按钮区域 */}
      {bottomButtons && (
        <div className="flex-shrink-0 bg-white border-t px-4 sm:px-6 lg:px-8 py-4">
          <div className="max-w-7xl mx-auto flex justify-center items-center">
            {bottomButtons}
          </div>
        </div>
      )}
    </div>
  )
} 
"use client"

import { CheckCircle } from 'lucide-react'
import { motion } from 'framer-motion'

/**
 * 应用状态枚举
 */
enum AppStep {
  INPUT = 'input',
  SEARCHING = 'searching', 
  IDEAS = 'ideas',
  TITLE_GENERATING = 'title_generating',
  TITLES = 'titles',
  OUTLINE_GENERATING = 'outline_generating',
  OUTLINE = 'outline',
  SETTINGS = 'settings',
  ARTICLE_GENERATING = 'article_generating',
  ARTICLE_DRAFT = 'article_draft'
}

interface StepIndicatorProps {
  currentStep: AppStep
}

/**
 * 步骤指示器组件
 */
export default function StepIndicator({ currentStep }: StepIndicatorProps) {
  /**
   * 判断步骤是否已完成
   */
  const isStepCompleted = (step: AppStep): boolean => {
    const stepOrder = [AppStep.INPUT, AppStep.IDEAS, AppStep.TITLES, AppStep.OUTLINE, AppStep.SETTINGS, AppStep.ARTICLE_DRAFT];
    const currentIndex = stepOrder.indexOf(currentStep);
    const stepIndex = stepOrder.indexOf(step);
    
    // 如果当前步骤是搜索或生成中的状态，则基于对应的主要步骤判断
    if (currentStep === AppStep.SEARCHING) {
      return stepIndex < stepOrder.indexOf(AppStep.IDEAS);
    }
    if (currentStep === AppStep.TITLE_GENERATING) {
      return stepIndex < stepOrder.indexOf(AppStep.TITLES);
    }
    if (currentStep === AppStep.OUTLINE_GENERATING) {
      return stepIndex < stepOrder.indexOf(AppStep.OUTLINE);
    }
    if (currentStep === AppStep.ARTICLE_GENERATING) {
      return stepIndex < stepOrder.indexOf(AppStep.ARTICLE_DRAFT);
    }
    
    return stepIndex < currentIndex;
  };

  /**
   * 判断步骤是否为当前步骤
   */
  const isCurrentStep = (step: AppStep): boolean => {
    if (step === AppStep.INPUT) {
      return currentStep === AppStep.INPUT;
    }
    if (step === AppStep.IDEAS) {
      return currentStep === AppStep.IDEAS || currentStep === AppStep.SEARCHING;
    }
    if (step === AppStep.TITLES) {
      return currentStep === AppStep.TITLES || currentStep === AppStep.TITLE_GENERATING;
    }
    if (step === AppStep.OUTLINE) {
      return currentStep === AppStep.OUTLINE || currentStep === AppStep.OUTLINE_GENERATING;
    }
    if (step === AppStep.SETTINGS) {
      return currentStep === AppStep.SETTINGS || currentStep === AppStep.ARTICLE_GENERATING;
    }
    if (step === AppStep.ARTICLE_DRAFT) {
      return currentStep === AppStep.ARTICLE_DRAFT;
    }
    return false;
  };

  const steps = [
    { step: AppStep.INPUT, label: '输入关键词', number: '1' },
    { step: AppStep.IDEAS, label: '发现创意', number: '2' },
    { step: AppStep.TITLES, label: '推荐标题', number: '3' },
    { step: AppStep.OUTLINE, label: '推荐大纲', number: '4' },
    { step: AppStep.SETTINGS, label: '最终配置', number: '5' },
    { step: AppStep.ARTICLE_DRAFT, label: '文章草稿', number: '6' }
  ]

  return (
    <div className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-center">
          <div className="flex items-center space-x-6">
            {steps.map((stepInfo, index) => (
              <div key={stepInfo.step} className="flex items-center">
                <motion.div 
                  className="flex items-center"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <motion.div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      isCurrentStep(stepInfo.step) ? 'bg-blue-600 text-white' : 
                      isStepCompleted(stepInfo.step) ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'
                    }`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {isStepCompleted(stepInfo.step) ? <CheckCircle className="w-4 h-4" /> : stepInfo.number}
                  </motion.div>
                  <span className={`ml-2 text-sm font-medium ${
                    isCurrentStep(stepInfo.step) || isStepCompleted(stepInfo.step) ? 'text-gray-900' : 'text-gray-500'
                  }`}>{stepInfo.label}</span>
                </motion.div>
                {index < steps.length - 1 && (
                  <motion.div 
                    className="w-12 h-px bg-gray-300 ml-6"
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ delay: index * 0.1 + 0.2, duration: 0.3 }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export { AppStep } 
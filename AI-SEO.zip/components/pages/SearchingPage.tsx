"use client"

import { CheckCircle, Search, Brain } from 'lucide-react'

interface SearchingPageProps {
  progress: number
  pageCount: string
}

/**
 * 搜索进度页面组件
 */
export default function SearchingPage({ progress, pageCount }: SearchingPageProps) {
  // 计算当前步骤
  const isFirstStep = progress < 50
  
  // 计算搜索结果数量
  const totalResults = parseInt(pageCount) * 10

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="mb-8">
        {/* 步骤指示器 */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center">
            {/* 第一步 */}
            <div className="flex flex-col items-center">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                progress >= 50 ? 'bg-green-500 text-white' : 'bg-blue-500 text-white'
              }`}>
                {progress >= 50 ? <CheckCircle className="w-6 h-6" /> : <Search className="w-6 h-6" />}
              </div>
              <span className={`text-sm font-medium ${
                isFirstStep ? 'text-blue-600' : progress >= 50 ? 'text-green-600' : 'text-gray-400'
              }`}>
                搜索内容
              </span>
            </div>
            
            {/* 连接线 */}
            <div className={`w-16 h-1 mx-4 ${
              progress >= 50 ? 'bg-green-500' : 'bg-gray-200'
            }`}></div>
            
            {/* 第二步 */}
            <div className="flex flex-col items-center">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                progress >= 100 ? 'bg-green-500 text-white' : 
                progress >= 50 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-400'
              }`}>
                {progress >= 100 ? <CheckCircle className="w-6 h-6" /> : <Brain className="w-6 h-6" />}
              </div>
              <span className={`text-sm font-medium ${
                progress >= 50 ? (progress >= 100 ? 'text-green-600' : 'text-blue-600') : 'text-gray-400'
              }`}>
                生成灵感
              </span>
            </div>
          </div>
        </div>

        {/* 当前步骤内容 */}
        {isFirstStep ? (
          // 第一步：搜索内容
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              通过关键词在 Google 中搜索前{totalResults}结果作为博客灵感参考
            </h2>
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              正在搜索相关内容
            </h3>
            <p className="text-gray-600">
              大约需要 1-5 秒。
            </p>
          </div>
        ) : (
          // 第二步：分析意图和生成灵感
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              分析用户搜索意图并生成博客灵感
            </h2>
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              努力寻找灵感
            </h3>
            <p className="text-gray-600">
              大约需要 20-40 秒。
            </p>
          </div>
        )}
      </div>
    </div>
  )
} 
"use client"

import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Globe, Clock } from 'lucide-react'

interface KeywordInputPageProps {
  keyword: string
  setKeyword: (value: string) => void
  targetMarket: string
  setTargetMarket: (value: string) => void
  targetLanguage: string
  setTargetLanguage: (value: string) => void
  pageCount: string
  setPageCount: (value: string) => void
  timeRange: string
  setTimeRange: (value: string) => void
}

/**
 * 关键词输入页面组件
 */
export default function KeywordInputPage({
  keyword,
  setKeyword,
  targetMarket,
  setTargetMarket,
  targetLanguage,
  setTargetLanguage,
  pageCount,
  setPageCount,
  timeRange,
  setTimeRange
}: KeywordInputPageProps) {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          输入一个关键词发现创意
        </h1>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            关键词/长尾词/提问词 <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <Input
              type="text"
              placeholder="AI SEO tool, best AI tools for SEO, how to use AI for SEO"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              className="pr-16"
              maxLength={100}
            />
            <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-gray-400">
              {keyword.length}/100
            </span>
          </div>
          <div className="text-sm text-gray-500 mt-2 space-y-1">
            <p><strong>支持多种输入类型：</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li><strong>关键词：</strong>AI SEO tool, digital marketing</li>
              <li><strong>长尾词：</strong>best AI tools for SEO in 2025, affordable SEO software</li>
              <li><strong>提问词：</strong>how to improve SEO with AI, what is the best SEO tool</li>
              <li><strong>短语：</strong>AI-powered SEO optimization, digital marketing strategies</li>
            </ul>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              目标市场
            </label>
            <Select value={targetMarket} onValueChange={setTargetMarket}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Globe className="w-4 h-4 mr-2" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="美国">美国</SelectItem>
                <SelectItem value="中国">中国</SelectItem>
                <SelectItem value="英国">英国</SelectItem>
                <SelectItem value="日本">日本</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              目标语种
            </label>
            <Select value={targetLanguage} onValueChange={setTargetLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="英语">英语</SelectItem>
                <SelectItem value="中文">中文</SelectItem>
                <SelectItem value="日语">日语</SelectItem>
                <SelectItem value="法语">法语</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              检索页面数
            </label>
            <Select value={pageCount} onValueChange={setPageCount}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 页</SelectItem>
                <SelectItem value="2">2 页</SelectItem>
                <SelectItem value="3">3 页</SelectItem>
                <SelectItem value="5">5 页</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              检索时间范围
            </label>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="任何时候">任何时候</SelectItem>
                <SelectItem value="过去一小时">过去一小时</SelectItem>
                <SelectItem value="过去24小时">过去24小时</SelectItem>
                <SelectItem value="过去一周">过去一周</SelectItem>
                <SelectItem value="上个月">上个月</SelectItem>
                <SelectItem value="过去一年">过去一年</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>


      </div>
    </div>
  )
} 
import '@testing-library/jest-dom'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import KeywordInputPage from '../KeywordInputPage'
import BlogIdeasPage from '../BlogIdeasPage'
import { useAppState } from '@/hooks/useAppState'
import React from 'react'

jest.mock('@/hooks/useAppState')

const mockIdeas = [
  { title: 'AI SEO 入门', type: 'Guide' as const, description: 'AI SEO 基础知识', keywords: ['AI', 'SEO'] },
  { title: 'AI SEO 工具推荐', type: 'Listicle' as const, description: '推荐好用的AI SEO工具', keywords: ['AI', 'SEO', '工具'] }
]

describe('关键词到创意流程', () => {
  it('用户输入关键词并生成创意，页面应显示创意列表', async () => {
    // mock useAppState
    (useAppState as jest.Mock).mockReturnValue({
      keyword: '',
      setKeyword: jest.fn(),
      targetMarket: '中国',
      setTargetMarket: jest.fn(),
      targetLanguage: '中文',
      setTargetLanguage: jest.fn(),
      pageCount: '2',
      setPageCount: jest.fn(),
      timeRange: '任何时候',
      setTimeRange: jest.fn(),
      handleSearch: jest.fn(),
      isLoading: false,
      currentStep: 'ideas',
      blogIdeas: mockIdeas,
      setCustomIdea: jest.fn(),
      customIdea: '',
      selectedIdeaIndex: 0,
      onIdeaSelect: jest.fn(),
      additionalInfo: '',
      setAdditionalInfo: jest.fn(),
      additionalRequirements: '',
      setAdditionalRequirements: jest.fn(),
      autoInsertLSI: false,
      setAutoInsertLSI: jest.fn(),
      knowledgeSource: '',
      setKnowledgeSource: jest.fn()
    })

    render(<BlogIdeasPage
      keyword="AI SEO"
      targetMarket="中国"
      targetLanguage="中文"
      searchResults={[]}
      blogIdeas={mockIdeas}
      searchIntent={null}
      customIdea=""
      setCustomIdea={jest.fn()}
      selectedIdeaIndex={0}
      onIdeaSelect={jest.fn()}
      additionalInfo=""
      setAdditionalInfo={jest.fn()}
      additionalRequirements=""
      setAdditionalRequirements={jest.fn()}
      autoInsertLSI={false}
      setAutoInsertLSI={jest.fn()}
      knowledgeSource=""
      setKnowledgeSource={jest.fn()}
    />)

    // 验证创意列表渲染
    expect(screen.getByText('AI SEO 入门')).toBeInTheDocument()
    expect(screen.getByText('AI SEO 工具推荐')).toBeInTheDocument()
  })
}) 
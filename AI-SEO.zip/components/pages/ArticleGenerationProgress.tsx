"use client"

import React from 'react'
import { CheckCircle } from 'lucide-react'

/**
 * 文章生成子步骤枚举
 */
enum ArticleGenerationSubStep {
  MATCHING_EVIDENCE_TYPES = 1,
  SEARCHING_EVIDENCE = 2,
  CRAWLING_CONTENT = 3,
  EXTRACTING_EVIDENCE = 4
}

interface ArticleGenerationProgressProps {
  // 文章生成状态
  articleGenerationStep: number
  articleGenerationMessage: string
  generatedEvidence?: any[]
}

/**
 * 文章生成进度页面组件
 * 显示文章生成的步骤进度，参考TitleGeneratingPage的设计风格
 */
export default function ArticleGenerationProgress({
  articleGenerationStep,
  articleGenerationMessage,
  generatedEvidence = []
}: ArticleGenerationProgressProps) {

  /**
   * 获取步骤标题
   */
  const getStepText = (): string => {
    switch (articleGenerationStep) {
      case ArticleGenerationSubStep.MATCHING_EVIDENCE_TYPES:
        return '为文章匹配合适的证据类型'
      case ArticleGenerationSubStep.SEARCHING_EVIDENCE:
        return '通过谷歌搜索目标证据'
      case ArticleGenerationSubStep.CRAWLING_CONTENT:
        return '抓取相关网站内容获取目标证据'
      case ArticleGenerationSubStep.EXTRACTING_EVIDENCE:
        return '分析并提取网站内容中的目标证据'
      default:
        return '正在处理...'
    }
  }

  /**
   * 获取当前步骤状态文本
   */
  const getStepStatusText = (): string => {
    switch (articleGenerationStep) {
      case ArticleGenerationSubStep.MATCHING_EVIDENCE_TYPES:
        return '正在分析文章内容并匹配证据类型'
      case ArticleGenerationSubStep.SEARCHING_EVIDENCE:
        return '正在搜索相关证据和资料'
      case ArticleGenerationSubStep.CRAWLING_CONTENT:
        return '正在获取网站内容和数据'
      case ArticleGenerationSubStep.EXTRACTING_EVIDENCE:
        return '正在提取和整理目标证据'
      default:
        return '正在处理...'
    }
  }

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="mb-8">
        {/* 步骤指示器 */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 text-sm font-medium ${
                    step < articleGenerationStep ? 'bg-green-500 text-white' :
                    step === articleGenerationStep ? 'bg-blue-500 text-white' :
                    'bg-gray-200 text-gray-400'
                  }`}>
                    {step < articleGenerationStep ? <CheckCircle className="w-5 h-5" /> : step}
                  </div>
                  <span className={`text-xs font-medium ${
                    step === articleGenerationStep ? 'text-blue-600' : 
                    step < articleGenerationStep ? 'text-green-600' : 'text-gray-400'
                  }`}>
                    步骤{step}
                  </span>
                </div>
                {step < 4 && (
                  <div className={`w-12 h-1 mx-3 ${
                    step < articleGenerationStep ? 'bg-green-500' : 'bg-gray-200'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 当前步骤内容 */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            {getStepText()}
          </h2>
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            {getStepStatusText()}
          </h3>
          <p className="text-gray-600 mb-4">
            {articleGenerationMessage || '正在努力为您生成高质量的文章内容...'}
          </p>
          <p className="text-sm text-gray-500">
            大约需要 30-60 秒。
          </p>
        </div>

        {/* 已收集证据显示 */}
        {generatedEvidence.length > 0 && (
          <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-center mb-3">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span className="text-sm font-medium text-green-900">
                已收集 {generatedEvidence.length} 条高质量证据
              </span>
            </div>
            <div className="text-xs text-green-700">
              证据将帮助增强文章的可信度和权威性
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export { ArticleGenerationSubStep } 
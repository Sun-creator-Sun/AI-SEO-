"use client"

import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Settings, Plus } from 'lucide-react'
import { BlogOutline, SearchResult } from '@/lib/google-search'
import { useState, useEffect } from 'react'

interface SettingsPageProps {
  keyword: string
  targetMarket: string
  targetLanguage: string
  selectedTitle: string
  generatedOutline: BlogOutline | null
  filteredBlogContent: SearchResult[]
  // 配置状态
  articleRequirements: string
  setArticleRequirements: (value: string) => void
  addFactsAndEvidence: boolean
  setAddFactsAndEvidence: (value: boolean) => void
  searchRegion: string
  setSearchRegion: (value: string) => void
  contentLanguage: string
  setContentLanguage: (value: string) => void
  autoInsertInternalLinks: boolean
  setAutoInsertInternalLinks: (value: boolean) => void
  anchorTextAutomation: boolean
  setAnchorTextAutomation: (value: boolean) => void
  autoInsertExternalLinks: boolean
  setAutoInsertExternalLinks: (value: boolean) => void
  externalDomainWhitelist: boolean
  setExternalDomainWhitelist: (value: boolean) => void
  addBlogCoverImage: boolean
  setAddBlogCoverImage: (value: boolean) => void
  addImagesUnderH2: boolean
  setAddImagesUnderH2: (value: boolean) => void
  addKeyPoints: boolean
  setAddKeyPoints: (value: boolean) => void
  addFAQSection: boolean
  setAddFAQSection: (value: boolean) => void
  addMoreRecommendations: boolean
  setAddMoreRecommendations: (value: boolean) => void
  customLinks: Array<{ url: string; anchor: string }>
  setCustomLinks: (links: Array<{ url: string; anchor: string }>) => void
  // 修改：使用全局状态
  customAnchorLinks: Array<{ url: string; anchor: string }>
  setCustomAnchorLinks: (links: Array<{ url: string; anchor: string }>) => void
  // 文章生成状态
  isGeneratingArticle: boolean
  articleGenerationStep: number
  articleGenerationMessage: string
  generatedEvidence: any[]
}

/**
 * 最终配置页面组件
 */
export default function SettingsPage({
  keyword,
  targetMarket,
  targetLanguage,
  selectedTitle,
  generatedOutline,
  filteredBlogContent,
  articleRequirements,
  setArticleRequirements,
  addFactsAndEvidence,
  setAddFactsAndEvidence,
  searchRegion,
  setSearchRegion,
  contentLanguage,
  setContentLanguage,
  autoInsertInternalLinks,
  setAutoInsertInternalLinks,
  anchorTextAutomation,
  setAnchorTextAutomation,
  autoInsertExternalLinks,
  setAutoInsertExternalLinks,
  externalDomainWhitelist,
  setExternalDomainWhitelist,
  addBlogCoverImage,
  setAddBlogCoverImage,
  addImagesUnderH2,
  setAddImagesUnderH2,
  addKeyPoints,
  setAddKeyPoints,
  addFAQSection,
  setAddFAQSection,
  addMoreRecommendations,
  setAddMoreRecommendations,
  customLinks,
  setCustomLinks,
  customAnchorLinks,
  setCustomAnchorLinks,
  isGeneratingArticle,
  articleGenerationStep,
  articleGenerationMessage,
  generatedEvidence
}: SettingsPageProps) {

  // 示例信息显示状态
  const [showExampleModal, setShowExampleModal] = useState(false)

  /**
   * 添加自定义链接
   */
  const addCustomLink = () => {
    setCustomLinks([...customLinks, { url: '', anchor: '' }])
  }

  /**
   * 更新自定义链接
   */
  const updateCustomLink = (index: number, field: 'url' | 'anchor', value: string) => {
    const newLinks = [...customLinks]
    newLinks[index][field] = value
    setCustomLinks(newLinks)
  }

  /**
   * 删除自定义链接
   */
  const removeCustomLink = (index: number) => {
    setCustomLinks(customLinks.filter((_, i) => i !== index))
  }

  /**
   * 添加自定义锚文本链接
   */
  const addCustomAnchorLink = () => {
    const newLinks = [...(customAnchorLinks || []), { url: '', anchor: '' }];
    setCustomAnchorLinks(newLinks);
    console.log('添加新的锚文本链接', { newLinks });
  }

  /**
   * 更新自定义锚文本链接
   */
  const updateCustomAnchorLink = (index: number, field: 'url' | 'anchor', value: string) => {
    const newLinks = [...(customAnchorLinks || [])];
    if (newLinks[index]) {
      newLinks[index][field] = value;
      setCustomAnchorLinks(newLinks);
      console.log('更新锚文本链接', { index, field, value, newLinks });
    }
  }

  /**
   * 删除自定义锚文本链接
   */
  const removeCustomAnchorLink = (index: number) => {
    const newLinks = (customAnchorLinks || []).filter((_, i) => i !== index);
    setCustomAnchorLinks(newLinks);
    console.log('删除锚文本链接', { index, newLinks });
  }

  return (
    <div className="h-full">
      <div className="max-w-6xl mx-auto h-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* 左侧：关键词信息和参考资料 */}
          <div className="lg:col-span-1 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 关键词信息 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <div className="flex items-center mb-3">
                <span className="text-sm text-blue-600">关键词</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{keyword}</h2>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-3">🇺🇸 {targetMarket}</span>
                  <span>🌐 {targetLanguage}</span>
                </div>
              </div>
            </div>

            {/* 选中的标题 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-3">标题</h4>
              <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
                {selectedTitle}
              </div>
            </div>

            {/* 参考资料 */}
            <div className="bg-white rounded-lg border p-4">
              <h4 className="font-medium text-gray-900 mb-3">
                参考资料 ({filteredBlogContent.length})
              </h4>
              <p className="text-xs text-gray-500 mb-3">从参考文章中选择与所选想法最相关的文章。</p>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {filteredBlogContent.length > 0 ? (
                  filteredBlogContent.map((content, index) => (
                    <div key={index} className="border-l-2 border-blue-200 pl-3">
                      <div className="flex items-start space-x-2">
                        <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded flex-shrink-0">
                          {content.originalIndex || index + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <a 
                            href={content.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm font-medium text-blue-600 hover:text-blue-800 cursor-pointer line-clamp-2 block"
                          >
                            {content.title}
                          </a>
                          <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                            {content.snippet}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">暂无参考资料</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 右侧：增强设置 */}
          <div className="lg:col-span-2 overflow-y-auto max-h-[calc(100vh-200px)]">
            <div className="flex items-center mb-6">
              <Settings className="w-5 h-5 mr-2 text-blue-600" />
              <h3 className="text-lg font-semibold">增强设置</h3>
            </div>

            <div className="space-y-6">
              {/* 生成文章的要求 */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">生成文章的要求</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowExampleModal(true)}
                      className="text-blue-600 hover:text-blue-700 text-sm"
                    >
                      示例
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="请输入您下一步生成文章的要求。"
                    value={articleRequirements}
                    onChange={(e) => setArticleRequirements(e.target.value)}
                    className="min-h-[120px] text-sm"
                  />
                  <div className="text-right text-xs text-gray-500 mt-2">
                    {articleRequirements.length}/3000
                  </div>
                </CardContent>
              </Card>

              {/* 示例信息弹出框 */}
              {showExampleModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setShowExampleModal(false)}>
                  <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">生成文章要求示例</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowExampleModal(false)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        ✕
                      </Button>
                    </div>
                    <div className="space-y-4 text-sm text-gray-700">
                      <p>您可以在生成博客内容时添加提示词描述。例如（以英语为例）：</p>
                      
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">1. 您可以指定生成的博客内容应包含产品信息：</h4>
                        <div className="bg-white p-3 rounded border text-xs font-mono">
                          In the writing process, make appropriate use of the following product information: My Brand Name is an AI-powered marketing tool...
                        </div>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">2. 您可以指定特定的写作风格：</h4>
                        <div className="bg-white p-3 rounded border text-xs font-mono">
                          Please write in a conversational tone, using simple language that beginners can understand. Include real-world examples and actionable tips.
                        </div>
                      </div>

                      <div className="bg-yellow-50 p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">3. 您可以要求避免某些内容：</h4>
                        <div className="bg-white p-3 rounded border text-xs font-mono">
                          Avoid mentioning competitor brands. Focus on benefits rather than technical specifications.
                        </div>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">4. 您可以指定目标受众：</h4>
                        <div className="bg-white p-3 rounded border text-xs font-mono">
                          Target audience: Small business owners who are new to digital marketing. Use relatable examples from retail, restaurants, or service businesses.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 事实和证据搜索设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">事实和证据搜索</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* 添加事实和证据开关 */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">添加事实和证据</Label>
                      <p className="text-xs text-gray-500 mt-1" title="我们将在谷歌上进行相关搜索，以提供额外的事实和证据来支持您的文章，从而增强其可信度和权威性。">
                        我们将在谷歌上进行相关搜索，以提供额外的事实和证据来支持您的文章，从而增强其可信度和权威性。
                      </p>
                    </div>
                    <Switch
                      checked={addFactsAndEvidence}
                      onCheckedChange={setAddFactsAndEvidence}
                    />
                  </div>

                  {/* 搜索区域和语言设置 */}
                  {addFactsAndEvidence && (
                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                      <div>
                        <Label className="block text-sm font-medium text-gray-700 mb-2">搜索区域</Label>
                        <Select value={searchRegion} onValueChange={setSearchRegion}>
                          <SelectTrigger>
                            <SelectValue placeholder="选择搜索区域" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="美国">🇺🇸 美国</SelectItem>
                            <SelectItem value="中国">🇨🇳 中国</SelectItem>
                            <SelectItem value="英国">🇬🇧 英国</SelectItem>
                            <SelectItem value="加拿大">🇨🇦 加拿大</SelectItem>
                            <SelectItem value="澳大利亚">🇦🇺 澳大利亚</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="block text-sm font-medium text-gray-700 mb-2">语言</Label>
                        <Select value={contentLanguage} onValueChange={setContentLanguage}>
                          <SelectTrigger>
                            <SelectValue placeholder="选择语言" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="英语">英语</SelectItem>
                            <SelectItem value="中文">中文</SelectItem>
                            <SelectItem value="日语">日语</SelectItem>
                            <SelectItem value="韩语">韩语</SelectItem>
                            <SelectItem value="法语">法语</SelectItem>
                            <SelectItem value="德语">德语</SelectItem>
                            <SelectItem value="西班牙语">西班牙语</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* 内链设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">内链</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">自动插入内链</Label>
                      <p className="text-xs text-gray-500 mt-1">只需输入您的域名，我们将自动为您的站点建立索引并插入相关的内链。</p>
                    </div>
                    <Switch
                      checked={autoInsertInternalLinks}
                      onCheckedChange={setAutoInsertInternalLinks}
                    />
                  </div>
                  
                  {autoInsertInternalLinks && (
                    <div className="bg-pink-50 p-3 rounded">
                      <Input placeholder="输入域名" className="text-sm" />
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">锚文本链接自动化</Label>
                      <p className="text-xs text-gray-500 mt-1">自动为您的指定锚文本添加预定义的链接</p>
                    </div>
                    <Switch
                      checked={anchorTextAutomation}
                      onCheckedChange={setAnchorTextAutomation}
                    />
                  </div>

                  {/* 自定义锚文本和链接区域 */}
                  {anchorTextAutomation && (
                    <div className="pt-4 border-t border-gray-100 mt-4">
                      <Label className="text-sm font-medium mb-2 block">自定义锚文本和链接</Label>
                      <p className="text-xs text-gray-500 mb-3">
                        在此处添加您希望自动链接的特定锚文本及其对应的URL。在文章生成时，这些锚文本将被替换为指向对应URL的Markdown链接。
                      </p>
                      <div className="space-y-3">
                        {(customAnchorLinks || []).map((link, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Input
                              placeholder="锚文本 (例如：vertu)"
                              value={link.anchor}
                              onChange={(e) => updateCustomAnchorLink(index, 'anchor', e.target.value)}
                              className="flex-1 text-sm"
                            />
                            <Input
                              placeholder="链接地址 (例如：https://vertu.com)"
                              value={link.url}
                              onChange={(e) => updateCustomAnchorLink(index, 'url', e.target.value)}
                              className="flex-1 text-sm"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeCustomAnchorLink(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              删除
                            </Button>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={addCustomAnchorLink}
                          className="w-full"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          添加锚文本链接
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* 外链设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">外链</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">自动插入外链</Label>
                      <p className="text-xs text-gray-500 mt-1">自动插入高权重外链以增强内容的可信度。</p>
                    </div>
                    <Switch
                      checked={autoInsertExternalLinks}
                      onCheckedChange={setAutoInsertExternalLinks}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">外部域名黑名单</Label>
                      <p className="text-xs text-gray-500 mt-1">当您开启外部域名黑名单时，列表中的任何域名链接将不再出现在生成的文章中</p>
                    </div>
                    <Switch
                      checked={externalDomainWhitelist}
                      onCheckedChange={setExternalDomainWhitelist}
                    />
                  </div>

                  {/* 插入指定链接 */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">插入指定链接</Label>
                    <div className="space-y-3">
                      {customLinks.map((link, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Input
                            placeholder="链接地址"
                            value={link.url}
                            onChange={(e) => updateCustomLink(index, 'url', e.target.value)}
                            className="flex-1 text-sm"
                          />
                          <Input
                            placeholder="锚文本"
                            value={link.anchor}
                            onChange={(e) => updateCustomLink(index, 'anchor', e.target.value)}
                            className="flex-1 text-sm"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeCustomLink(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            删除
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={addCustomLink}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-1" />
                        添加链接
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">手动添加链接和锚文本，准确链接到目标页面，有效推广产品、活动和各种资源。</p>
                  </div>
                </CardContent>
              </Card>

              {/* 图片设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">图片</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">添加博客封面图片</Label>
                      <p className="text-xs text-gray-500 mt-1">选择图像来源进行搜索，或让 AI 生成与您的文章内容完美匹配的封面图像</p>
                    </div>
                    <Switch
                      checked={addBlogCoverImage}
                      onCheckedChange={setAddBlogCoverImage}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">在H2标题下添加图片</Label>
                      <p className="text-xs text-gray-500 mt-1">自动查找最合适的图片，并将它们插入到一些H2的内容中（1-2张图片）</p>
                    </div>
                    <Switch
                      checked={addImagesUnderH2}
                      onCheckedChange={setAddImagesUnderH2}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* 文章结构设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">文章结构</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">添加关键要点</Label>
                      <p className="text-xs text-gray-500 mt-1">"关键要点" 是对文章核心内容的简明总结，旨在帮助读者快速掌握主要内容</p>
                    </div>
                    <Switch
                      checked={addKeyPoints}
                      onCheckedChange={setAddKeyPoints}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">常见问题解答</Label>
                      <p className="text-xs text-gray-500 mt-1">我们会在您的文章中添加一个常见问题解答 (FAQ) 部分。这个部分对搜索引擎优化非常有益，因为它可以改善用户体验，瞄准长尾关键词，并且可以与结构化数据一起出现在搜索结果中，从而增加可见性和点击率</p>
                    </div>
                    <Switch
                      checked={addFAQSection}
                      onCheckedChange={setAddFAQSection}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">添加"更多推荐内容"部分</Label>
                      <p className="text-xs text-gray-500 mt-1">此功能将在您的文章末尾显示最多5篇相关文章</p>
                    </div>
                    <Switch
                      checked={addMoreRecommendations}
                      onCheckedChange={setAddMoreRecommendations}
                    />
                  </div>

                  {addKeyPoints && addFAQSection && (
                    <div className="bg-blue-50 p-3 rounded flex items-center text-sm">
                      <span className="text-blue-600 mr-2">ℹ️</span>
                      <span className="text-blue-800">预计额外增加字数: 420~700。</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 
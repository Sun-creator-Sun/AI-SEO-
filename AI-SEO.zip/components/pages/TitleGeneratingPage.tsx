"use client"

import { CheckCircle } from 'lucide-react'

/**
 * 标题生成子步骤枚举
 */
enum TitleGenerationSubStep {
  SEARCHING_CONTENT = 1,
  FILTERING_CONTENT = 2,
  EXTRACTING_KNOWLEDGE = 3,
  GENERATING_TITLES = 4
}

interface TitleGeneratingPageProps {
  titleGenerationStep: TitleGenerationSubStep
  titleGenerationProgress: number
}

/**
 * 标题生成进度页面组件
 */
export default function TitleGeneratingPage({
  titleGenerationStep,
  titleGenerationProgress
}: TitleGeneratingPageProps) {
  
  /**
   * 获取当前步骤文本
   */
  const getStepText = () => {
    switch (titleGenerationStep) {
      case TitleGenerationSubStep.SEARCHING_CONTENT:
        return '使用谷歌搜索与博客主题相关的更多内容作为参考';
      case TitleGenerationSubStep.FILTERING_CONTENT:
        return '过滤出搜索结果中与主题相关的博客类型内容作为参考';
      case TitleGenerationSubStep.EXTRACTING_KNOWLEDGE:
        return '从搜索结果内容中提取知识点';
      case TitleGenerationSubStep.GENERATING_TITLES:
        return '用知识点+额外要求+参考文章标题生成博客标题';
      default:
        return '正在处理...';
    }
  };

  /**
   * 获取当前步骤状态文本
   */
  const getStepStatusText = () => {
    switch (titleGenerationStep) {
      case TitleGenerationSubStep.SEARCHING_CONTENT:
        return '正在搜索相关内容';
      case TitleGenerationSubStep.FILTERING_CONTENT:
        return '正在筛选参考内容';
      case TitleGenerationSubStep.EXTRACTING_KNOWLEDGE:
        return '正在提取知识点';
      case TitleGenerationSubStep.GENERATING_TITLES:
        return '正在生成博客标题';
      default:
        return '正在处理...';
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="mb-8">
        {/* 步骤指示器 */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 text-sm font-medium ${
                    step < titleGenerationStep ? 'bg-green-500 text-white' :
                    step === titleGenerationStep ? 'bg-blue-500 text-white' :
                    'bg-gray-200 text-gray-400'
                  }`}>
                    {step < titleGenerationStep ? <CheckCircle className="w-5 h-5" /> : step}
                  </div>
                  <span className={`text-xs font-medium ${
                    step === titleGenerationStep ? 'text-blue-600' : 
                    step < titleGenerationStep ? 'text-green-600' : 'text-gray-400'
                  }`}>
                    步骤{step}
                  </span>
                </div>
                {step < 4 && (
                  <div className={`w-12 h-1 mx-3 ${
                    step < titleGenerationStep ? 'bg-green-500' : 'bg-gray-200'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 当前步骤内容 */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            {getStepText()}
          </h2>
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            {getStepStatusText()}
          </h3>
          <p className="text-gray-600">
            大约需要 20-40 秒。
          </p>
        </div>
      </div>
    </div>
  );
}

export { TitleGenerationSubStep } 
"use client"

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { SearchResult, BlogIdea, BlogTitle } from '@/lib/google-search'

interface TitlesPageProps {
  keyword: string
  targetMarket: string
  targetLanguage: string
  selectedIdeaIndex: number | null
  blogIdeas: BlogIdea[]
  customIdea: string
  extractedKnowledge: string[]
  filteredBlogContent: SearchResult[]
  generatedTitles: BlogTitle[]
  selectedTitleIndex: number | null
  setSelectedTitleIndex: (index: number | null) => void
  customTitle: string
  setCustomTitle: (value: string) => void
  wordCount: string
  setWordCount: (value: string) => void
  readabilityLevel: string
  setReadabilityLevel: (value: string) => void
  toneStyle: string
  setToneStyle: (value: string) => void
  perspective: string
  setPerspective: (value: string) => void
  outlineRequirements: string
  setOutlineRequirements: (value: string) => void
}

/**
 * 标题展示页面组件
 */
export default function TitlesPage({
  keyword,
  targetMarket,
  targetLanguage,
  selectedIdeaIndex,
  blogIdeas,
  customIdea,
  extractedKnowledge,
  filteredBlogContent,
  generatedTitles,
  selectedTitleIndex,
  setSelectedTitleIndex,
  customTitle,
  setCustomTitle,
  wordCount,
  setWordCount,
  readabilityLevel,
  setReadabilityLevel,
  toneStyle,
  setToneStyle,
  perspective,
  setPerspective,
  outlineRequirements,
  setOutlineRequirements
}: TitlesPageProps) {
  
  return (
    <div className="h-full">
      <div className="max-w-6xl mx-auto h-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* 左侧：关键词信息和参考资料 */}
          <div className="lg:col-span-1 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 关键词信息 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <div className="flex items-center mb-3">
                <span className="text-sm text-blue-600">关键词</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{keyword}</h2>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-3">🇺🇸 {targetMarket}</span>
                  <span>🌐 {targetLanguage}</span>
                </div>
              </div>
            </div>

            {/* 选中的创意 */}
            {(selectedIdeaIndex !== null || customIdea) && (
              <div className="bg-white rounded-lg border p-4 mb-6">
                <h4 className="font-medium text-gray-900 mb-3">选中的创意</h4>
                <div className="text-sm text-gray-600">
                  {selectedIdeaIndex !== null ? blogIdeas[selectedIdeaIndex].title : customIdea}
                </div>
              </div>
            )}

            {/* 提取的知识点 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-3">提取的知识点 ({extractedKnowledge.length})</h4>
              <p className="text-xs text-gray-500 mb-3">从上一步的附加信息中提取的关键知识点。</p>
              <div className="space-y-2">
                {extractedKnowledge.length > 0 ? (
                  extractedKnowledge.slice(0, 10).map((knowledge, index) => (
                    <div key={index} className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                      {knowledge}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p className="text-sm">暂无提取的知识点</p>
                    <p className="text-xs mt-1">请在上一步的"附加信息"中输入相关内容</p>
                  </div>
                )}
              </div>
            </div>

            {/* 参考的博客内容 */}
            <div className="bg-white rounded-lg border p-4">
              <h4 className="font-medium text-gray-900 mb-3">
                参考的博客内容 ({filteredBlogContent.length})
              </h4>
              <div className="space-y-3">
                {filteredBlogContent.length > 0 ? (
                  filteredBlogContent.map((result, index) => (
                    <div key={index} className="border-l-2 border-gray-200 pl-3">
                      <div className="flex items-start space-x-2">
                        <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded flex-shrink-0">
                          {result.originalIndex || index + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <a 
                            href={result.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm font-medium text-blue-600 hover:text-blue-800 cursor-pointer line-clamp-2 block"
                          >
                            {result.title}
                          </a>
                          <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                            {result.snippet}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p className="text-sm">暂无参考的博客内容</p>
                    <p className="text-xs mt-1">正在从搜索结果中筛选相关内容...</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 右侧：生成的标题 */}
          <div className="lg:col-span-2 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 选择一个标题区域 */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold mb-6">选择一个标题</h3>
              
              {/* 生成的标题列表 */}
              <div className="space-y-3 mb-6">
                {generatedTitles.map((titleObj, index) => (
                  <div 
                    key={index} 
                    onClick={() => setSelectedTitleIndex(index === selectedTitleIndex ? null : index)}
                    className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 ${
                      selectedTitleIndex === index 
                        ? 'border-blue-500 bg-blue-50 shadow-md ring-2 ring-blue-200' 
                        : 'border-gray-200 hover:bg-gray-50 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900 mb-2 leading-relaxed">
                          {titleObj.title}
                        </h5>
                        <div className="flex items-center text-sm text-gray-500 mb-2">
                          <span className="mr-4">📝 博客标题</span>
                          <span className="mr-4">🎯 SEO: {titleObj.seoScore}/100</span>
                          <span>📖 可读性: {titleObj.readabilityScore}/100</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {titleObj.keywords.slice(0, 4).map((kw, kwIndex) => (
                            <span key={kwIndex} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                              {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {selectedTitleIndex === index && (
                          <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">✓ 已选中</span>
                        )}
                        <div className="flex flex-col items-center">
                          <div className={`w-3 h-3 rounded-full ${
                            titleObj.seoScore >= 80 ? 'bg-green-500' :
                            titleObj.seoScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}></div>
                          <span className="text-xs text-gray-400 mt-1">SEO</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 自定义标题输入 */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">或者输入您的标题</h4>
                <div className="border border-gray-200 rounded-lg p-4">
                  <Input
                    placeholder="输入您的自定义标题"
                    className="mb-3"
                    maxLength={200}
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                  />
                  <div className="text-right text-sm text-gray-400">
                    {customTitle.length}/200
                  </div>
                </div>
              </div>
            </div>

            {/* 大纲生成配置 */}
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-6">大纲生成配置</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 字数选择 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">字数</label>
                  <Select value={wordCount} onValueChange={setWordCount}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="800-1000">800-1000 (2-3个H2标题)</SelectItem>
                      <SelectItem value="1000-2000">1000-2000 (3-5个H2标题)</SelectItem>
                      <SelectItem value="2000-3000">2000-3000 (5-7个H2标题)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* 可读性选择 */}
                <div>
                  <div className="flex items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">可读性</label>
                    <span className="ml-2 text-gray-400 cursor-help" title="中学（六年级至八年级）: 浅显易懂。高中（9年级至12年级）: 普通阅读水平。大学学历或以上: 专业性词汇较多，需要一定的专业知识。">
                      ❓
                    </span>
                  </div>
                  <Select value={readabilityLevel} onValueChange={setReadabilityLevel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="中学">中学 (六年级至八年级)</SelectItem>
                      <SelectItem value="高中">高中 (九年级至十二年级)</SelectItem>
                      <SelectItem value="大学">大学学历或以上</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* 语气选择 */}
                <div>
                  <div className="flex items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">语气</label>
                    <span className="ml-2 text-gray-400 cursor-help" title="选择文章的语气风格">
                      ❓
                    </span>
                  </div>
                  <Select value={toneStyle} onValueChange={setToneStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="信息型/教育类">信息型/教育类</SelectItem>
                      <SelectItem value="专业/正式类">专业/正式类</SelectItem>
                      <SelectItem value="口语/非正式">口语/非正式</SelectItem>
                      <SelectItem value="说服性">说服性</SelectItem>
                      <SelectItem value="故事型/励志">故事型/励志</SelectItem>
                      <SelectItem value="幽默/娱乐性">幽默/娱乐性</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* 视角选择 */}
                <div>
                  <div className="flex items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">视角</label>
                    <span className="ml-2 text-gray-400 cursor-help" title="第一人称视角: 从我的视角写作，直接与读者分享个人经验和观点。第二人称视角: 将读者作为您，创建直接的连接并将他们吸引到叙述或讨论中。第三人称视角: 从外部视角叙述，将角色或个体称为他、她或他们，提供客观性和距离感。">
                      ❓
                    </span>
                  </div>
                  <Select value={perspective} onValueChange={setPerspective}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="第一人称视角">第一人称视角</SelectItem>
                      <SelectItem value="第二人称视角">第二人称视角</SelectItem>
                      <SelectItem value="第三人称视角">第三人称视角</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* 附加要求 */}
              <div className="mt-6">
                <div className="flex items-center justify-between mb-3">
                  <label className="block text-sm font-medium text-gray-700">附加要求（大纲生成）</label>
                  <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800 text-xs">
                    示例
                  </Button>
                </div>
                <textarea
                  placeholder="请输入下一步生成大纲的要求，例如：生成大纲的主要部分时确保嵌入我的品牌名称xxx。"
                  value={outlineRequirements}
                  onChange={(e) => setOutlineRequirements(e.target.value)}
                  className="w-full h-24 p-3 border border-gray-200 rounded-lg resize-none text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                  maxLength={3000}
                />
                <div className="text-right text-xs text-gray-400 mt-1">
                  {outlineRequirements.length}/3000
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 
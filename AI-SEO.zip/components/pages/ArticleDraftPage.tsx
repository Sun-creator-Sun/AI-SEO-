"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, ExternalLink, Image, Link, FileText, Search } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import { Evidence, SectionEvidenceRequirement } from '@/lib/article-generation'
import { BlogOutline } from '@/lib/google-search'
import { ArticleDraftStep } from '@/lib/content-generation'
import { saveArticleToHistory, calculateWordCount } from '@/lib/article-history'

interface ArticleDraftPageProps {
  keyword: string
  targetMarket: string
  targetLanguage: string
  selectedTitle: string
  generatedOutline: BlogOutline | null
  generatedEvidence: Evidence[]
  evidenceRequirements: SectionEvidenceRequirement[]
  // 生成状态
  currentStep: ArticleDraftStep
  stepMessage: string
  generatedContent: string
  isGenerating: boolean
  customAnchorLinks?: Array<{url: string; anchor: string}>
}

/**
 * 用于转义正则表达式特殊字符的辅助函数。
 * @param str 输入字符串。
 * @returns 转义后的字符串，可用作正则表达式的一部分。
 */
const escapeRegExp = (str: string): string => {
  return str.replace(/[.*+?^${}()|[\\\]]/g, '\\$&'); // $& 表示整个匹配到的字符串
};

/**
 * 将文本中的指定锚文本替换为Markdown链接。
 * @param text 原始文本内容。
 * @param customAnchorLinks 自定义锚文本和链接的列表。
 * @returns 处理后的文本，其中匹配的锚文本已转换为Markdown链接。
 */
const applyCustomAnchorLinks = (
  text: string,
  customAnchorLinks: Array<{ url: string; anchor: string }> | undefined
): string => {
  if (!text || !customAnchorLinks || customAnchorLinks.length === 0) {
    console.log('锚文本替换：没有可用的锚文本链接或文本为空', { 
      hasText: !!text, 
      anchorLinksCount: customAnchorLinks?.length 
    });
    return text;
  }

  let newText = text;
  
  try {
    // 按锚文本长度降序排序，优先匹配长锚文本，避免部分匹配问题
    const sortedLinks = [...customAnchorLinks]
      .filter(link => link.anchor && link.url) // 确保锚文本和URL都存在
      .sort((a, b) => b.anchor.length - a.anchor.length);
    
    console.log('锚文本替换：开始处理', { 
      availableAnchors: sortedLinks.map(l => l.anchor),
      textLength: text.length 
    });

    // 创建一个映射来跟踪已替换的位置
    const replacedPositions = new Set<number>();

    sortedLinks.forEach(link => {
      const escapedAnchor = escapeRegExp(link.anchor);
      // 使用更严格的单词边界匹配
      const regex = new RegExp(`(?<!\\[)\\b(${escapedAnchor})\\b(?!\\])(?!\\(${escapeRegExp(link.url)}\\))`, 'gi');
      
      let match;
      let lastIndex = 0;
      let tempText = newText;
      
      // 使用循环来处理所有匹配项
      while ((match = regex.exec(tempText)) !== null) {
        const matchStart = match.index;
        const matchEnd = matchStart + match[0].length;
        
        // 检查这个位置是否已经被替换过
        if (!Array.from(replacedPositions).some(pos => 
          (matchStart >= pos && matchStart < pos + 50) || // 避免替换已替换文本附近的内容
          (matchEnd > pos && matchEnd <= pos + 50)
        )) {
          const replacement = `[${match[0]}](${link.url})`;
          console.log(`找到锚文本匹配："${match[0]}"`, {
            position: matchStart,
            replacement: replacement
          });
          
          // 记录这个位置已被替换
          replacedPositions.add(matchStart);
          
          // 执行替换
          tempText = 
            tempText.substring(0, matchStart) + 
            replacement + 
            tempText.substring(matchEnd);
          
          // 更新 lastIndex 以考虑替换后的新长度
          const lengthDiff = replacement.length - match[0].length;
          regex.lastIndex += lengthDiff;
        }
      }
      
      newText = tempText;
    });

    const hasChanges = newText !== text;
    console.log('锚文本替换：处理完成', { 
      hasChanges,
      originalLength: text.length,
      newLength: newText.length,
      replacedCount: replacedPositions.size
    });

    return newText;
  } catch (error) {
    console.error('锚文本替换出错:', error);
    return text; // 发生错误时返回原始文本
  }
};

/**
 * 文章草稿页面组件
 */
export default function ArticleDraftPage({
  keyword,
  targetMarket,
  targetLanguage,
  selectedTitle,
  generatedOutline,
  generatedEvidence,
  evidenceRequirements,
  currentStep,
  stepMessage,
  generatedContent,
  isGenerating,
  customAnchorLinks
}: ArticleDraftPageProps) {

  // 在组件挂载和customAnchorLinks更新时输出调试信息
  useEffect(() => {
    console.log('ArticleDraftPage: customAnchorLinks 更新', {
      hasAnchorLinks: !!customAnchorLinks,
      anchorLinksCount: customAnchorLinks?.length,
      anchors: customAnchorLinks?.map(l => l.anchor)
    });
  }, [customAnchorLinks]);

  // 当文章生成完成时，保存到历史记录
  useEffect(() => {
    if (generatedContent && !isGenerating && currentStep === ArticleDraftStep.GENERATE_META) {
      // 文章生成完成，保存到历史记录
      const cleanedContent = cleanGeneratedContent(generatedContent);
      const wordCount = calculateWordCount(cleanedContent);
      
      saveArticleToHistory({
        title: selectedTitle,
        content: cleanedContent,
        keywords: [keyword, ...(generatedOutline?.seoKeywords || [])],
        wordCount,
        outline: generatedOutline || undefined,
        seoScore: 85, // 默认SEO评分
        readabilityScore: 80 // 默认可读性评分
      });
      
      console.log('文章已保存到历史记录:', {
        title: selectedTitle,
        wordCount,
        keywords: [keyword, ...(generatedOutline?.seoKeywords || [])]
      });
    }
  }, [generatedContent, isGenerating, currentStep, selectedTitle, keyword, generatedOutline]);

  // 添加右侧面板显示状态
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);

  /**
   * 按章节分组证据
   */
  const getEvidenceBySection = () => {
    if (!generatedOutline) return {}
    
    const evidenceBySection: { [key: string]: Evidence[] } = {}
    
    // 为每个章节创建空数组
    generatedOutline.sections.forEach(section => {
      evidenceBySection[section.heading] = []
      // 为每个子标题也创建空数组
      section.subheadings.forEach(subheading => {
        evidenceBySection[subheading] = []
      })
    })
    
    // 根据证据内容匹配到相应章节或子章节
    generatedEvidence.forEach(evidence => {
      let matched = false
      
      // 先尝试匹配子标题（H3）
      generatedOutline.sections.forEach(section => {
        section.subheadings.forEach(subheading => {
          if (!matched) {
            const subheadingKeywords = subheading.toLowerCase()
            const evidenceContent = evidence.content.toLowerCase()
            
            // 检查证据是否与子标题相关
            if (evidenceContent.includes(subheadingKeywords.split(' ')[0]) || 
                subheadingKeywords.split(' ').some(word => word.length > 3 && evidenceContent.includes(word))) {
              evidenceBySection[subheading].push(evidence)
              matched = true
            }
          }
        })
      })
      
      // 如果没有匹配到子标题，再匹配主标题（H2）
      if (!matched) {
        generatedOutline.sections.forEach(section => {
          if (!matched) {
            const sectionKeywords = section.heading.toLowerCase() + ' ' + section.keyPoints.join(' ').toLowerCase()
            const evidenceContent = evidence.content.toLowerCase()
            
            if (sectionKeywords.includes(evidence.type.replace(/_/g, ' ')) ||
                evidenceContent.length > 50) {
              evidenceBySection[section.heading].push(evidence)
              matched = true
            }
          }
        })
      }
      
      // 如果还没有匹配到，分配给第一个章节
      if (!matched && generatedOutline.sections.length > 0) {
        evidenceBySection[generatedOutline.sections[0].heading].push(evidence)
      }
    })
    
    return evidenceBySection
  }

  const evidenceBySection = getEvidenceBySection()

  /**
   * 清理生成的内容，移除API返回的额外包装
   */
  const cleanGeneratedContent = (content: string): string => {
    if (!content) return content;
    
    console.log('清理前的内容:', content.substring(0, 200) + '...');
    
    let cleaned = content;
    
    // 如果内容以 "Here's" 等开头，移除到第一个换行符
    const introEndIndex = cleaned.indexOf('\n');
    if (introEndIndex > -1 && cleaned.substring(0, introEndIndex).includes("Here's")) {
      cleaned = cleaned.substring(introEndIndex + 1).trim();
    }
    
    // 移除 markdown 代码块标记
    if (cleaned.startsWith('```markdown')) {
      cleaned = cleaned.substring('```markdown'.length).trim();
    } else if (cleaned.startsWith('```')) {
      cleaned = cleaned.substring(3).trim();
    }
    
    // 移除结尾的代码块标记
    if (cleaned.endsWith('```')) {
      cleaned = cleaned.substring(0, cleaned.length - 3).trim();
    }
    
    // 移除开头可能存在的说明文字（以":"结尾的部分）
    const colonIndex = cleaned.indexOf(':');
    if (colonIndex > -1 && colonIndex < 50) { // 只处理前50个字符内的冒号
      const firstNewline = cleaned.indexOf('\n');
      if (firstNewline > colonIndex) {
        cleaned = cleaned.substring(firstNewline + 1);
      }
    }
    
    console.log('清理后的内容:', cleaned.substring(0, 200) + '...');
    
    return cleaned.trim();
  };

  /**
   * 获取证据类型的中文名称
   */
  const getEvidenceTypeName = (type: string): string => {
    const typeMap: { [key: string]: string } = {
      'statistical_evidence': '统计证据',
      'predictive_evidence': '预测证据',
      'descriptive_evidence': '描述性证据',
      'explanatory_evidence': '解释性证据',
      'comparative_data': '对比数据',
      'user_experience': '用户体验',
      'survey_results': '调查结果',
      'statistics_user_surveys': '统计调查',
      'pros_and_cons': '优缺点分析',
      'performance_metrics': '性能指标',
      'feature_analysis': '功能分析',
      'advantages_disadvantages': '优劣分析',
      'feature_description': '功能描述',
      'comparative_numerical_review': '数值对比',
      'user_feedback_statistics': '用户反馈统计',
      'expert_predictions': '专家预测',
      'research_findings': '研究发现',
      'features_capabilities': '功能能力',
      'market_data': '市场数据',
      'user_performance_metrics': '用户性能指标',
      'comparative_analysis': '对比分析'
    }
    return typeMap[type] || type
  }

  /**
   * 获取步骤状态
   */
  const getStepStatus = (step: ArticleDraftStep) => {
    if (step < currentStep) return 'completed'
    if (step === currentStep) return 'current'
    return 'pending'
  }

  /**
   * 获取步骤图标
   */
  const getStepIcon = (step: ArticleDraftStep) => {
    const status = getStepStatus(step)
    
    if (status === 'completed') {
      return <CheckCircle className="w-5 h-5 text-green-600" />
    }
    
    const iconMap = {
      [ArticleDraftStep.GENERATE_CONTENT]: <FileText className="w-5 h-5" />,
      [ArticleDraftStep.SEARCH_IMAGES]: <Image className="w-5 h-5" />,
      [ArticleDraftStep.INSERT_LINKS]: <Link className="w-5 h-5" />,
      [ArticleDraftStep.GENERATE_META]: <Search className="w-5 h-5" />
    }
    
    return iconMap[step]
  }

  /**
   * 获取步骤标题
   */
  const getStepTitle = (step: ArticleDraftStep): string => {
    const titleMap = {
      [ArticleDraftStep.GENERATE_CONTENT]: '生成文章内容',
      [ArticleDraftStep.SEARCH_IMAGES]: '搜索配图',
      [ArticleDraftStep.INSERT_LINKS]: '插入链接',
      [ArticleDraftStep.GENERATE_META]: '生成元描述'
    }
    return titleMap[step]
  }

  /**
   * 获取步骤描述
   */
  const getStepDescription = (step: ArticleDraftStep): string => {
    const descMap = {
      [ArticleDraftStep.GENERATE_CONTENT]: '根据知识总结及生成要求逐段生成内容',
      [ArticleDraftStep.SEARCH_IMAGES]: '为文章搜索合适的配图',
      [ArticleDraftStep.INSERT_LINKS]: '查找并插入内部和外部链接以及锚文本',
      [ArticleDraftStep.GENERATE_META]: '为文章页面生成元描述信息'
    }
    return descMap[step]
  }

  /**
   * 渲染单个证据项
   */
  const renderEvidenceItem = (evidence: Evidence, index: number) => (
    <div key={index} className="text-sm text-gray-600 mb-3">
      <div className="flex items-start">
        <span className="text-gray-800 font-medium mr-2 flex-shrink-0">
          {index + 1}.
        </span>
        <div className="flex-1">
          <div className="text-gray-700 mb-1 leading-relaxed prose prose-sm max-w-none">
            <ReactMarkdown
              components={{
                p: ({ children }) => <p className="text-sm text-gray-700 mb-2 leading-relaxed">{children}</p>,
                strong: ({ children }) => <strong className="font-semibold text-gray-900">{children}</strong>,
                em: ({ children }) => <em className="italic text-gray-700">{children}</em>,
                code: ({ children }) => <code className="bg-gray-100 px-1 py-0.5 rounded text-xs font-mono">{children}</code>,
                ul: ({ children }) => <ul className="list-disc list-inside text-sm text-gray-700 mb-2">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal list-inside text-sm text-gray-700 mb-2">{children}</ol>,
                li: ({ children }) => <li className="mb-1">{children}</li>,
                blockquote: ({ children }) => <blockquote className="border-l-2 border-gray-300 pl-2 italic text-gray-600 text-sm">{children}</blockquote>,
                a: ({ children, href }) => <a href={href} className="text-blue-600 hover:text-blue-800 underline" target="_blank" rel="noopener noreferrer">{children}</a>
              }}
            >
              {evidence.content}
            </ReactMarkdown>
          </div>
          
          {/* 证据类型和评分信息 */}
          <div className="flex items-center text-xs text-gray-500 mb-1">
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded mr-2">
              {getEvidenceTypeName(evidence.type)}
            </span>
            <span className="mr-3">可信度: {evidence.credibility}/10</span>
            <span>相关性: {evidence.relevance}/10</span>
          </div>
        </div>
      </div>
    </div>
  )

  /**
   * 渲染参考链接
   */
  const renderReferenceLinks = (evidenceList: Evidence[]) => {
    if (evidenceList.length === 0) return null
    
    // 找到相关性最高的证据作为参考链接
    const bestEvidence = evidenceList.reduce((best, current) => 
      current.relevance > best.relevance ? current : best
    )
    
    return (
      <div className="mt-3 pt-2 border-t border-gray-100">
        <div className="text-xs text-blue-600">
          <span className="text-gray-500">参考: </span>
          <a 
            href={bestEvidence.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-blue-800 hover:underline"
            title={bestEvidence.source}
          >
            {bestEvidence.url.length > 50 ? bestEvidence.url.substring(0, 50) + '...' : bestEvidence.url}
          </a>
        </div>
      </div>
    )
  }

  const sidebarWidthPx = 384; // 等同于 w-96
  const sidebarGapPx = 24;    // 等同于 gap-6 或 right-6
  const topOffsetPx = 100;    // 假设的顶部偏移（例如页眉高度）
  const bottomOffsetPx = 100; // 假设的底部偏移

  return (
    <div className="h-full">
      {/* 主要内容区域 (左侧 + 中间) */}
      <div className="max-w-7xl mx-auto h-full">
        <div className={`grid ${isRightPanelOpen ? 'grid-cols-10' : 'grid-cols-12'} gap-6 h-full`}>
          {/* 左侧：关键词和证据 */}
          <div className={`${isRightPanelOpen ? 'col-span-4' : 'col-span-5'} overflow-y-auto max-h-[calc(100vh-200px)]`}>
            {/* 关键词信息 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <div className="flex items-center mb-3">
                <span className="text-sm text-blue-600">关键词</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{keyword}</h2>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-3">🇺🇸 {targetMarket}</span>
                  <span>🌐 {targetLanguage}</span>
                </div>
              </div>
            </div>

            {/* 事实与证据 */}
            <div className="bg-white rounded-lg border p-4">
              <div className="flex items-center mb-2">
                <h4 className="font-medium text-gray-900">
                  事实与证据 ({generatedEvidence.length})
                </h4>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                用可靠的事实和证据强化您的论点。
              </p>
              {generatedOutline && generatedOutline.sections.map((section, sectionIndex) => {
                const sectionEvidence = evidenceBySection[section.heading] || []
                const totalSectionEvidence = sectionEvidence.length + 
                  section.subheadings.reduce((total, subheading) => 
                    total + (evidenceBySection[subheading] || []).length, 0)
                return (
                  <div key={sectionIndex} className="mb-6">
                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="inline-flex items-center bg-blue-600 text-white px-2 py-1 rounded text-sm font-medium">
                          H2
                        </div>
                        <h5 className="text-base font-medium text-gray-900">
                          {section.heading} ({totalSectionEvidence})
                        </h5>
                      </div>
                      {sectionEvidence.length > 0 && (
                        <div className="mb-4">
                          {sectionEvidence.map((evidence, index) => renderEvidenceItem(evidence, index))}
                          {renderReferenceLinks(sectionEvidence)}
                        </div>
                      )}
                    </div>
                    {section.subheadings && section.subheadings.length > 0 && (
                      <div className="ml-4">
                        {section.subheadings.map((subheading, subIndex) => {
                          const subheadingEvidence = evidenceBySection[subheading] || []
                          return (
                            <div key={subIndex} className="mb-4">
                              <div className="flex items-center gap-2 mb-2">
                                <div className="inline-flex items-center bg-gray-500 text-white px-2 py-1 rounded text-xs font-medium">
                                  H3
                                </div>
                                <span className="text-sm font-medium text-gray-800">
                                  {subheading} ({subheadingEvidence.length})
                                </span>
                              </div>
                              {subheadingEvidence.length > 0 && (
                                <div className="ml-6">
                                  {subheadingEvidence.map((evidence, index) => renderEvidenceItem(evidence, index))}
                                  {renderReferenceLinks(subheadingEvidence)}
                                </div>
                              )}
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })}
              {generatedEvidence.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-sm">暂无证据数据</p>
                </div>
              )}
            </div>
          </div>

          {/* 中间：文章内容 */}
          <div className={`${isRightPanelOpen ? 'col-span-6' : 'col-span-7'} overflow-y-auto max-h-[calc(100vh-200px)]`}>
            <div className="bg-white rounded-lg border p-6">
              {generatedContent ? (
                <div className="max-w-none">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => <h1 className="text-3xl font-bold text-gray-900 mb-6 mt-8 first:mt-0">{children}</h1>,
                      h2: ({ children }) => <h2 className="text-2xl font-semibold text-gray-800 mb-4 mt-8 first:mt-0">{children}</h2>,
                      h3: ({ children }) => <h3 className="text-xl font-medium text-gray-800 mb-3 mt-6 first:mt-0">{children}</h3>,
                      h4: ({ children }) => <h4 className="text-lg font-medium text-gray-800 mb-2 mt-4">{children}</h4>,
                      h5: ({ children }) => <h5 className="text-base font-medium text-gray-800 mb-2 mt-4">{children}</h5>,
                      h6: ({ children }) => <h6 className="text-sm font-medium text-gray-800 mb-2 mt-4">{children}</h6>,
                      p: ({ children }) => {
                        // 对段落文本进行锚文本替换
                        if (typeof children === 'string') {
                          const textWithLinks = applyCustomAnchorLinks(children, customAnchorLinks);
                          return <p className="text-gray-700 mb-4 leading-relaxed">{textWithLinks}</p>;
                        }
                        return <p className="text-gray-700 mb-4 leading-relaxed">{children}</p>;
                      },
                      ul: ({ children }) => <ul className="list-disc list-inside mb-4 text-gray-700 space-y-1">{children}</ul>,
                      ol: ({ children }) => <ol className="list-decimal list-inside mb-4 text-gray-700 space-y-1">{children}</ol>,
                      li: ({ children }) => <li className="text-gray-700">{children}</li>,
                      blockquote: ({ children }) => <blockquote className="border-l-4 border-blue-300 bg-blue-50 pl-4 py-2 italic text-gray-700 mb-4">{children}</blockquote>,
                      code: ({ children, ...props }) => {
                        const match = /language-(\w+)/.exec(props.className || '')
                        const isInline = !props.className
                        if (isInline) {
                          return <code className="bg-gray-100 text-gray-800 px-1 py-0.5 rounded text-sm font-mono">{children}</code>
                        }
                        return <code className="block bg-gray-900 text-gray-100 p-4 rounded text-sm font-mono mb-4 overflow-x-auto">{children}</code>
                      },
                      pre: ({ children }) => <pre className="bg-gray-900 text-gray-100 p-4 rounded text-sm font-mono mb-4 overflow-x-auto">{children}</pre>,
                      strong: ({ children }) => <strong className="font-semibold text-gray-900">{children}</strong>,
                      em: ({ children }) => <em className="italic text-gray-700">{children}</em>,
                      a: ({ children, href }) => {
                        // 确保 href 是完整的 URL
                        const fullHref = href?.startsWith('http') ? href : `https://${href}`;
                        return (
                          <a 
                            href={fullHref} 
                            className="text-blue-600 hover:text-blue-800 underline"
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            {children}
                          </a>
                        );
                      },
                      img: ({ src, alt }) => (
                        <img 
                          src={src} 
                          alt={alt || ''} 
                          className="max-w-full h-auto rounded mb-4"
                        />
                      ),
                      hr: () => <hr className="border-t border-gray-300 my-6" />,
                      table: ({ children }) => (
                        <div className="overflow-x-auto mb-4">
                          <table className="min-w-full border border-gray-300">
                            {children}
                          </table>
                        </div>
                      ),
                      thead: ({ children }) => <thead className="bg-gray-50">{children}</thead>,
                      tbody: ({ children }) => <tbody>{children}</tbody>,
                      tr: ({ children }) => <tr>{children}</tr>,
                      th: ({ children }) => <th className="px-4 py-2 text-left font-medium text-gray-900 border-b">{children}</th>,
                      td: ({ children }) => <td className="px-4 py-2 text-gray-700 border-b">{children}</td>
                    }}
                  >
                    {(() => {
                      const cleaned = cleanGeneratedContent(generatedContent);
                      const withLinks = applyCustomAnchorLinks(cleaned, customAnchorLinks);
                      console.log('最终渲染的内容:', withLinks.substring(0, 200) + '...');
                      return withLinks;
                    })()}
                  </ReactMarkdown>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-8 h-8 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
                  </div>
                  <p className="text-gray-600">正在生成文章内容...</p>
                  <p className="text-sm text-gray-500 mt-2">{stepMessage}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 右侧面板切换按钮 */}
      <button
        onClick={() => setIsRightPanelOpen(!isRightPanelOpen)}
        className={`fixed z-30 top-1/2 transform -translate-y-1/2 transition-all duration-300 bg-white border border-gray-200 rounded-l-lg p-2 shadow-md hover:bg-gray-50 focus:outline-none ${
          isRightPanelOpen ? 'right-[384px]' : 'right-0'
        }`}
        aria-label={isRightPanelOpen ? '收起侧边栏' : '展开侧边栏'}
      >
        <svg
          className={`w-4 h-4 text-gray-600 transform transition-transform duration-300 ${
            isRightPanelOpen ? 'rotate-0' : 'rotate-180'
          }`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>

      {/* 右侧：生成步骤 (抽屉样式) */}
      <div 
        className={`fixed bg-white overflow-y-auto z-20 flex-shrink-0 p-6 rounded-l-lg border-l border-t border-b border-gray-200 transition-all duration-300 ease-in-out ${
          isRightPanelOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ 
          top: `${topOffsetPx}px`, 
          right: `0px`,
          width: `${sidebarWidthPx}px`, 
          height: `calc(100vh - ${topOffsetPx}px - ${bottomOffsetPx}px)`,
        }}
      >
        <div className="h-full">
          <div className="space-y-3">
            {[
              {
                step: ArticleDraftStep.GENERATE_CONTENT,
                title: '根据知识总结及生成要求逐段生成内容',
                timeEstimate: '100-150 秒'
              },
              {
                step: ArticleDraftStep.SEARCH_IMAGES,
                title: '为文章搜索合适的配图',
                timeEstimate: '30-60 秒'
              },
              {
                step: ArticleDraftStep.INSERT_LINKS,
                title: '查找并插入内部和外部链接以及锚文本',
                timeEstimate: '60-90 秒'
              },
              {
                step: ArticleDraftStep.GENERATE_META,
                title: '为文章页面生成元描述信息',
                timeEstimate: '20-30 秒'
              }
            ].map((item, index) => {
              const status = getStepStatus(item.step)
              let progressText = "正在处理...";
              let progressPercentage = 0;
              let showProgressDetails = false;
              if (item.step === ArticleDraftStep.GENERATE_CONTENT && status === 'current' && isGenerating && generatedOutline) {
                const totalH2Sections = generatedOutline.sections.length;
                const totalGenerationUnits = totalH2Sections + 2;
                let currentGenerationUnit = 0;
                if (stepMessage.startsWith('Generating article introduction...')) {
                  currentGenerationUnit = 1;
                  progressText = `生成引言 (1/${totalGenerationUnits})`;
                } else if (stepMessage.startsWith('Generating section ')) {
                  const match = stepMessage.match(/Generating section (\d+):/);
                  if (match && match[1]) {
                    const sectionNumber = parseInt(match[1], 10);
                    currentGenerationUnit = 1 + sectionNumber;
                    progressText = `生成段落 ${sectionNumber}/${totalH2Sections} (共 ${totalGenerationUnits} 单元)`;
                  }
                } else if (stepMessage.startsWith('Generating article conclusion...')) {
                  currentGenerationUnit = totalGenerationUnits;
                  progressText = `生成结论 (${totalGenerationUnits}/${totalGenerationUnits})`;
                } else if (stepMessage.startsWith('Generating article content in sections...') || !stepMessage) {
                   progressText = '准备生成内容...';
                   currentGenerationUnit = 0;
                } else {
                   progressText = stepMessage.substring(0, 30) + "..."; 
                }
                if (totalGenerationUnits > 0) {
                    progressPercentage = (currentGenerationUnit / totalGenerationUnits) * 100;
                }
                showProgressDetails = true;
              }
              return (
                <div key={item.step} className="flex items-start">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs mr-2 flex-shrink-0 ${
                    status === 'completed' ? 'bg-green-100 text-green-600' :
                    status === 'current' ? 'bg-blue-500 text-white' :
                    'bg-gray-200 text-gray-600'
                  }`}>
                    {status === 'completed' ? <CheckCircle className="w-4 h-4" /> : index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className={`text-xs mb-1 leading-tight ${
                      status === 'completed' ? 'text-gray-500' :
                      status === 'current' ? 'text-blue-900' :
                      'text-gray-600'
                    }`}>
                      {item.title}
                    </h5>
                    {status === 'current' && isGenerating && (
                      <div className="space-y-1">
                        {showProgressDetails && item.step === ArticleDraftStep.GENERATE_CONTENT ? (
                          <>
                            <div className="w-full bg-gray-200 rounded-full h-1">
                              <div 
                                className="bg-blue-500 h-1 rounded-full transition-all duration-300 ease-linear" 
                                style={{ width: `${progressPercentage}%` }}
                              ></div>
                            </div>
                            <p className="text-xs text-gray-600">
                              <span className="flex items-center">
                                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse mr-1"></span>
                                {progressText}
                              </span>
                            </p>
                          </>
                        ) : (
                          <div className="flex items-center mt-1">
                            <div className="w-3 h-3 border-2 border-blue-200 border-t-blue-500 rounded-full animate-spin mr-1.5"></div>
                            <span className="text-xs text-blue-600">正在处理...</span>
                          </div>
                        )}
                        <p className="text-xs text-gray-500">
                          大约需要 {item.timeEstimate}。
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
} 
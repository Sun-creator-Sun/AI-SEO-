"use client"

import { useState } from 'react'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { SearchResult, BlogIdea, SearchIntent } from '@/lib/google-search'
import { UrlAnalysisResult } from '@/lib/url-knowledge-extraction'
import UrlKnowledgeModal from '@/components/ui/url-knowledge-modal'
import KnowledgeBaseModal from '@/components/ui/knowledge-base-modal'
import { BlogIdeasSkeleton } from '@/components/ui/loading-skeletons'

interface BlogIdeasPageProps {
  keyword: string
  targetMarket: string
  targetLanguage: string
  searchResults: SearchResult[]
  blogIdeas: BlogIdea[]
  searchIntent: SearchIntent | null
  customIdea: string
  setCustomIdea: (value: string) => void
  selectedIdeaIndex: number | null
  onIdeaSelect: (index: number) => void
  additionalInfo: string
  setAdditionalInfo: (value: string) => void
  additionalRequirements: string
  setAdditionalRequirements: (value: string) => void
  autoInsertLSI: boolean
  setAutoInsertLSI: (value: boolean) => void
  // 知识来源相关props
  knowledgeSource: string
  setKnowledgeSource: (value: string) => void
  // 加载状态
  isLoading?: boolean
}

/**
 * 博客创意页面组件
 */
export default function BlogIdeasPage({
  keyword,
  targetMarket,
  targetLanguage,
  searchResults,
  blogIdeas,
  searchIntent,
  customIdea,
  setCustomIdea,
  selectedIdeaIndex,
  onIdeaSelect,
  additionalInfo,
  setAdditionalInfo,
  additionalRequirements,
  setAdditionalRequirements,
  autoInsertLSI,
  setAutoInsertLSI,
  // 知识来源相关props
  knowledgeSource,
  setKnowledgeSource,
  // 加载状态
  isLoading = false
}: BlogIdeasPageProps) {
  
  // URL知识提取弹窗状态
  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false)
  // AI知识库弹窗状态
  const [isKnowledgeBaseModalOpen, setIsKnowledgeBaseModalOpen] = useState(false)
  // 提取的产品图片状态
  const [extractedProductImage, setExtractedProductImage] = useState<string | null>(null)
  // 图片加载状态
  const [imageLoading, setImageLoading] = useState(false)
  const [imageError, setImageError] = useState(false)
  // 示例弹窗状态
  const [showExamplesModal, setShowExamplesModal] = useState(false)

  /**
   * 处理URL知识提取完成
   * @param result 分析结果文本
   * @param analysisData 完整的分析数据
   */
  const handleUrlAnalysisComplete = (result: string, analysisData?: UrlAnalysisResult) => {
    // 将分析结果添加到现有的附加信息中
    const newAdditionalInfo = additionalInfo 
      ? `${additionalInfo}\n\n--- URL提取的知识 ---\n${result}`
      : result
    
    setAdditionalInfo(newAdditionalInfo)
    
    // 如果有产品图片，设置图片状态
    if (analysisData?.productImage) {
      setExtractedProductImage(analysisData.productImage)
      setImageLoading(true)
      setImageError(false)
    }
  }

  /**
   * 清除提取的产品图片
   */
  const handleClearProductImage = () => {
    setExtractedProductImage(null)
    setImageLoading(false)
    setImageError(false)
  }

  /**
   * 处理图片加载完成
   */
  const handleImageLoad = () => {
    setImageLoading(false)
    setImageError(false)
  }

  /**
   * 处理图片加载错误
   */
  const handleImageError = () => {
    setImageLoading(false)
    setImageError(true)
  }

  /**
   * 打开URL知识提取弹窗
   */
  const handleOpenUrlModal = () => {
    setIsUrlModalOpen(true)
  }

  /**
   * 关闭URL知识提取弹窗
   */
  const handleCloseUrlModal = () => {
    setIsUrlModalOpen(false)
  }

  /**
   * 打开AI知识库弹窗
   */
  const handleOpenKnowledgeBaseModal = () => {
    setIsKnowledgeBaseModalOpen(true)
  }

  /**
   * 关闭AI知识库弹窗
   */
  const handleCloseKnowledgeBaseModal = () => {
    setIsKnowledgeBaseModalOpen(false)
  }

  /**
   * 处理从知识库提取的知识
   * @param knowledge 提取的知识内容
   */
  const handleKnowledgeExtracted = (knowledge: string) => {
    // 将提取的知识添加到知识来源字段中
    const newKnowledgeSource = knowledgeSource 
      ? `${knowledgeSource}\n\n--- AI知识库提取 ${new Date().toLocaleString('zh-CN')} ---\n${knowledge}`
      : `--- AI知识库提取 ${new Date().toLocaleString('zh-CN')} ---\n${knowledge}`
    
    setKnowledgeSource(newKnowledgeSource)
  }

  /**
   * 解析博客标题并高亮关键部分
   */
  const parseAndHighlightTitle = (title: string) => {
    // 匹配格式：Write a 'Type' blog post on 'Title'
    const match = title.match(/Write a '([^']+)' blog post on '([^']+)'/);
    
    if (match) {
      const [, type, actualTitle] = match;
      return (
        <span>
          Write a <span className="bg-blue-100 text-blue-800 px-1 rounded font-medium">'{type}'</span> blog post on{' '}
          <span className="bg-yellow-100 text-yellow-800 px-1 rounded font-medium">'{actualTitle}'</span>
        </span>
      );
    }
    
    // 如果不匹配标准格式，直接返回原标题
    return <span>{title}</span>;
  }

  /**
   * 根据博客想法类型判断是商业型还是信息型
   */
  const getIdeaCategory = (type: string) => {
    // 商业型：主要用于推广、比较、评测、推荐产品/服务
    const commercialTypes = ['Listicle', 'Comparison', 'Review', 'Tips'];
    // 信息型：主要用于教育、解释、指导
    const informationalTypes = ['How', 'Why', 'Guide', 'Trends'];
    
    if (commercialTypes.includes(type)) {
      return {
        label: 'C',
        fullName: '商业型',
        className: 'bg-orange-100 text-orange-800'
      };
    } else if (informationalTypes.includes(type)) {
      return {
        label: 'I', 
        fullName: '信息型',
        className: 'bg-green-100 text-green-800'
      };
    } else {
      return {
        label: 'I',
        fullName: '信息型', 
        className: 'bg-gray-100 text-gray-800'
      };
    }
  }

  /**
   * 打开示例要求弹窗
   */
  const handleShowExamples = () => {
    setShowExamplesModal(true)
  }

  /**
   * 关闭示例要求弹窗
   */
  const handleCloseExamples = () => {
    setShowExamplesModal(false)
  }

  // 如果正在加载，显示骨架屏
  if (isLoading) {
    return <BlogIdeasSkeleton />
  }

  return (
    <div className="h-full">
      <div className="max-w-6xl mx-auto h-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* 左侧：关键词信息、搜索意图和参考资料 */}
          <div className="lg:col-span-1 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 关键词信息 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <div className="flex items-center mb-3">
                <span className="text-sm text-blue-600">关键词</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{keyword}</h2>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-3">🇺🇸 {targetMarket}</span>
                  <span>🌐 {targetLanguage}</span>
                </div>
              </div>
            </div>

            {/* 搜索意图 */}
            {searchIntent && (
              <div className="bg-white rounded-lg border p-4 mb-6">
                <h4 className="font-medium text-gray-900 mb-3">搜索意图</h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700">{searchIntent.intent}</span>
                      <span className="text-xs text-gray-500">{searchIntent.confidence}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${searchIntent.confidence}%` }}
                      ></div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{searchIntent.description}</p>
                  
                  {/* 意图列表 */}
                  <div className="space-y-1">
                    <h5 className="text-xs font-medium text-gray-700 mb-2">具体意图：</h5>
                    <ul className="space-y-1">
                      {searchIntent.intentList.map((intentItem, index) => (
                        <li key={index} className="text-xs text-gray-600 flex items-start">
                          <span className="w-1 h-1 bg-gray-400 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                          <span>{intentItem}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* 参考资料 */}
            <div className="bg-white rounded-lg border p-4">
              <h4 className="font-medium text-gray-900 mb-3">参考资料 ({searchResults.length})</h4>
              <div className="space-y-3">
                {searchResults.map((result, index) => (
                  <div key={index} className="border-l-2 border-gray-200 pl-3">
                    <div className="flex items-start space-x-2">
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded flex-shrink-0">
                        {result.originalIndex || index + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <a 
                          href={result.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-sm font-medium text-blue-600 hover:text-blue-800 cursor-pointer line-clamp-2 block"
                        >
                          {result.title}
                        </a>
                        <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                          {result.snippet}
                        </p>
                        <span className="text-xs text-green-600 mt-1 inline-block">
                          {new URL(result.url).hostname}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 右侧：选择想法和附加信息 */}
          <div className="lg:col-span-2 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 选择一个想法区域 */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold mb-6">选择一个想法</h3>
              
              {/* 推荐的想法 */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 mb-3">推荐的想法</h4>
                <div className="space-y-3">
                  {blogIdeas.map((idea, index) => (
                    <div 
                      key={index} 
                      onClick={() => onIdeaSelect(index)}
                      className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 ${
                        selectedIdeaIndex === index 
                          ? 'border-blue-500 bg-blue-50 shadow-md ring-2 ring-blue-200' 
                          : 'border-gray-200 hover:bg-gray-50 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <span className={`px-2 py-1 text-xs rounded-full mr-2 ${
                              idea.type === 'Listicle' ? 'bg-yellow-100 text-yellow-800' :
                              idea.type === 'How-to-Guide' ? 'bg-blue-100 text-blue-800' :
                              idea.type === 'Comparison' ? 'bg-purple-100 text-purple-800' :
                              idea.type === 'Why' ? 'bg-green-100 text-green-800' :
                              idea.type === 'Tips' ? 'bg-orange-100 text-orange-800' :
                              idea.type === 'Case-Study' ? 'bg-indigo-100 text-indigo-800' :
                              idea.type === 'FAQ' ? 'bg-cyan-100 text-cyan-800' :
                              idea.type === 'Trends' ? 'bg-pink-100 text-pink-800' :
                              idea.type === 'Review' ? 'bg-red-100 text-red-800' :
                              idea.type === 'Myth-Busting' ? 'bg-gray-100 text-gray-800' :
                              idea.type === 'Infographic' ? 'bg-teal-100 text-teal-800' :
                              idea.type === 'Expert-Interview' ? 'bg-violet-100 text-violet-800' :
                              idea.type === 'Resource-Roundup' ? 'bg-emerald-100 text-emerald-800' :
                              idea.type === 'Personal-Story' ? 'bg-rose-100 text-rose-800' :
                              idea.type === 'Template-Checklist' ? 'bg-amber-100 text-amber-800' :
                              'bg-slate-100 text-slate-800'
                            }`}>
                              {idea.type}
                            </span>
                            <span className="text-sm text-gray-500">博客文章关于 '{idea.keywords[0]}'</span>
                          </div>
                          <h5 className="font-medium text-gray-900 mb-1 leading-relaxed">
                            {parseAndHighlightTitle(idea.title)}
                          </h5>
                          {selectedIdeaIndex === index && (
                            <p className="text-sm text-gray-600 mt-2 pt-2 border-t border-gray-200">
                              {idea.description}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          {selectedIdeaIndex === index && (
                            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">✓ 已选中</span>
                          )}
                          {(() => {
                            const category = getIdeaCategory(idea.type);
                            return (
                              <span 
                                className={`text-xs px-2 py-1 rounded font-medium ${category.className}`}
                                title={category.fullName}
                              >
                                {category.label}
                              </span>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 或者输入您的想法 */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">或者输入您的想法</h4>
                <div className="border border-gray-200 rounded-lg p-4">
                  <Input
                    placeholder="写一篇关于SEO认证课程的学习博客文章"
                    value={customIdea}
                    onChange={(e) => setCustomIdea(e.target.value)}
                    className="mb-3"
                    maxLength={500}
                  />
                  <div className="text-right text-sm text-gray-400">
                    {customIdea.length}/500
                  </div>
                </div>
              </div>
            </div>

            {/* 附加信息区域 */}
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-6">附加信息（品牌/产品/场景）</h4>
              
              <div className="space-y-6">
                {/* 文本内容 */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700">📄 文本内容</span>
                    <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800" onClick={handleOpenUrlModal}>
                      🔗 从URL提取
                    </Button>
                  </div>
                  <textarea
                    placeholder="与主题相关的补充知识"
                    value={additionalInfo}
                    onChange={(e) => setAdditionalInfo(e.target.value)}
                    className="w-full h-24 p-3 border border-gray-200 rounded-lg resize-none text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                    maxLength={50000}
                  />
                  <div className="text-right text-xs text-gray-400 mt-1">
                    {additionalInfo.length}/50000
                  </div>
                </div>

                {/* 提取的产品图片 */}
                {extractedProductImage && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-gray-700">🖼️ 提取的产品图片</span>
                      <button
                        onClick={handleClearProductImage}
                        className="text-xs text-red-600 hover:text-red-800 flex items-center space-x-1"
                      >
                        <span>🗑️</span>
                        <span>移除</span>
                      </button>
                    </div>
                    <div className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 relative">
                          {imageLoading && (
                            <div className="w-20 h-20 bg-gray-200 rounded-lg border border-gray-300 flex items-center justify-center">
                              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                            </div>
                          )}
                          {imageError && (
                            <div className="w-20 h-20 bg-gray-100 rounded-lg border border-gray-300 flex items-center justify-center">
                              <span className="text-gray-400 text-xs">❌</span>
                            </div>
                          )}
                          {!imageError && (
                            <div className="relative w-20 h-20">
                              <Image
                                src={extractedProductImage}
                                alt="Product"
                                fill
                                className={`object-cover rounded-lg border border-gray-300 ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
                                onLoad={handleImageLoad}
                                onError={handleImageError}
                                sizes="80px"
                                priority={false}
                              />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-gray-600 mb-2">
                            从URL提取的产品图片，可用于博客文章配图参考
                          </p>
                          {imageError && (
                            <p className="text-xs text-red-500 mb-2">
                              图片加载失败，请检查图片链接是否有效
                            </p>
                          )}
                          <div className="bg-white border border-gray-200 rounded p-2">
                            <p className="text-xs text-gray-500 break-all">
                              {extractedProductImage}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* AI 知识库 */}
                <div>
                  <div className="flex items-center mb-3">
                    <span className="text-sm font-medium text-gray-700">🧠 AI 知识库</span>
                    <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">New</span>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <span className="text-sm text-gray-600">📚 知识来源</span>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-purple-600 hover:text-purple-800"
                        onClick={handleOpenKnowledgeBaseModal}
                      >
                        ✨ 提取知识
                      </Button>
                    </div>
                    
                    {/* 知识来源内容 */}
                    {knowledgeSource ? (
                      <div className="space-y-3">
                        <textarea
                          placeholder="从企业知识库中提取的相关知识..."
                          value={knowledgeSource}
                          onChange={(e) => setKnowledgeSource(e.target.value)}
                          className="w-full h-32 p-3 border border-gray-200 rounded-lg resize-none text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
                          maxLength={10000}
                        />
                        <div className="flex items-center justify-between">
                          <div className="text-right text-xs text-gray-400">
                            {knowledgeSource.length}/10000
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-red-600 hover:text-red-800 text-xs"
                              onClick={() => setKnowledgeSource('')}
                            >
                              🗑️ 清空
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-purple-600 hover:text-purple-800 text-xs"
                              onClick={handleOpenKnowledgeBaseModal}
                            >
                              ➕ 继续提取
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-4">
                        <div className="text-gray-400 mb-2">📖</div>
                        <p className="text-sm text-gray-500 mb-4">
                          从企业知识库中提取相关知识，为博客文章提供专业素材
                        </p>
                        <Button 
                          className="bg-purple-600 hover:bg-purple-700 text-white"
                          onClick={handleOpenKnowledgeBaseModal}
                        >
                          选择知识库
                        </Button>
                      </div>
                    )}
                  </div>
                </div>

                {/* 附加要求（标题生成） */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700">📝 附加要求（标题生成）</span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-800 text-xs"
                      onClick={handleShowExamples}
                    >
                      示例
                    </Button>
                  </div>
                  <textarea
                    placeholder="输入您对生成标题的要求，例如：每个生成的标题必须包含我们的品牌名称：XXXXX。"
                    value={additionalRequirements}
                    onChange={(e) => setAdditionalRequirements(e.target.value)}
                    className="w-full h-20 p-3 border border-gray-200 rounded-lg resize-none text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                    maxLength={3000}
                  />
                  <div className="text-right text-xs text-gray-400 mt-1">
                    {additionalRequirements.length}/3000
                  </div>
                </div>

                {/* 自动插入LSI术语选项 */}
                <div className=" border-gray-300">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="autoInsertLSI"
                      checked={autoInsertLSI}
                      onChange={(e) => setAutoInsertLSI(e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <label htmlFor="autoInsertLSI" className="ml-2 text-sm font-medium text-gray-900">
                      🔧 自动插入LSI术语
                    </label>
                    <span className="ml-2 relative inline-block group cursor-help">
                      <svg className="w-4 h-4 text-blue-500 hover:text-blue-600 transition-colors" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                      </svg>
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none w-80 z-10">
                        <div className="text-left">
                          激活此功能后，我们会进行SERPs分析，将相关关键词自动嵌入到您的博客中，包含在标题、大纲和文章内容中。这可以确保您的文章不仅针对搜索引擎进行了优化，而且与目标受众搜索的内容紧密相关。使您的内容更易被发现并且更具有吸引力。
                        </div>
                        {/* Tooltip Arrow */}
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 ml-6">
                    自动在生成的内容中插入语义相关的关键词，提升SEO效果
                  </p>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
      {isUrlModalOpen && (
        <UrlKnowledgeModal
          isOpen={isUrlModalOpen}
          onClose={handleCloseUrlModal}
          onAnalysisComplete={handleUrlAnalysisComplete}
        />
      )}
      {isKnowledgeBaseModalOpen && (
        <KnowledgeBaseModal
          isOpen={isKnowledgeBaseModalOpen}
          onClose={handleCloseKnowledgeBaseModal}
          onKnowledgeExtracted={handleKnowledgeExtracted}
        />
      )}

      {/* 示例要求弹窗 */}
      {showExamplesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full m-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">📝 附加要求示例</h3>
              <button
                onClick={handleCloseExamples}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="space-y-4">
              <p className="text-sm text-gray-600 mb-4">
                以下是一些常用的标题生成要求示例，您可以参考并根据需要调整：
              </p>
              
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg border">
                  <div className="flex items-start">
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-3 mt-0.5">1</span>
                    <p className="text-sm text-gray-700">
                      每个生成的标题必须包含关键词 "seo"
                    </p>
                  </div>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg border">
                  <div className="flex items-start">
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded mr-3 mt-0.5">2</span>
                    <p className="text-sm text-gray-700">
                      每个生成的标题必须包含年份 "2024"
                    </p>
                  </div>
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg border">
                  <div className="flex items-start">
                    <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded mr-3 mt-0.5">3</span>
                    <p className="text-sm text-gray-700">
                      每个生成标题的长度必须控制在12个词以内
                    </p>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg border">
                  <div className="flex items-start">
                    <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded mr-3 mt-0.5">4</span>
                    <p className="text-sm text-gray-700">
                      确保标题使用吸引眼球的词汇或短语。避免过长或复杂的句子结构，力求清晰简洁地表达主题
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-900 mb-2">💡 更多示例：</h4>
                <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>每个标题必须包含我们的品牌名称：XXXXX</li>
                  <li>标题必须体现产品的核心价值主张</li>
                  <li>避免使用技术术语，使用通俗易懂的语言</li>
                  <li>标题要有紧迫感或行动导向</li>
                  <li>包含数字或具体数据以增加可信度</li>
                </ul>
              </div>
            </div>
            
            <div className="flex justify-end mt-6">
              <Button onClick={handleCloseExamples} className="bg-blue-600 hover:bg-blue-700 text-white">
                知道了
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
} 
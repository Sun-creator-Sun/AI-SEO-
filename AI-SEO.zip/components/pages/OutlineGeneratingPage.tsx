"use client"

import { CheckCircle, AlertCircle, RefreshCw } from 'lucide-react'
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'

/**
 * 大纲生成子步骤枚举
 */
enum OutlineGenerationSubStep {
  EXTRACTING_CONTENT = 1,
  ANALYZING_OUTLINES = 2,
  SYNTHESIZING_ANALYSIS = 3,
  GENERATING_OUTLINE = 4
}

interface OutlineGeneratingPageProps {
  outlineGenerationStep: OutlineGenerationSubStep
  outlineGenerationProgress: number
  error?: string | null
  onRetry?: () => void
}

/**
 * 大纲生成进度页面组件
 */
export default function OutlineGeneratingPage({
  outlineGenerationStep,
  outlineGenerationProgress,
  error,
  onRetry
}: OutlineGeneratingPageProps) {
  
  /**
   * 获取当前步骤文本
   */
  const getStepText = () => {
    switch (outlineGenerationStep) {
      case OutlineGenerationSubStep.EXTRACTING_CONTENT:
        return '抓取引用文章内容';
      case OutlineGenerationSubStep.ANALYZING_OUTLINES:
        return '提炼并分析每篇文章的大纲和风格';
      case OutlineGenerationSubStep.SYNTHESIZING_ANALYSIS:
        return '分析文章';
      case OutlineGenerationSubStep.GENERATING_OUTLINE:
        return '根据提取的知识和要求生成文章大纲';
      default:
        return '正在处理...';
    }
  };

  /**
   * 获取当前步骤状态文本
   */
  const getStepStatusText = () => {
    switch (outlineGenerationStep) {
      case OutlineGenerationSubStep.EXTRACTING_CONTENT:
        return '正在抓取内容';
      case OutlineGenerationSubStep.ANALYZING_OUTLINES:
        return '正在提炼分析';
      case OutlineGenerationSubStep.SYNTHESIZING_ANALYSIS:
        return '获取和分析参考文章的词汇分布';
      case OutlineGenerationSubStep.GENERATING_OUTLINE:
        return '正在生成文章大纲';
      default:
        return '正在处理...';
    }
  };

  /**
   * 获取步骤标签
   */
  const getStepLabels = () => [
    '抓取内容',
    '分析大纲', 
    '综合分析',
    '生成大纲'
  ];

  /**
   * 获取当前步骤的时间估计
   */
  const getStepTimeEstimate = () => {
    switch (outlineGenerationStep) {
      case OutlineGenerationSubStep.EXTRACTING_CONTENT:
        return '大约需要 10-30 秒';
      case OutlineGenerationSubStep.ANALYZING_OUTLINES:
        return '大约需要 60-90 秒';
      case OutlineGenerationSubStep.SYNTHESIZING_ANALYSIS:
        return '大约需要 90-120 秒';
      case OutlineGenerationSubStep.GENERATING_OUTLINE:
        return '大约需要 60-90 秒';
      default:
        return '正在处理...';
    }
  };

  /**
   * 获取错误提示信息
   */
  const getErrorSuggestion = () => {
    if (!error) return '';
    
    if (error.includes('API_KEY') || error.includes('key')) {
      return '请检查API密钥配置是否正确，或联系管理员确认API密钥状态。';
    } else if (error.includes('network') || error.includes('fetch')) {
      return '请检查网络连接是否正常，或稍后重试。';
    } else if (error.includes('quota') || error.includes('limit')) {
      return 'API配额已用完，请稍后重试或联系管理员。';
    } else if (error.includes('JSON') || error.includes('解析')) {
      return 'AI响应格式异常，请重试。如果问题持续存在，请联系技术支持。';
    } else {
      return '请重试或返回上一步检查输入信息。如果问题持续存在，请联系技术支持。';
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="mb-8">
        {/* 错误提示 */}
        {error && (
          <Alert variant="destructive" className="mb-6 text-left">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>大纲生成失败</AlertTitle>
            <AlertDescription className="mt-2">
              <div className="mb-3">
                <strong>错误详情：</strong>
                <p className="mt-1 text-sm">{error}</p>
              </div>
              <div className="mb-3">
                <strong>建议解决方案：</strong>
                <p className="mt-1 text-sm">{getErrorSuggestion()}</p>
              </div>
              {onRetry && (
                <div className="mt-4">
                  <Button 
                    onClick={onRetry}
                    variant="outline"
                    size="sm"
                    className="mr-2"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    重试
                  </Button>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* 步骤指示器 */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 text-sm font-medium ${
                    step < outlineGenerationStep ? 'bg-green-500 text-white' :
                    step === outlineGenerationStep ? 'bg-blue-500 text-white' :
                    'bg-gray-200 text-gray-400'
                  }`}>
                    {step < outlineGenerationStep ? <CheckCircle className="w-5 h-5" /> : step}
                  </div>
                  <span className={`text-xs font-medium ${
                    step === outlineGenerationStep ? 'text-blue-600' : 
                    step < outlineGenerationStep ? 'text-green-600' : 'text-gray-400'
                  }`}>
                    {getStepLabels()[step - 1]}
                  </span>
                </div>
                {step < 4 && (
                  <div className={`w-12 h-1 mx-3 ${
                    step < outlineGenerationStep ? 'bg-green-500' : 'bg-gray-200'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 当前步骤内容 */}
        {!error && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              {getStepText()}
            </h2>
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              {getStepStatusText()}
            </h3>
            <p className="text-gray-600">
              {getStepTimeEstimate()}
            </p>
            
            {/* 进度条 */}
            <div className="mt-6">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${outlineGenerationProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500 mt-2">
                进度: {outlineGenerationProgress}%
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export { OutlineGenerationSubStep } 
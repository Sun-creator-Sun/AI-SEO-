"use client"

import { Button } from '@/components/ui/button'
import { FileText, Clock, Users, MessageSquare, Eye } from 'lucide-react'
import { BlogOutline, ArticleAnalysis, SearchResult } from '@/lib/google-search'

interface OutlinePageProps {
  keyword: string
  targetMarket: string
  targetLanguage: string
  selectedTitle: string
  generatedOutline: BlogOutline | null
  articleAnalyses: ArticleAnalysis[]
  synthesisReport: string
  extractedContents: string[]
  filteredBlogContent: SearchResult[]
}

/**
 * 大纲展示页面组件
 */
export default function OutlinePage({
  keyword,
  targetMarket,
  targetLanguage,
  selectedTitle,
  generatedOutline,
  articleAnalyses,
  synthesisReport,
  extractedContents,
  filteredBlogContent
}: OutlinePageProps) {
  
  /**
   * 计算总预估字数
   */
  const getTotalEstimatedWords = () => {
    if (!generatedOutline) return 0;
    return generatedOutline.sections.reduce((total, section) => total + section.estimatedWords, 0);
  };

  return (
    <div className="h-full">
      <div className="max-w-6xl mx-auto h-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* 左侧：关键词信息和分析数据 */}
          <div className="lg:col-span-1 overflow-y-auto max-h-[calc(100vh-200px)]">
            {/* 关键词信息 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <div className="flex items-center mb-3">
                <span className="text-sm text-blue-600">关键词</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{keyword}</h2>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-3">🇺🇸 {targetMarket}</span>
                  <span>🌐 {targetLanguage}</span>
                </div>
              </div>
            </div>

            {/* 选中的标题 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-3">选中的标题</h4>
              <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
                {selectedTitle}
              </div>
            </div>

            {/* 参考资料 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-3">
                参考资料 ({filteredBlogContent.length})
              </h4>
              <p className="text-xs text-gray-500 mb-3">从参考文章中选择与所选想法最相关的文章。</p>
              <div className="space-y-3">
                {filteredBlogContent.length > 0 ? (
                  filteredBlogContent.map((content, index) => (
                    <div key={index} className="border-l-2 border-blue-200 pl-3">
                      <div className="flex items-start space-x-2">
                        <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded flex-shrink-0">
                          {content.originalIndex || index + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <a 
                            href={content.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm font-medium text-blue-600 hover:text-blue-800 cursor-pointer line-clamp-2 block"
                          >
                            {content.title}
                          </a>
                          <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                            {content.snippet}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">暂无参考资料</p>
                    <p className="text-xs mt-1">正在从搜索结果中筛选相关内容...</p>
                  </div>
                )}
              </div>
            </div>

            {/* 抓取的文章内容 */}
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-3">抓取的文章内容 ({extractedContents.length})</h4>
              <div className="space-y-3 max-h-48 overflow-y-auto">
                {extractedContents.length > 0 ? (
                  extractedContents.slice(0, 3).map((content, index) => (
                    <div key={index} className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                      {content.substring(0, 150)}...
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">暂无抓取的文章内容</p>
                  </div>
                )}
              </div>
            </div>

            {/* 文章分析结果 */}
            <div className="bg-white rounded-lg border p-4">
              <h4 className="font-medium text-gray-900 mb-3">文章分析结果 ({articleAnalyses.length})</h4>
              <div className="space-y-3 max-h-48 overflow-y-auto">
                {articleAnalyses.length > 0 ? (
                  articleAnalyses.slice(0, 3).map((analysis, index) => (
                    <div key={index} className="border-l-2 border-blue-200 pl-3">
                      <div className="text-sm font-medium text-gray-900">{analysis.title}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        风格: {analysis.style} | 语调: {analysis.tone}
                      </div>
                      <div className="text-xs text-gray-600 mt-1">
                        结构: {analysis.structure}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">暂无分析结果</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 右侧：生成的大纲 */}
          <div className="lg:col-span-2 overflow-y-auto max-h-[calc(100vh-200px)]">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">推荐大纲</h3>
              {generatedOutline && (
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{getTotalEstimatedWords()} 字</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    <span>{generatedOutline.readabilityLevel}</span>
                  </div>
                  <div className="flex items-center">
                    <MessageSquare className="w-4 h-4 mr-1" />
                    <span>{generatedOutline.toneStyle}</span>
                  </div>
                  <div className="flex items-center">
                    <Eye className="w-4 h-4 mr-1" />
                    <span>{generatedOutline.perspective}</span>
                  </div>
                </div>
              )}
            </div>
            
            {generatedOutline ? (
              <div className="bg-white rounded-lg border p-6">
                {/* 文章标题 */}
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    {generatedOutline.title}
                  </h1>
                  <div className="flex flex-wrap gap-2">
                    {generatedOutline.seoKeywords.map((keyword, index) => (
                      <span key={index} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 引言 */}
                <div className="mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <span className="bg-blue-600 text-white text-sm px-2 py-1 rounded mr-2">引言</span>
                    Introduction
                  </h2>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-gray-700 text-sm leading-relaxed">
                      {generatedOutline.introduction}
                    </p>
                  </div>
                </div>

                {/* 主要章节 */}
                <div className="space-y-6 mb-6">
                  {generatedOutline.sections.map((section, index) => (
                    <div key={index} className="border-l-4 border-gray-200 pl-4">
                      <div className="flex items-center justify-between mb-3">
                        <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                          <span className="bg-gray-600 text-white text-sm px-2 py-1 rounded mr-2">H2</span>
                          {section.heading}
                        </h2>
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                          ~{section.estimatedWords} 字
                        </span>
                      </div>
                      
                      {/* 子标题 */}
                      {section.subheadings.length > 0 && (
                        <div className="mb-3">
                          <h4 className="text-sm font-medium text-gray-700 mb-2">子标题:</h4>
                          <div className="space-y-1">
                            {section.subheadings.map((subheading, subIndex) => (
                              <div key={subIndex} className="flex items-center text-sm text-gray-600">
                                <span className="bg-gray-400 text-white text-xs px-1.5 py-0.5 rounded mr-2">H3</span>
                                {subheading}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* 关键要点 */}
                      {section.keyPoints.length > 0 && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 mb-2">关键要点:</h4>
                          <ul className="space-y-1">
                            {section.keyPoints.map((point, pointIndex) => (
                              <li key={pointIndex} className="text-sm text-gray-600 flex items-start">
                                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                {point}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* 结论 */}
                <div className="mb-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <span className="bg-green-600 text-white text-sm px-2 py-1 rounded mr-2">结论</span>
                    Conclusion
                  </h2>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-gray-700 text-sm leading-relaxed">
                      {generatedOutline.conclusion}
                    </p>
                  </div>
                </div>

                {/* 大纲统计信息 */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">大纲统计</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">总字数:</span>
                      <span className="font-medium ml-1">{getTotalEstimatedWords()}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">章节数:</span>
                      <span className="font-medium ml-1">{generatedOutline.sections.length}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">可读性:</span>
                      <span className="font-medium ml-1">{generatedOutline.readabilityLevel}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">语气:</span>
                      <span className="font-medium ml-1">{generatedOutline.toneStyle}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg border p-8 text-center">
                <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">大纲生成中</h3>
                <p className="text-gray-500">正在根据分析结果生成定制化大纲...</p>
              </div>
            )}


          </div>
        </div>
      </div>
    </div>
  );
} 
import dynamic from 'next/dynamic'
import { Spinner } from '@/components/ui/spinner'
import { useLazyLoadPerformance } from '@/hooks/usePerformance'
import { 
  BlogIdeasSkeleton, 
  TitlesSkeleton, 
  OutlineSkeleton, 
  SettingsSkeleton,
  ArticleProgressSkeleton,
  ContentSkeleton
} from '@/components/ui/loading-skeletons'

const LoadingSpinner = () => (
  <div className="w-full h-full min-h-[400px] flex items-center justify-center">
    <Spinner size="lg" text="正在加载..." />
  </div>
)

// 懒加载的页面组件
export const LazyTitlesPage = dynamic(
  () => import('./TitlesPage'),
  {
    loading: () => <TitlesSkeleton />,
    ssr: false
  }
)

export const LazyOutlinePage = dynamic(
  () => import('./OutlinePage'),
  {
    loading: () => <OutlineSkeleton />,
    ssr: false
  }
)

export const LazySettingsPage = dynamic(
  () => import('./SettingsPage'),
  {
    loading: () => <SettingsSkeleton />,
    ssr: false
  }
)

export const LazyArticleDraftPage = dynamic(
  () => import('./ArticleDraftPage'),
  {
    loading: LoadingSpinner,
    ssr: false
  }
)

export const LazyTitleGeneratingPage = dynamic(
  () => import('./TitleGeneratingPage'),
  {
    loading: LoadingSpinner,
    ssr: false
  }
)

export const LazyOutlineGeneratingPage = dynamic(
  () => import('./OutlineGeneratingPage'),
  {
    loading: LoadingSpinner,
    ssr: false
  }
)

export const LazyArticleGenerationProgress = dynamic(
  () => import('./ArticleGenerationProgress'),
  {
    loading: LoadingSpinner,
    ssr: false
  }
) 
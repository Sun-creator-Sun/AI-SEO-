'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/toast';

interface APIKeyConfig {
  key: string;
  name: string;
  provider: 'gemini' | 'openai' | 'claude' | 'deepseek';
  rateLimit: {
    requestsPerMinute: number;
    requestsPerHour: number;
    requestsPerDay: number;
  };
  priority: number;
  enabled: boolean;
  lastUsed?: Date;
  errorCount: number;
  maxErrors: number;
  cooldownMinutes: number;
  rateLimitInfo?: {
    currentMinute: number;
    currentHour: number;
    currentDay: number;
    limitMinute: number;
    limitHour: number;
    limitDay: number;
  };
}

interface UsageStats {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  averageResponseTime: number;
  keyStats: Array<{
    key: string;
    name: string;
    requests: number;
    successRate: number;
    avgResponseTime: number;
  }>;
}

export default function APIKeyManagementPage() {
  const [keys, setKeys] = useState<APIKeyConfig[]>([]);
  const [stats, setStats] = useState<UsageStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newKey, setNewKey] = useState({
    key: '',
    name: '',
    provider: 'gemini' as const,
    rateLimit: {
      requestsPerMinute: 60,
      requestsPerHour: 1000,
      requestsPerDay: 10000
    },
    priority: 999
  });

  const fetchKeys = async () => {
    try {
      const response = await fetch('/api/keys');
      const data = await response.json();
      
      if (data.success) {
        setKeys(data.data.keys);
        setStats(data.data.stats);
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to fetch API keys',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch API keys',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKeys();
    // 每30秒刷新一次数据
    const interval = setInterval(fetchKeys, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleAddKey = async () => {
    try {
      const response = await fetch('/api/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newKey)
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: 'Success',
          description: 'API key added successfully'
        });
        setShowAddForm(false);
        setNewKey({
          key: '',
          name: '',
          provider: 'gemini',
          rateLimit: {
            requestsPerMinute: 60,
            requestsPerHour: 1000,
            requestsPerDay: 10000
          },
          priority: 999
        });
        fetchKeys();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to add API key',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add API key',
        variant: 'destructive'
      });
    }
  };

  const handleToggleKey = async (key: string, enabled: boolean) => {
    try {
      const response = await fetch('/api/keys', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, enabled })
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: 'Success',
          description: `API key ${enabled ? 'enabled' : 'disabled'} successfully`
        });
        fetchKeys();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to update API key',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update API key',
        variant: 'destructive'
      });
    }
  };

  const handleResetErrors = async (key: string) => {
    try {
      const response = await fetch('/api/keys', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, resetErrors: true })
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: 'Success',
          description: 'Error count reset successfully'
        });
        fetchKeys();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to reset errors',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to reset errors',
        variant: 'destructive'
      });
    }
  };

  const handleDeleteKey = async (key: string) => {
    if (!confirm('Are you sure you want to delete this API key?')) {
      return;
    }
    
    try {
      const response = await fetch(`/api/keys?key=${encodeURIComponent(key)}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: 'Success',
          description: 'API key deleted successfully'
        });
        fetchKeys();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to delete API key',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete API key',
        variant: 'destructive'
      });
    }
  };

  const getStatusBadge = (key: APIKeyConfig) => {
    if (!key.enabled) {
      return <Badge variant="secondary">Disabled</Badge>;
    }
    if (key.errorCount >= key.maxErrors) {
      return <Badge variant="destructive">Error Limit</Badge>;
    }
    if (key.rateLimitInfo) {
      const { currentMinute, limitMinute } = key.rateLimitInfo;
      const usagePercent = (currentMinute / limitMinute) * 100;
      if (usagePercent >= 90) {
        return <Badge variant="destructive">Rate Limited</Badge>;
      } else if (usagePercent >= 70) {
        return <Badge variant="default">High Usage</Badge>;
      }
    }
    return <Badge variant="default">Active</Badge>;
  };

  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'gemini': return 'bg-blue-100 text-blue-800';
      case 'openai': return 'bg-green-100 text-green-800';
      case 'claude': return 'bg-purple-100 text-purple-800';
      case 'deepseek': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Loading API key management...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">API Key Management</h1>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          {showAddForm ? 'Cancel' : 'Add New Key'}
        </Button>
      </div>

      {/* 统计信息 */}
      {stats && (
        <Card>
          <CardHeader>
            <CardTitle>Usage Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.totalRequests}</div>
                <div className="text-sm text-gray-600">Total Requests</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.successfulRequests}</div>
                <div className="text-sm text-gray-600">Successful</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{stats.failedRequests}</div>
                <div className="text-sm text-gray-600">Failed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{Math.round(stats.averageResponseTime)}ms</div>
                <div className="text-sm text-gray-600">Avg Response Time</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 添加新Key表单 */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New API Key</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="key">API Key</Label>
                <Input
                  id="key"
                  value={newKey.key}
                  onChange={(e) => setNewKey({ ...newKey, key: e.target.value })}
                  placeholder="Enter API key"
                />
              </div>
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newKey.name}
                  onChange={(e) => setNewKey({ ...newKey, name: e.target.value })}
                  placeholder="Enter key name"
                />
              </div>
              <div>
                <Label htmlFor="provider">Provider</Label>
                <Select
                  value={newKey.provider}
                  onValueChange={(value: any) => setNewKey({ ...newKey, provider: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gemini">Gemini</SelectItem>
                    <SelectItem value="openai">OpenAI</SelectItem>
                    <SelectItem value="claude">Claude</SelectItem>
                    <SelectItem value="deepseek">DeepSeek</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Input
                  id="priority"
                  type="number"
                  value={newKey.priority}
                  onChange={(e) => setNewKey({ ...newKey, priority: parseInt(e.target.value) })}
                  placeholder="Priority (lower = higher priority)"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="perMinute">Requests per Minute</Label>
                <Input
                  id="perMinute"
                  type="number"
                  value={newKey.rateLimit.requestsPerMinute}
                  onChange={(e) => setNewKey({
                    ...newKey,
                    rateLimit: { ...newKey.rateLimit, requestsPerMinute: parseInt(e.target.value) }
                  })}
                />
              </div>
              <div>
                <Label htmlFor="perHour">Requests per Hour</Label>
                <Input
                  id="perHour"
                  type="number"
                  value={newKey.rateLimit.requestsPerHour}
                  onChange={(e) => setNewKey({
                    ...newKey,
                    rateLimit: { ...newKey.rateLimit, requestsPerHour: parseInt(e.target.value) }
                  })}
                />
              </div>
              <div>
                <Label htmlFor="perDay">Requests per Day</Label>
                <Input
                  id="perDay"
                  type="number"
                  value={newKey.rateLimit.requestsPerDay}
                  onChange={(e) => setNewKey({
                    ...newKey,
                    rateLimit: { ...newKey.rateLimit, requestsPerDay: parseInt(e.target.value) }
                  })}
                />
              </div>
            </div>
            <Button onClick={handleAddKey} className="w-full">
              Add API Key
            </Button>
          </CardContent>
        </Card>
      )}

      {/* API Keys列表 */}
      <div className="space-y-4">
        {keys.map((key) => (
          <Card key={key.key}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {key.name}
                    <Badge className={getProviderColor(key.provider)}>
                      {key.provider.toUpperCase()}
                    </Badge>
                    {getStatusBadge(key)}
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-1">
                    Priority: {key.priority} | Errors: {key.errorCount}/{key.maxErrors}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={key.enabled}
                    onCheckedChange={(checked) => handleToggleKey(key.key, checked)}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleResetErrors(key.key)}
                    disabled={key.errorCount === 0}
                  >
                    Reset Errors
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteKey(key.key)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {/* 限流信息 */}
                {key.rateLimitInfo && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Minute Usage</span>
                      <span>{key.rateLimitInfo.currentMinute}/{key.rateLimitInfo.limitMinute}</span>
                    </div>
                    <Progress
                      value={(key.rateLimitInfo.currentMinute / key.rateLimitInfo.limitMinute) * 100}
                      className="h-2"
                    />
                    <div className="flex justify-between text-sm">
                      <span>Hour Usage</span>
                      <span>{key.rateLimitInfo.currentHour}/{key.rateLimitInfo.limitHour}</span>
                    </div>
                    <Progress
                      value={(key.rateLimitInfo.currentHour / key.rateLimitInfo.limitHour) * 100}
                      className="h-2"
                    />
                    <div className="flex justify-between text-sm">
                      <span>Day Usage</span>
                      <span>{key.rateLimitInfo.currentDay}/{key.rateLimitInfo.limitDay}</span>
                    </div>
                    <Progress
                      value={(key.rateLimitInfo.currentDay / key.rateLimitInfo.limitDay) * 100}
                      className="h-2"
                    />
                  </div>
                )}
                
                {/* 最后使用时间 */}
                {key.lastUsed && (
                  <p className="text-sm text-gray-600">
                    Last used: {new Date(key.lastUsed).toLocaleString()}
                  </p>
                )}
                
                {/* Key统计信息 */}
                {stats?.keyStats.find(s => s.key === key.key) && (
                  <div className="text-sm text-gray-600">
                    {(() => {
                      const keyStat = stats.keyStats.find(s => s.key === key.key)!;
                      return (
                        <div className="flex gap-4">
                          <span>Requests: {keyStat.requests}</span>
                          <span>Success Rate: {keyStat.successRate.toFixed(1)}%</span>
                          <span>Avg Time: {Math.round(keyStat.avgResponseTime)}ms</span>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
} 
"use client"

import { motion, AnimatePresence } from 'framer-motion'
import { ReactNode } from 'react'

interface AnimatedListProps {
  children: ReactNode
  className?: string
  staggerDelay?: number
}

/**
 * 动画列表组件
 */
export function AnimatedList({
  children,
  className = '',
  staggerDelay = 0.1
}: AnimatedListProps) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: staggerDelay
          }
        }
      }}
    >
      {children}
    </motion.div>
  )
}

/**
 * 动画列表项组件
 */
export function AnimatedListItem({
  children,
  className = '',
  index = 0
}: {
  children: ReactNode
  className?: string
  index?: number
}) {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { 
          opacity: 0, 
          y: 20,
          scale: 0.95
        },
        visible: { 
          opacity: 1, 
          y: 0,
          scale: 1
        }
      }}
      transition={{
        duration: 0.3,
        ease: "easeOut"
      }}
      whileHover={{
        y: -2,
        transition: { duration: 0.2 }
      }}
    >
      {children}
    </motion.div>
  )
}

/**
 * 淡入动画列表
 */
export function FadeInList({
  children,
  className = '',
  delay = 0
}: AnimatedListProps & { delay?: number }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ 
        duration: 0.5,
        delay,
        staggerChildren: 0.1
      }}
    >
      {children}
    </motion.div>
  )
}

/**
 * 滑动动画列表
 */
export function SlideInList({
  children,
  className = '',
  direction = 'up',
  delay = 0
}: AnimatedListProps & { 
  direction?: 'up' | 'down' | 'left' | 'right'
  delay?: number 
}) {
  const getInitialPosition = () => {
    switch (direction) {
      case 'up': return { y: 50, opacity: 0 }
      case 'down': return { y: -50, opacity: 0 }
      case 'left': return { x: 50, opacity: 0 }
      case 'right': return { x: -50, opacity: 0 }
      default: return { y: 50, opacity: 0 }
    }
  }

  return (
    <motion.div
      className={className}
      initial={getInitialPosition()}
      animate={{ x: 0, y: 0, opacity: 1 }}
      transition={{ 
        duration: 0.6,
        delay,
        staggerChildren: 0.1
      }}
    >
      {children}
    </motion.div>
  )
}

/**
 * 缩放动画列表
 */
export function ScaleInList({
  children,
  className = '',
  delay = 0
}: AnimatedListProps & { delay?: number }) {
  return (
    <motion.div
      className={className}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ 
        duration: 0.4,
        delay,
        staggerChildren: 0.1
      }}
    >
      {children}
    </motion.div>
  )
} 
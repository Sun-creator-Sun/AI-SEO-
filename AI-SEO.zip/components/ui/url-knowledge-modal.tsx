"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { extractKnowledgeFromUrl, UrlAnalysisResult } from '@/lib/url-knowledge-extraction'
import { GENERATIVE_AI_KEY } from '@/lib/config'

interface UrlKnowledgeModalProps {
  isOpen: boolean
  onClose: () => void
  onAnalysisComplete: (result: string, analysisData?: UrlAnalysisResult) => void
}

/**
 * URL知识提取弹窗组件
 */
export default function UrlKnowledgeModal({ 
  isOpen, 
  onClose, 
  onAnalysisComplete 
}: UrlKnowledgeModalProps) {
  const [url, setUrl] = useState('')
  const [focusInfo, setFocusInfo] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState('')

  // 检查是否配置了Gemini API密钥
  const hasGeminiKey = !!GENERATIVE_AI_KEY

  // 预设的URL选项
  const quickUrlOptions = [
    { label: 'Vertu官网', url: 'https://vertu.com' },
    { label: 'Apple官网', url: 'https://apple.com' },
    { label: 'Tesla官网', url: 'https://tesla.com' },
    { label: 'Nike官网', url: 'https://nike.com' },
    { label: 'Google官网', url: 'https://google.com' },
  ]

  // 预设的关注信息选项
  const quickFocusOptions = [
    '产品特点',
    '价格信息',
    '技术规格',
    '市场趋势',
    '用户评价',
    '竞争优势'
  ]

  /**
   * 快速选择URL
   */
  const handleQuickSelectUrl = (selectedUrl: string) => {
    setUrl(selectedUrl)
    setError('')
  }

  /**
   * 快速选择关注信息
   */
  const handleQuickSelectFocus = (selectedFocus: string) => {
    setFocusInfo(selectedFocus)
    setError('')
  }

  /**
   * 处理URL分析
   */
  const handleAnalyze = async () => {
    if (!url.trim()) {
      setError('请输入有效的URL')
      return
    }

    setIsAnalyzing(true)
    setError('')

    try {
      // 首先尝试使用新的简单文本提取API
      const response = await fetch('/api/extract-from-url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url.trim() })
      })

      const data = await response.json()

      if (data.success && data.content) {
        // 成功提取文本内容
        const extractedText = `--- 从URL提取的内容 (${new Date().toLocaleString('zh-CN')}) ---\nURL: ${data.url}\n${data.title ? `标题: ${data.title}\n` : ''}\n${data.content}`
        onAnalysisComplete(extractedText)
        onClose()
        return
      }

      // 如果简单提取失败，回退到AI分析
      if (hasGeminiKey) {
        const result = await extractKnowledgeFromUrl(url, focusInfo.trim() || undefined)
        const formattedResult = formatAnalysisResult(result, focusInfo)
        onAnalysisComplete(formattedResult, result)
        onClose()
      } else {
        throw new Error(data.error || '内容提取失败')
      }
      
    } catch (err) {
      console.error('分析失败:', err)
      setError(err instanceof Error ? err.message : '分析失败，请稍后重试')
    } finally {
      setIsAnalyzing(false)
    }
  }

  /**
   * 格式化分析结果为可读文本
   */
  const formatAnalysisResult = (result: UrlAnalysisResult, focus?: string): string => {
    let formatted = ''
    
    if (result.brand && result.brand !== 'Unknown Brand') {
      formatted += `Brand: ${result.brand}\n\n`
    }
    
    if (result.products && result.products.length > 0) {
      formatted += `Main Products/Services:\n`
      result.products.forEach((product, index) => {
        formatted += `• ${product}\n`
      })
      formatted += '\n'
    }
    
    if (result.productDescriptions && result.productDescriptions.length > 0) {
      formatted += `Product Descriptions:\n`
      result.productDescriptions.forEach((desc, index) => {
        if (desc && desc.trim()) {
          formatted += `• ${desc}\n`
        }
      })
      formatted += '\n'
    }
    
    if (result.summary) {
      formatted += `Website Overview:\n${result.summary}`
    }
    
    if (focus && focus.trim()) {
      formatted += `\n\nFocus Area: Analysis was specifically focused on "${focus.trim()}"`
    }
    
    // 如果有产品图片，添加图片标记但不显示URL
    if (result.productImage) {
      formatted += `\n\n[Product Image Available]`
    }
    
    return formatted.trim()
  }

  /**
   * 处理URL输入变化
   */
  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value)
    setError('')
  }

  /**
   * 处理关注信息输入变化
   */
  const handleFocusInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFocusInfo(e.target.value)
    setError('')
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">从URL提取知识</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
            disabled={isAnalyzing}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label htmlFor="url-input" className="block text-sm font-medium text-gray-700 mb-2">
              网站URL
            </label>
            <div className="relative">
              <Input
                id="url-input"
                type="url"
                placeholder="https://example.com"
                value={url}
                onChange={handleUrlChange}
                disabled={isAnalyzing}
                className="w-full pr-20"
              />
              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !url.trim()}
                className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 px-3 text-sm bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isAnalyzing ? (
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  '🔍'
                )}
              </Button>
            </div>
            
            {/* 快速选择URL按钮组 */}
            <div className="mt-3">
              <p className="text-xs text-gray-500 mb-2">快速选择：</p>
              <div className="flex flex-wrap gap-2">
                {quickUrlOptions.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickSelectUrl(option.url)}
                    disabled={isAnalyzing}
                    className="px-3 py-1.5 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100 hover:border-blue-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
                  >
                    <span className="flex items-center space-x-1">
                      <span>🌐</span>
                      <span>{option.label}</span>
                    </span>
                  </button>
                ))}
                
                {/* 清空按钮 */}
                {url && (
                  <button
                    onClick={() => handleQuickSelectUrl('')}
                    disabled={isAnalyzing}
                    className="px-3 py-1.5 text-xs bg-red-50 text-red-700 border border-red-200 rounded-lg hover:bg-red-100 hover:border-red-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
                  >
                    <span className="flex items-center space-x-1">
                      <span>🗑️</span>
                      <span>清空</span>
                    </span>
                  </button>
                )}
              </div>
              <p className="text-xs text-gray-400 mt-2">点击任意按钮快速填入对应网站URL</p>
            </div>
          </div>

          <div>
            <label htmlFor="focus-info-input" className="block text-sm font-medium text-gray-700 mb-2">
              关注信息 <span className="text-gray-500 text-xs">(可选)</span>
            </label>
            <Input
              id="focus-info-input"
              type="text"
              placeholder="例如：产品特点、价格信息、技术规格、市场趋势等"
              value={focusInfo}
              onChange={handleFocusInfoChange}
              disabled={isAnalyzing}
              className="w-full"
            />
            
            {/* 快速选择关注信息按钮组 */}
            <div className="mt-3">
              <p className="text-xs text-gray-500 mb-2">常用关注信息：</p>
              <div className="flex flex-wrap gap-2">
                {quickFocusOptions.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickSelectFocus(option)}
                    disabled={isAnalyzing}
                    className="px-3 py-1.5 text-xs bg-green-50 text-green-700 border border-green-200 rounded-lg hover:bg-green-100 hover:border-green-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50"
                  >
                    <span className="flex items-center space-x-1">
                      <span>🎯</span>
                      <span>{option}</span>
                    </span>
                  </button>
                ))}
                
                {/* 清空关注信息按钮 */}
                {focusInfo && (
                  <button
                    onClick={() => handleQuickSelectFocus('')}
                    disabled={isAnalyzing}
                    className="px-3 py-1.5 text-xs bg-gray-50 text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-100 hover:border-gray-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50"
                  >
                    <span className="flex items-center space-x-1">
                      <span>❌</span>
                      <span>清空</span>
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
              {error}
            </div>
          )}
        </div>

        {isAnalyzing && (
          <div className="mt-4 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
              <span>正在连接到网站...</span>
            </div>
            <div className="flex items-center space-x-2 mt-2">
              <div className="w-2 h-2 bg-purple-600 rounded-full animate-pulse"></div>
              <span>
                {hasGeminiKey ? 
                  (focusInfo.trim() ? 
                    `正在使用智能分析网站内容，特别关注"${focusInfo.trim()}"...` : 
                    '正在使用智能分析网站内容...') : 
                  '正在使用备用方法分析...'}
              </span>
            </div>
            {focusInfo.trim() && (
              <div className="flex items-center space-x-2 mt-2">
                <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                <span>正在提取关注信息相关内容...</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
} 
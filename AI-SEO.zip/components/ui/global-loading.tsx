"use client"

import { motion, AnimatePresence } from 'framer-motion'
import { Loader2, FileText, Sparkles } from 'lucide-react'

interface GlobalLoadingProps {
  isVisible: boolean
  message?: string
  step?: number
  totalSteps?: number
}

/**
 * 全局加载组件
 */
export function GlobalLoading({ 
  isVisible, 
  message = "正在处理...", 
  step = 1, 
  totalSteps = 4 
}: GlobalLoadingProps) {
  const progressPercentage = (step / totalSteps) * 100

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.8, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 20 }}
            className="bg-white rounded-lg p-8 max-w-md w-full mx-4 shadow-2xl"
          >
            <div className="text-center">
              {/* 图标 */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="mx-auto mb-4"
              >
                <Sparkles className="w-12 h-12 text-blue-600" />
              </motion.div>

              {/* 标题 */}
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                直接生成文章
              </h3>

              {/* 消息 */}
              <p className="text-gray-600 mb-6">
                {message}
              </p>

              {/* 进度条 */}
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <motion.div
                  className="bg-blue-600 h-2 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>

              {/* 步骤指示器 */}
              <div className="flex justify-between text-xs text-gray-500 mb-4">
                <span>步骤 {step}</span>
                <span>共 {totalSteps} 步</span>
              </div>

              {/* 步骤说明 */}
              <div className="text-sm text-gray-600">
                {step === 1 && "正在生成标题..."}
                {step === 2 && "正在生成大纲..."}
                {step === 3 && "正在生成文章内容..."}
                {step === 4 && "正在完成最终优化..."}
              </div>

              {/* 加载动画 */}
              <div className="mt-4">
                <Loader2 className="w-6 h-6 text-blue-600 animate-spin mx-auto" />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/**
 * 简化版全局加载组件
 */
export function SimpleGlobalLoading({ 
  isVisible, 
  message = "正在处理..." 
}: { isVisible: boolean; message?: string }) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.8 }}
            className="bg-white rounded-lg p-6 shadow-2xl"
          >
            <div className="text-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="mx-auto mb-4"
              >
                <FileText className="w-8 h-8 text-blue-600" />
              </motion.div>
              <p className="text-gray-700">{message}</p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
} 
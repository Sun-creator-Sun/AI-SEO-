"use client"

import { Card, CardContent, CardHeader } from './card'
import { motion } from 'framer-motion'
import { ReactNode } from 'react'

interface AnimatedCardProps {
  children: ReactNode
  className?: string
  header?: ReactNode
  hoverEffect?: boolean
  delay?: number
}

/**
 * 动画卡片组件
 */
export function AnimatedCard({
  children,
  className = '',
  header,
  hoverEffect = true,
  delay = 0
}: AnimatedCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.3,
        delay,
        ease: "easeOut"
      }}
      whileHover={hoverEffect ? {
        y: -5,
        transition: { duration: 0.2 }
      } : {}}
    >
      <Card className={className}>
        {header && <CardHeader>{header}</CardHeader>}
        <CardContent>{children}</CardContent>
      </Card>
    </motion.div>
  )
}

/**
 * 脉冲动画卡片
 */
export function PulseCard({
  children,
  className = '',
  header,
  delay = 0
}: AnimatedCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        boxShadow: [
          "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
          "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
          "0 4px 6px -1px rgba(0, 0, 0, 0.1)"
        ]
      }}
      transition={{ 
        duration: 0.4,
        delay,
        ease: "easeOut",
        boxShadow: {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }
      }}
      whileHover={{
        scale: 1.02,
        transition: { duration: 0.2 }
      }}
    >
      <Card className={className}>
        {header && <CardHeader>{header}</CardHeader>}
        <CardContent>{children}</CardContent>
      </Card>
    </motion.div>
  )
}

/**
 * 滑动动画卡片
 */
export function SlideCard({
  children,
  className = '',
  header,
  direction = 'left',
  delay = 0
}: AnimatedCardProps & { direction?: 'left' | 'right' | 'up' | 'down' }) {
  const getInitialPosition = () => {
    switch (direction) {
      case 'left': return { x: -50, opacity: 0 }
      case 'right': return { x: 50, opacity: 0 }
      case 'up': return { y: 50, opacity: 0 }
      case 'down': return { y: -50, opacity: 0 }
      default: return { x: -50, opacity: 0 }
    }
  }

  return (
    <motion.div
      initial={getInitialPosition()}
      animate={{ x: 0, y: 0, opacity: 1 }}
      transition={{ 
        duration: 0.5,
        delay,
        ease: "easeOut"
      }}
      whileHover={{
        scale: 1.01,
        transition: { duration: 0.2 }
      }}
    >
      <Card className={className}>
        {header && <CardHeader>{header}</CardHeader>}
        <CardContent>{children}</CardContent>
      </Card>
    </motion.div>
  )
} 
"use client"

import { Skeleton } from './skeleton'
import { Card, CardContent, CardHeader } from './card'

/**
 * 博客创意骨架屏
 */
export function BlogIdeasSkeleton() {
  return (
    <div className="space-y-4">
      {/* 关键词信息骨架 */}
      <div className="bg-white rounded-lg p-6 border">
        <Skeleton className="h-6 w-1/3 mb-4" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-4/6" />
        </div>
      </div>

      {/* 搜索意图骨架 */}
      <div className="bg-white rounded-lg p-6 border">
        <Skeleton className="h-5 w-1/4 mb-3" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      </div>

      {/* 博客创意列表骨架 */}
      <div className="space-y-3">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <div className="flex items-start justify-between mb-3">
              <Skeleton className="h-5 w-1/3" />
              <Skeleton className="h-6 w-16 rounded-full" />
            </div>
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-5/6 mb-3" />
            <div className="flex flex-wrap gap-2">
              <Skeleton className="h-6 w-16 rounded-full" />
              <Skeleton className="h-6 w-20 rounded-full" />
              <Skeleton className="h-6 w-14 rounded-full" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/**
 * 标题列表骨架屏
 */
export function TitlesSkeleton() {
  return (
    <div className="space-y-4">
      {/* 标题列表骨架 */}
      <div className="space-y-3">
        {Array.from({ length: 10 }).map((_, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between mb-2">
              <Skeleton className="h-5 w-3/4" />
              <div className="flex items-center space-x-2">
                <Skeleton className="h-4 w-8 rounded" />
                <Skeleton className="h-4 w-8 rounded" />
              </div>
            </div>
            <Skeleton className="h-4 w-full mb-2" />
            <div className="flex flex-wrap gap-2">
              <Skeleton className="h-5 w-16 rounded-full" />
              <Skeleton className="h-5 w-20 rounded-full" />
              <Skeleton className="h-5 w-14 rounded-full" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/**
 * 大纲骨架屏
 */
export function OutlineSkeleton() {
  return (
    <div className="space-y-6">
      {/* 大纲标题骨架 */}
      <div className="bg-white rounded-lg p-6 border">
        <Skeleton className="h-7 w-2/3 mb-4" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-5/6" />
      </div>

      {/* 大纲章节骨架 */}
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <Skeleton className="h-6 w-1/2 mb-3" />
            <div className="space-y-2 ml-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
              <Skeleton className="h-4 w-4/6" />
            </div>
            <div className="mt-3 flex items-center justify-between">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-16" />
            </div>
          </div>
        ))}
      </div>

      {/* 结论骨架 */}
      <div className="bg-white rounded-lg p-6 border">
        <Skeleton className="h-6 w-1/4 mb-3" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-5/6" />
      </div>
    </div>
  )
}

/**
 * 搜索结果骨架屏
 */
export function SearchResultsSkeleton() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 10 }).map((_, index) => (
        <div key={index} className="bg-white rounded-lg p-4 border">
          <Skeleton className="h-5 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-5/6 mb-2" />
          <Skeleton className="h-4 w-1/3 text-green-600" />
        </div>
      ))}
    </div>
  )
}

/**
 * 知识点骨架屏
 */
export function KnowledgePointsSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 15 }).map((_, index) => (
        <div key={index} className="flex items-center space-x-2">
          <Skeleton className="h-2 w-2 rounded-full" />
          <Skeleton className="h-4 w-full" />
        </div>
      ))}
    </div>
  )
}

/**
 * 设置页面骨架屏
 */
export function SettingsSkeleton() {
  return (
    <div className="space-y-6">
      {/* 文章要求骨架 */}
      <div className="bg-white rounded-lg p-6 border">
        <Skeleton className="h-6 w-1/3 mb-4" />
        <div className="space-y-3">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
        </div>
      </div>

      {/* 配置选项骨架 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <Skeleton className="h-5 w-1/2 mb-3" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/**
 * 文章生成进度骨架屏
 */
export function ArticleProgressSkeleton() {
  return (
    <div className="space-y-4">
      {/* 进度步骤骨架 */}
      <div className="space-y-3">
        {Array.from({ length: 4 }).map((_, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between mb-2">
              <Skeleton className="h-5 w-1/3" />
              <Skeleton className="h-6 w-16 rounded-full" />
            </div>
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        ))}
      </div>
    </div>
  )
}

/**
 * 通用内容骨架屏
 */
export function ContentSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-8 w-1/3" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
      <Skeleton className="h-4 w-4/6" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    </div>
  )
}

/**
 * 卡片骨架屏
 */
export function CardSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-1/3" />
        <Skeleton className="h-4 w-full" />
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-4/6" />
        </div>
      </CardContent>
    </Card>
  )
} 
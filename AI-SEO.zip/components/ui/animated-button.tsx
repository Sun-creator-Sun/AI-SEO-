"use client"

import { Button } from './button'
import { motion } from 'framer-motion'
import { ReactNode } from 'react'

interface ButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
  onClick?: () => void
  disabled?: boolean
  children?: ReactNode
}

interface AnimatedButtonProps extends ButtonProps {
  children: ReactNode
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
  onClick?: () => void
  disabled?: boolean
  loading?: boolean
}

/**
 * 动画按钮组件
 */
export function AnimatedButton({
  children,
  variant = 'default',
  size = 'default',
  className = '',
  onClick,
  disabled = false,
  loading = false,
  ...props
}: AnimatedButtonProps) {
  return (
    <motion.div
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{ duration: 0.1 }}
    >
      <Button
        variant={variant}
        size={size}
        className={className}
        onClick={onClick}
        disabled={disabled || loading}
        {...props}
      >
        {loading ? (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-4 h-4 border-2 border-current border-t-transparent rounded-full mr-2"
          />
        ) : null}
        {children}
      </Button>
    </motion.div>
  )
}

/**
 * 脉冲动画按钮
 */
export function PulseButton({
  children,
  variant = 'default',
  size = 'default',
  className = '',
  onClick,
  disabled = false,
  ...props
}: AnimatedButtonProps) {
  return (
    <motion.div
      whileHover={{ scale: disabled ? 1 : 1.05 }}
      whileTap={{ scale: disabled ? 1 : 0.95 }}
      animate={disabled ? {} : { 
        boxShadow: [
          "0 0 0 0 rgba(59, 130, 246, 0.7)",
          "0 0 0 10px rgba(59, 130, 246, 0)",
          "0 0 0 0 rgba(59, 130, 246, 0)"
        ]
      }}
      transition={{ 
        duration: 0.3,
        repeat: disabled ? 0 : Infinity,
        repeatDelay: 1
      }}
    >
      <Button
        variant={variant}
        size={size}
        className={className}
        onClick={onClick}
        disabled={disabled}
        {...props}
      >
        {children}
      </Button>
    </motion.div>
  )
}

/**
 * 渐变动画按钮
 */
export function GradientButton({
  children,
  size = 'default',
  className = '',
  onClick,
  disabled = false,
  ...props
}: AnimatedButtonProps) {
  return (
    <motion.div
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      animate={{
        background: [
          "linear-gradient(45deg, #667eea 0%, #764ba2 100%)",
          "linear-gradient(45deg, #764ba2 0%, #667eea 100%)",
          "linear-gradient(45deg, #667eea 0%, #764ba2 100%)"
        ]
      }}
      transition={{ 
        duration: 2,
        repeat: disabled ? 0 : Infinity,
        ease: "linear"
      }}
      className={`rounded-md ${className}`}
    >
      <Button
        variant="default"
        size={size}
        className="bg-transparent border-0 hover:bg-transparent"
        onClick={onClick}
        disabled={disabled}
        {...props}
      >
        {children}
      </Button>
    </motion.div>
  )
} 
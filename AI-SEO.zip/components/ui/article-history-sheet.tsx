'use client';

import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from './sheet';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Badge } from './badge';
import { ScrollArea } from './scroll-area';
import { Separator } from './separator';
import { 
  History, 
  FileText, 
  Copy, 
  Trash2, 
  Clock, 
  Hash,
  Eye,
  EyeOff,
  Download
} from 'lucide-react';
import { GeneratedArticle } from '@/lib/types';
import { 
  getArticleHistory, 
  deleteArticleFromHistory, 
  clearArticleHistory,
  formatCreatedAt,
  calculateWordCount
} from '@/lib/article-history';
import { convertMarkdownToWordPressHTML } from '@/lib/html-converter';
import { useToast } from './toast';

interface ArticleHistorySheetProps {
  children?: React.ReactNode;
}

export function ArticleHistorySheet({ children }: ArticleHistorySheetProps) {
  const [articles, setArticles] = useState<GeneratedArticle[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<GeneratedArticle | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [showContent, setShowContent] = useState(false);
  const toast = useToast();

  // 加载历史记录
  const loadHistory = () => {
    const history = getArticleHistory();
    setArticles(history);
  };

  // 删除文章
  const handleDeleteArticle = (articleId: string) => {
    if (confirm('确定要删除这篇文章吗？此操作不可撤销。')) {
      const success = deleteArticleFromHistory(articleId);
      if (success) {
        loadHistory();
        if (selectedArticle?.id === articleId) {
          setSelectedArticle(null);
        }
        toast.success("删除成功", "文章已从历史记录中删除");
      } else {
        toast.error("删除失败", "无法删除文章，请重试");
      }
    }
  };

  // 清空历史记录
  const handleClearHistory = () => {
    if (confirm('确定要清空所有历史记录吗？此操作不可撤销。')) {
      clearArticleHistory();
      setArticles([]);
      setSelectedArticle(null);
      toast.success("清空成功", "所有历史记录已清空");
    }
  };

  // 复制Markdown内容
  const handleCopyMarkdown = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      toast.success("复制成功", "Markdown格式内容已复制到剪贴板");
    } catch (error) {
      toast.error("复制失败", "无法复制内容，请手动选择复制");
    }
  };

  // 复制WordPress HTML内容
  const handleCopyHTML = async (content: string) => {
    try {
      const htmlContent = convertMarkdownToWordPressHTML(content);
      await navigator.clipboard.writeText(htmlContent);
      toast.success("复制成功", "WordPress HTML格式内容已复制到剪贴板");
    } catch (error) {
      toast.error("复制失败", "无法复制内容，请手动选择复制");
    }
  };

  // 下载文章
  const handleDownloadArticle = (article: GeneratedArticle) => {
    const blob = new Blob([article.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${article.title.replace(/[^a-zA-Z0-9]/g, '_')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success("下载成功", "文章已下载为Markdown文件");
  };

  // 当Sheet打开时加载历史记录
  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        {children || (
          <Button variant="outline" size="sm">
            <History className="h-4 w-4 mr-2" />
            历史记录
          </Button>
        )}
      </SheetTrigger>
      <SheetContent className="w-[800px] sm:max-w-[800px]">
        <SheetHeader>
          <SheetTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <History className="h-5 w-5 mr-2" />
              文章生成历史
            </div>
            {articles.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleClearHistory}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                清空
              </Button>
            )}
          </SheetTitle>
        </SheetHeader>

        <div className="flex h-full mt-4">
          {/* 左侧文章列表 */}
          <div className="w-1/2 pr-4 border-r">
            <ScrollArea className="h-[calc(100vh-200px)]">
              {articles.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>暂无历史记录</p>
                  <p className="text-sm">生成的文章将显示在这里</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {articles.map((article) => (
                    <Card
                      key={article.id}
                      className={`cursor-pointer transition-colors hover:bg-accent ${
                        selectedArticle?.id === article.id ? 'bg-accent border-primary' : ''
                      }`}
                      onClick={() => setSelectedArticle(article)}
                    >
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm line-clamp-2">
                          {article.title}
                        </CardTitle>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {formatCreatedAt(article.createdAt)}
                          </div>
                          <div className="flex items-center">
                            <Hash className="h-3 w-3 mr-1" />
                            {article.wordCount || calculateWordCount(article.content)} 字
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex flex-wrap gap-1">
                          {article.keywords.slice(0, 3).map((keyword, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                          {article.keywords.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{article.keywords.length - 3}
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* 右侧文章详情 */}
          <div className="w-1/2 pl-4">
            {selectedArticle ? (
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold line-clamp-1">
                    {selectedArticle.title}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowContent(!showContent)}
                    >
                      {showContent ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopyMarkdown(selectedArticle.content)}
                      title="复制Markdown格式"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopyHTML(selectedArticle.content)}
                      title="复制WordPress HTML格式"
                      className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                    >
                      HTML
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadArticle(selectedArticle)}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteArticle(selectedArticle.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex items-center space-x-4 mb-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {formatCreatedAt(selectedArticle.createdAt)}
                  </div>
                  <div className="flex items-center">
                    <Hash className="h-4 w-4 mr-1" />
                    {selectedArticle.wordCount || calculateWordCount(selectedArticle.content)} 字
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-4">
                  {selectedArticle.keywords.map((keyword, index) => (
                    <Badge key={index} variant="secondary">
                      {keyword}
                    </Badge>
                  ))}
                </div>

                <Separator className="mb-4" />

                {showContent ? (
                  <ScrollArea className="flex-1">
                    <div className="prose prose-sm max-w-none">
                      <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-md">
                        {selectedArticle.content}
                      </pre>
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="flex-1 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>点击眼睛图标查看文章内容</p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>选择一篇文章查看详情</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
} 
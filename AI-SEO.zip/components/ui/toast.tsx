"use client"

import React, { createContext, useContext, useState, useCallback } from 'react'
import { CheckCircle, XCircle, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Toast {
  id: string
  type: 'success' | 'error'
  title: string
  description?: string
}

interface ToastContextType {
  toasts: Toast[]
  addToast: (toast: Omit<Toast, 'id'>) => void
  removeToast: (id: string) => void
}

const ToastContext = createContext<ToastContextType | undefined>(undefined)

/**
 * Toast Provider组件
 */
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  /**
   * 添加toast提示
   */
  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = Math.random().toString(36).substring(2, 9)
    const newToast = { ...toast, id }
    
    setToasts(prev => [...prev, newToast])
    
    // 3秒后自动移除
    setTimeout(() => {
      removeToast(id)
    }, 3000)
  }, [])

  /**
   * 移除toast提示
   */
  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id))
  }, [])

  return (
    <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
      {children}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </ToastContext.Provider>
  )
}

/**
 * useToast hook
 */
export function useToast() {
  const context = useContext(ToastContext)
  if (!context) {
    throw new Error('useToast must be used within ToastProvider')
  }

  const { addToast } = context

  const success = useCallback((title: string, description?: string) => {
    addToast({ type: 'success', title, description })
  }, [addToast])

  const error = useCallback((title: string, description?: string) => {
    addToast({ type: 'error', title, description })
  }, [addToast])

  return { success, error }
}

/**
 * Toast容器组件
 */
function ToastContainer({ toasts, onRemove }: { toasts: Toast[]; onRemove: (id: string) => void }) {
  if (toasts.length === 0) return null

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map(toast => (
        <ToastItem key={toast.id} toast={toast} onRemove={onRemove} />
      ))}
    </div>
  )
}

/**
 * 单个Toast组件
 */
function ToastItem({ toast, onRemove }: { toast: Toast; onRemove: (id: string) => void }) {
  return (
    <div
      className={cn(
        "flex items-start gap-3 min-w-[320px] p-4 rounded-lg shadow-lg border bg-white animate-in slide-in-from-right-5 duration-300",
        {
          "border-green-200": toast.type === 'success',
          "border-red-200": toast.type === 'error'
        }
      )}
    >
      {/* 图标 */}
      <div className="flex-shrink-0">
        {toast.type === 'success' && (
          <CheckCircle className="w-5 h-5 text-green-500" />
        )}
        {toast.type === 'error' && (
          <XCircle className="w-5 h-5 text-red-500" />
        )}
      </div>

      {/* 内容 */}
      <div className="flex-1 min-w-0">
        <div className={cn(
          "text-sm font-medium",
          {
            "text-green-900": toast.type === 'success',
            "text-red-900": toast.type === 'error'
          }
        )}>
          {toast.title}
        </div>
        {toast.description && (
          <div className={cn(
            "text-sm mt-1",
            {
              "text-green-700": toast.type === 'success',
              "text-red-700": toast.type === 'error'
            }
          )}>
            {toast.description}
          </div>
        )}
      </div>

      {/* 关闭按钮 */}
      <button
        onClick={() => onRemove(toast.id)}
        className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  )
} 
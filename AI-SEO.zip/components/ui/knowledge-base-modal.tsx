"use client"

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import type { KnowledgeBase } from '@/app/api/knowledge-base/list/route'
import type { KnowledgeBaseDetail } from '@/app/api/knowledge-base/detail/route'

interface KnowledgeBaseModalProps {
  isOpen: boolean
  onClose: () => void
  onKnowledgeExtracted: (knowledge: string) => void
}

/**
 * 知识库选择和管理弹窗组件
 */
export default function KnowledgeBaseModal({
  isOpen,
  onClose,
  onKnowledgeExtracted
}: KnowledgeBaseModalProps) {
  
  // 状态管理
  const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([])
  const [selectedKnowledgeBase, setSelectedKnowledgeBase] = useState<KnowledgeBase | null>(null)
  const [knowledgeBaseDetail, setKnowledgeBaseDetail] = useState<KnowledgeBaseDetail | null>(null)
  const [question, setQuestion] = useState('')
  const [extractionPrompt, setExtractionPrompt] = useState('请根据SEO写作要求，提取与博客文章相关的关键知识点和素材，包括产品特性、使用场景、优势等信息。')
  const [isLoading, setIsLoading] = useState(false)
  const [isExtracting, setIsExtracting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // 图片加载状态管理
  const [imageLoadErrors, setImageLoadErrors] = useState<Set<string>>(new Set())
  // 搜索状态管理
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filteredKnowledgeBases, setFilteredKnowledgeBases] = useState<KnowledgeBase[]>([])

  /**
   * 模糊搜索知识库
   * @param keyword 搜索关键词
   * @param knowledgeBaseList 知识库列表
   */
  const filterKnowledgeBases = (keyword: string, knowledgeBaseList: KnowledgeBase[]) => {
    if (!keyword.trim()) {
      return knowledgeBaseList
    }

    const lowerKeyword = keyword.toLowerCase()
    return knowledgeBaseList.filter(kb => 
      kb.name.toLowerCase().includes(lowerKeyword) ||
      (kb.intro && kb.intro.toLowerCase().includes(lowerKeyword))
    )
  }

  /**
   * 处理搜索输入变化
   * @param value 搜索关键词
   */
  const handleSearchChange = (value: string) => {
    setSearchKeyword(value)
    const filtered = filterKnowledgeBases(value, knowledgeBases)
    setFilteredKnowledgeBases(filtered)
    
    // 如果当前选中的知识库不在搜索结果中，清除选中状态
    if (selectedKnowledgeBase && !filtered.find(kb => kb._id === selectedKnowledgeBase._id)) {
      setSelectedKnowledgeBase(null)
      setKnowledgeBaseDetail(null)
    }
  }

  /**
   * 清除搜索
   */
  const clearSearch = () => {
    setSearchKeyword('')
    setFilteredKnowledgeBases(knowledgeBases)
  }

  /**
   * 处理图片加载错误
   * @param knowledgeBaseId 知识库ID
   */
  const handleImageError = (knowledgeBaseId: string) => {
    setImageLoadErrors(prev => {
      const newSet = new Set(prev)
      newSet.add(knowledgeBaseId)
      return newSet
    })
  }

  /**
   * 根据知识库名称生成头像字母
   * @param name 知识库名称
   */
  const getAvatarInitials = (name: string) => {
    return name.charAt(0).toUpperCase()
  }

  /**
   * 获取知识库图标
   * @param type 知识库类型
   */
  const getKnowledgeBaseIcon = (type: string) => {
    const iconMap: Record<string, string> = {
      'dataset': '📚',
      'knowledge': '🧠',
      'document': '📄',
      'manual': '📖',
      'faq': '❓',
      'default': '📊'
    }
    return iconMap[type] || iconMap.default
  }

  /**
   * 渲染知识库头像
   * @param kb 知识库对象
   */
  const renderKnowledgeBaseAvatar = (kb: KnowledgeBase) => {
    const hasImageError = imageLoadErrors.has(kb._id)
    const hasAvatar = kb.avatar && !hasImageError

    if (hasAvatar) {
      return (
        <div className="relative w-10 h-10">
          <Image 
            src={kb.avatar} 
            alt={kb.name} 
            fill
            className="rounded-lg object-cover border border-gray-200"
            onError={() => handleImageError(kb._id)}
            sizes="40px"
            priority={false}
          />
        </div>
      )
    }

    // Fallback显示
    return (
      <div className="w-10 h-10 rounded-lg border border-gray-200 flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="text-center">
          <div className="text-xs text-blue-600 font-medium">
            {getAvatarInitials(kb.name)}
          </div>
          <div className="text-xs mt-0.5">
            {getKnowledgeBaseIcon(kb.type)}
          </div>
        </div>
      </div>
    )
  }

  /**
   * 获取知识库列表
   */
  const fetchKnowledgeBases = async () => {
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await fetch('/api/knowledge-base/list', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ parentId: '' })
      })

      if (!response.ok) {
        throw new Error('获取知识库列表失败')
      }

      const data = await response.json()
      
      if (data.error) {
        throw new Error(data.error)
      }

      if (data.code === 200) {
        setKnowledgeBases(data.data)
        setFilteredKnowledgeBases(data.data)
      } else {
        throw new Error(data.message || '获取知识库列表失败')
      }
    } catch (error) {
      console.error('获取知识库列表错误:', error)
      setError(error instanceof Error ? error.message : '获取知识库列表失败')
    } finally {
      setIsLoading(false)
    }
  }

  /**
   * 获取知识库详情
   */
  const fetchKnowledgeBaseDetail = async (id: string) => {
    try {
      const response = await fetch(`/api/knowledge-base/detail?id=${id}`)

      if (!response.ok) {
        throw new Error('获取知识库详情失败')
      }

      const data = await response.json()
      
      if (data.error) {
        throw new Error(data.error)
      }

      if (data.code === 200) {
        setKnowledgeBaseDetail(data.data)
      } else {
        throw new Error(data.message || '获取知识库详情失败')
      }
    } catch (error) {
      console.error('获取知识库详情错误:', error)
      setError(error instanceof Error ? error.message : '获取知识库详情失败')
    }
  }

  /**
   * 从知识库提取知识
   */
  const extractKnowledge = async () => {
    if (!selectedKnowledgeBase || !question.trim()) {
      setError('请选择知识库并输入查询问题')
      return
    }

    setIsExtracting(true)
    setError(null)

    try {
      const response = await fetch('/api/knowledge-base/extract', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          knowledgeBaseId: selectedKnowledgeBase._id,
          question: question.trim(),
          extractKnowledgePrompt: extractionPrompt
        })
      })

      if (!response.ok) {
        throw new Error('提取知识失败')
      }

      const data = await response.json()
      
      if (data.error) {
        throw new Error(data.error)
      }

      if (data.choices && data.choices.length > 0) {
        const extractedKnowledge = data.choices[0].message.content
        onKnowledgeExtracted(extractedKnowledge)
        onClose()
      } else {
        throw new Error('未能提取到有效知识')
      }
    } catch (error) {
      console.error('提取知识错误:', error)
      setError(error instanceof Error ? error.message : '提取知识失败')
    } finally {
      setIsExtracting(false)
    }
  }

  /**
   * 选择知识库
   */
  const handleSelectKnowledgeBase = (knowledgeBase: KnowledgeBase) => {
    setSelectedKnowledgeBase(knowledgeBase)
    fetchKnowledgeBaseDetail(knowledgeBase._id)
    setError(null)
  }

  /**
   * 重置状态
   */
  const resetState = () => {
    setSelectedKnowledgeBase(null)
    setKnowledgeBaseDetail(null)
    setQuestion('')
    setError(null)
    setImageLoadErrors(new Set())
    setSearchKeyword('')
    setFilteredKnowledgeBases([])
  }

  // 监听弹窗开启，获取知识库列表
  useEffect(() => {
    if (isOpen) {
      fetchKnowledgeBases()
    } else {
      resetState()
    }
  }, [isOpen])

  /**
   * 高亮搜索关键词
   * @param text 原始文本
   * @param keyword 搜索关键词
   */
  const highlightSearchKeyword = (text: string, keyword: string) => {
    if (!keyword.trim()) {
      return text
    }

    const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
    const parts = text.split(regex)
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 text-yellow-900 px-0.5 rounded">
          {part}
        </mark>
      ) : (
        part
      )
    )
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* 头部 */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold">🧠 AI 知识库</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-xl font-bold w-8 h-8 flex items-center justify-center"
          >
            ×
          </button>
        </div>

        {/* 内容区域 */}
        <div className="flex h-[70vh]">
          {/* 左侧：知识库列表 */}
          <div className="w-1/3 border-r overflow-y-auto p-4">
            <h3 className="font-medium text-gray-900 mb-3">选择知识库</h3>
            
            {/* 搜索框 */}
            {!isLoading && knowledgeBases.length > 0 && (
              <div className="mb-4">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <input
                    type="text"
                    placeholder="搜索知识库名称或描述..."
                    value={searchKeyword}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Escape') {
                        clearSearch()
                      }
                    }}
                    className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  {searchKeyword && (
                    <button
                      onClick={clearSearch}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center hover:text-gray-600"
                    >
                      <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  )}
                </div>
                
                {/* 搜索结果统计 */}
                {searchKeyword && (
                  <div className="mt-2 text-xs text-gray-500">
                    找到 {filteredKnowledgeBases.length} 个相关知识库
                    {filteredKnowledgeBases.length !== knowledgeBases.length && (
                      <span className="ml-1">/ 共 {knowledgeBases.length} 个</span>
                    )}
                  </div>
                )}
                
                {/* 搜索提示 */}
                {!searchKeyword && (
                  <div className="mt-2 text-xs text-gray-400">
                    💡 提示：按 ESC 键可快速清除搜索
                  </div>
                )}
              </div>
            )}
            
            {isLoading && (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            )}

            {error && !isLoading && (
              <div className="text-center py-8">
                <p className="text-red-500 text-sm mb-4">{error}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={fetchKnowledgeBases}
                >
                  重试
                </Button>
              </div>
            )}

            {!isLoading && !error && knowledgeBases.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500 text-sm">暂无可用的知识库</p>
              </div>
            )}

            {/* 搜索无结果 */}
            {!isLoading && !error && knowledgeBases.length > 0 && filteredKnowledgeBases.length === 0 && searchKeyword && (
              <div className="text-center py-8">
                <div className="text-gray-400 mb-2">🔍</div>
                <p className="text-gray-500 text-sm mb-2">未找到匹配的知识库</p>
                <p className="text-xs text-gray-400 mb-4">
                  尝试使用不同的关键词搜索
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={clearSearch}
                >
                  清除搜索
                </Button>
              </div>
            )}

            {!isLoading && filteredKnowledgeBases.length > 0 && (
              <div className="space-y-3">
                {filteredKnowledgeBases.map((kb) => (
                  <div
                    key={kb._id}
                    onClick={() => handleSelectKnowledgeBase(kb)}
                    className={`group relative p-4 rounded-xl border cursor-pointer transition-all duration-200 hover:shadow-md ${
                      selectedKnowledgeBase?._id === kb._id
                        ? 'border-blue-500 bg-blue-50 shadow-lg ring-2 ring-blue-200 ring-opacity-50'
                        : 'border-gray-200 hover:bg-gray-50 hover:border-gray-300'
                    }`}
                  >
                    {/* 选中状态指示器 */}
                    {selectedKnowledgeBase?._id === kb._id && (
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}

                    <div className="flex items-start space-x-3">
                      {renderKnowledgeBaseAvatar(kb)}
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-gray-900 truncate text-sm">
                            {highlightSearchKeyword(kb.name, searchKeyword)}
                          </h4>
                          <div className="flex items-center space-x-1">
                            {kb.isOwner && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full" title="所有者"></div>
                            )}
                          </div>
                        </div>
                        
                        {kb.intro ? (
                          <p className="text-xs text-gray-600 mb-3 line-clamp-2 leading-relaxed">
                            {highlightSearchKeyword(kb.intro, searchKeyword)}
                          </p>
                        ) : (
                          <p className="text-xs text-gray-400 mb-3 italic">
                            暂无描述
                          </p>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                              kb.permission === 'private' 
                                ? 'bg-red-100 text-red-700 border border-red-200' 
                                : 'bg-green-100 text-green-700 border border-green-200'
                            }`}>
                              <div className={`w-1.5 h-1.5 rounded-full mr-1 ${
                                kb.permission === 'private' ? 'bg-red-400' : 'bg-green-400'
                              }`}></div>
                              {kb.permission === 'private' ? '私有' : '公开'}
                            </span>
                            
                            {kb.canWrite && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700 border border-blue-200">
                                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                  <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                                </svg>
                                可编辑
                              </span>
                            )}
                          </div>
                          
                          {kb.isOwner && (
                            <div className="flex items-center text-xs text-blue-600">
                              <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                              </svg>
                              所有者
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Hover效果 */}
                    <div className={`absolute inset-0 rounded-xl transition-opacity duration-200 ${
                      selectedKnowledgeBase?._id === kb._id 
                        ? 'opacity-0' 
                        : 'opacity-0 group-hover:opacity-5 bg-blue-500'
                    }`}></div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 右侧：知识提取 */}
          <div className="flex-1 overflow-y-auto p-4">
            {!selectedKnowledgeBase ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="text-gray-400 mb-4">📚</div>
                  <p className="text-gray-500">请先选择一个知识库</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* 知识库详情 */}
                {knowledgeBaseDetail && (
                  <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-5 border border-gray-200">
                    <div className="flex items-start space-x-3 mb-4">
                      {renderKnowledgeBaseAvatar(selectedKnowledgeBase!)}
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-1">{knowledgeBaseDetail.name}</h4>
                        {knowledgeBaseDetail.intro ? (
                          <p className="text-sm text-gray-600 leading-relaxed">{highlightSearchKeyword(knowledgeBaseDetail.intro, searchKeyword)}</p>
                        ) : (
                          <p className="text-sm text-gray-400 italic">暂无知识库描述</p>
                        )}
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs font-medium border ${
                        knowledgeBaseDetail.status === 'active' 
                          ? 'bg-green-100 text-green-700 border-green-200' 
                          : 'bg-red-100 text-red-700 border-red-200'
                      }`}>
                        <div className={`inline-block w-1.5 h-1.5 rounded-full mr-1 ${
                          knowledgeBaseDetail.status === 'active' ? 'bg-green-400' : 'bg-red-400'
                        }`}></div>
                        {knowledgeBaseDetail.status === 'active' ? '活跃' : '非活跃'}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg p-3 border border-gray-100">
                        <div className="flex items-center mb-2">
                          <div className="w-2 h-2 bg-purple-400 rounded-full mr-2"></div>
                          <span className="font-medium text-gray-700 text-sm">向量模型</span>
                        </div>
                        <p className="text-sm text-gray-600">{knowledgeBaseDetail.vectorModel.name}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          Token: {knowledgeBaseDetail.vectorModel.defaultToken} / {knowledgeBaseDetail.vectorModel.maxToken}
                        </p>
                      </div>
                      
                      {knowledgeBaseDetail.agentModel && (
                        <div className="bg-white rounded-lg p-3 border border-gray-100">
                          <div className="flex items-center mb-2">
                            <div className="w-2 h-2 bg-blue-400 rounded-full mr-2"></div>
                            <span className="font-medium text-gray-700 text-sm">对话模型</span>
                          </div>
                          <p className="text-sm text-gray-600">{knowledgeBaseDetail.agentModel.name}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            上下文: {knowledgeBaseDetail.agentModel.maxContext}
                          </p>
                        </div>
                      )}
                      
                      <div className="bg-white rounded-lg p-3 border border-gray-100">
                        <div className="flex items-center mb-2">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          <span className="font-medium text-gray-700 text-sm">权限信息</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            knowledgeBaseDetail.permission === 'private' 
                              ? 'bg-red-100 text-red-700' 
                              : 'bg-green-100 text-green-700'
                          }`}>
                            {knowledgeBaseDetail.permission === 'private' ? '私有' : '公开'}
                          </span>
                          {knowledgeBaseDetail.canWrite && (
                            <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700">可编辑</span>
                          )}
                          {knowledgeBaseDetail.isOwner && (
                            <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700">所有者</span>
                          )}
                        </div>
                      </div>
                      
                      <div className="bg-white rounded-lg p-3 border border-gray-100">
                        <div className="flex items-center mb-2">
                          <div className="w-2 h-2 bg-orange-400 rounded-full mr-2"></div>
                          <span className="font-medium text-gray-700 text-sm">更新时间</span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {new Date(knowledgeBaseDetail.updateTime).toLocaleDateString('zh-CN', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* 查询问题 */}
                <div className="bg-white rounded-xl p-4 border border-gray-200">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                      <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-900">
                        查询问题
                      </label>
                      <p className="text-xs text-gray-500 mt-1">描述您想从知识库中了解的内容</p>
                    </div>
                  </div>
                  <Input
                    placeholder="例如：产品的主要特性和优势是什么？使用场景有哪些？"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    className="w-full border-0 focus:ring-2 focus:ring-blue-500 bg-gray-50"
                  />
                </div>

                {/* 提取指令 */}
                <div className="bg-white rounded-xl p-4 border border-gray-200">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                      <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-900">
                        提取指令
                      </label>
                      <p className="text-xs text-gray-500 mt-1">自定义知识提取和组织的方式</p>
                    </div>
                  </div>
                  <textarea
                    placeholder="描述您希望如何提取和组织知识..."
                    value={extractionPrompt}
                    onChange={(e) => setExtractionPrompt(e.target.value)}
                    className="w-full h-24 p-3 border-0 rounded-lg resize-none text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-gray-50"
                  />
                  <div className="text-right text-xs text-gray-400 mt-1">
                    {extractionPrompt.length}/1000
                  </div>
                </div>

                {/* 错误信息 */}
                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                    <p className="text-red-600 text-sm">{error}</p>
                  </div>
                )}

                {/* 操作按钮 */}
                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={onClose}
                    disabled={isExtracting}
                  >
                    取消
                  </Button>
                  <Button
                    onClick={extractKnowledge}
                    disabled={!selectedKnowledgeBase || !question.trim() || isExtracting}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    {isExtracting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        提取中...
                      </>
                    ) : (
                      '✨ 提取知识'
                    )}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
} 
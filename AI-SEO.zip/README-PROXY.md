# VPN代理配置指南

本项目已集成VPN代理支持，可以自动处理网络连接问题。

## 🔧 自动代理检测

项目会自动检测并尝试以下代理配置：

### 环境变量代理
- `HTTPS_PROXY` 或 `https_proxy`
- `HTTP_PROXY` 或 `http_proxy`

### 常见VPN代理端口
- `http://127.0.0.1:7890` - Clash for Windows/Mac
- `http://127.0.0.1:1087` - Surge
- `http://127.0.0.1:8080` - 通用HTTP代理
- `http://127.0.0.1:1080` - SOCKS代理转HTTP

## 🚀 支持的API

### ✅ 完全支持代理的API
- `/api/extract-seo-knowledge` - SEO知识点提取（支持POST请求）
- `/api/search` - Google搜索代理（支持GET请求）

### ⚠️ 部分支持的API
- `/api/test-grounding` - 使用@google/genai包，需要系统级代理配置

## 🛠️ 手动配置代理

如果自动检测失败，可以手动设置环境变量：

```bash
# macOS/Linux
export HTTPS_PROXY=http://127.0.0.1:7890
export HTTP_PROXY=http://127.0.0.1:7890

# Windows
set HTTPS_PROXY=http://127.0.0.1:7890
set HTTP_PROXY=http://127.0.0.1:7890
```

## 📊 代理状态日志

API调用时会显示详细的代理使用情况：

```
🔧 代理配置: { proxy: undefined, commonProxyPorts: [...], detected: false }
🌐 将尝试以下代理配置: [...]
🔄 尝试代理 1/4: http://127.0.0.1:7890
🔗 HTTPS模块使用代理: http://127.0.0.1:7890
✅ Gemini API响应成功，使用的代理: http://127.0.0.1:7890
```

## 🔍 故障排除

### 常见问题
1. **代理端口不正确** - 检查VPN软件的代理设置
2. **VPN未启动** - 确保VPN连接正常
3. **防火墙阻止** - 检查防火墙设置

### 测试命令
```bash
# 测试代理连接
curl -I --proxy http://127.0.0.1:7890 https://www.google.com

# 测试API
curl -X POST http://localhost:3000/api/extract-seo-knowledge \
  -H "Content-Type: application/json" \
  -d '{"prompt":"测试", "content":"测试内容"}'
```

## 📋 技术实现

### 核心文件
- `lib/proxy-helper.ts` - 公共代理助手模块
- 自动重试机制，支持多个代理端口
- 统一的错误处理和诊断信息

### 使用方法
```typescript
import { callApiWithProxyRetry } from '@/lib/proxy-helper';

// POST请求
const response = await callApiWithProxyRetry(apiUrl, requestBody, 'Service Name');

// GET请求
const response = await callApiWithProxyRetry(apiUrl, null, 'Service Name', 'GET');
```

## 🎯 最佳实践

1. **优先使用支持代理的API路由**
2. **检查VPN状态** - 确保VPN正常工作
3. **查看日志** - 通过浏览器开发者工具或终端查看详细日志
4. **多节点测试** - 如果一个VPN节点不行，尝试其他节点

---

如有问题，请检查终端日志获取详细的网络诊断信息。

# 代理配置说明

## 推荐方式：使用环境变量

最简单的方式是设置环境变量，这是标准做法：

### 1. 设置环境变量

```bash
# 推荐：使用HTTPS_PROXY（针对HTTPS请求）
export HTTPS_PROXY="http://127.0.0.1:7890"

# 或者：使用HTTP_PROXY（通用代理）
export HTTP_PROXY="http://127.0.0.1:8080"
```

### 2. 常见VPN软件的默认端口

| VPN软件 | 默认端口 | 环境变量设置 |
|---------|----------|-------------|
| Clash | 7890 | `export HTTPS_PROXY="http://127.0.0.1:7890"` |
| Surge | 1087 | `export HTTPS_PROXY="http://127.0.0.1:1087"` |
| 通用代理 | 8080 | `export HTTPS_PROXY="http://127.0.0.1:8080"` |

### 3. 验证代理配置

```bash
# 检查环境变量
echo $HTTPS_PROXY
echo $HTTP_PROXY

# 启动应用
npm run dev
```

### 4. 临时设置（单次运行）

```bash
# 临时设置并启动应用
HTTPS_PROXY="http://127.0.0.1:7890" npm run dev
```

## 备用方式：自动检测

如果没有设置环境变量，系统会自动尝试常见端口：
- `http://127.0.0.1:7890` (Clash)
- `http://127.0.0.1:1087` (Surge)
- `http://127.0.0.1:8080` (通用)

## 优势

✅ **简化配置**：只需设置一个环境变量  
✅ **标准做法**：符合HTTP代理的标准规范  
✅ **兼容性好**：大部分HTTP客户端都支持  
✅ **易于管理**：可以在shell配置文件中永久设置  

## 永久配置

在 `~/.zshrc` 或 `~/.bashrc` 中添加：

```bash
# 添加代理配置
export HTTPS_PROXY="http://127.0.0.1:7890"
export HTTP_PROXY="http://127.0.0.1:7890"
```

然后重新加载：
```bash
source ~/.zshrc
```

## 故障排除

1. **检查代理是否工作**：
   ```bash
   curl -x http://127.0.0.1:7890 https://www.google.com
   ```

2. **检查端口是否监听**：
   ```bash
   netstat -an | grep 7890
   ```

3. **查看应用日志**，确认代理检测情况 
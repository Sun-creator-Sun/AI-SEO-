import { renderHook, act } from '@testing-library/react'
import { useAppState } from '../useAppState'

// eslint-disable-next-line @typescript-eslint/triple-slash-reference
/// <reference types="jest" />

// mock localStorage
beforeEach(() => {
  window.localStorage.clear()
})

describe('useAppState', () => {
  it('should initialize with default state', () => {
    const { result } = renderHook(() => useAppState())
    expect(result.current.currentStep).toBeDefined()
    expect(result.current.keyword).toBe('')
    expect(result.current.targetMarket).toBe('美国')
    expect(result.current.targetLanguage).toBe('英语')
  })

  it('should update state when setKeyword and setCurrentStep are called', () => {
    const { result } = renderHook(() => useAppState())
    act(() => {
      result.current.setKeyword('AI SEO')
      result.current.setCurrentStep('ideas')
    })
    expect(result.current.keyword).toBe('AI SEO')
    expect(result.current.currentStep).toBe('ideas')
  })

  it('should persist and restore state from localStorage', () => {
    // Set state and trigger persist
    const { result, unmount, rerender } = renderHook(() => useAppState())
    act(() => {
      result.current.setKeyword('persisted')
      result.current.setCurrentStep('titles')
    })
    unmount()
    // Simulate reload
    const { result: result2 } = renderHook(() => useAppState())
    expect(result2.current.keyword).toBe('persisted')
    expect(result2.current.currentStep).toBe('titles')
  })

  it('should reset state to default when localStorage is cleared', () => {
    const { result } = renderHook(() => useAppState())
    act(() => {
      result.current.setKeyword('reset-me')
      result.current.setCurrentStep('titles')
    })
    window.localStorage.clear()
    // simulate reload
    const { result: result2 } = renderHook(() => useAppState())
    expect(result2.current.keyword).toBe('')
    expect(result2.current.currentStep).toBeDefined()
  })
}) 
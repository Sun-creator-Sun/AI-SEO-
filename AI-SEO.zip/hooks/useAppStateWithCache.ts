"use client"

import { useAppState } from './useAppState'
import { 
  useSearchKeyword,
  useAnalyzeSearchIntent,
  useGenerateBlogIdeas,
  useSearchRelatedContent,
  useFilterBlogContent,
  useExtractKnowledgePoints,
  useExtractLSITerms,
  useGenerateBlogTitles,
  useExtractArticleContent,
  useAnalyzeArticleOutlines,
  useSynthesizeAnalysis,
  useGenerateBlogOutline,
  useGenerateAIKnowledge,
  useClearCache
} from './useApiQueries'
import { AppStep } from '@/components/shared/StepIndicator'
import { TitleGenerationSubStep } from '@/components/pages/TitleGeneratingPage'
import { OutlineGenerationSubStep } from '@/components/pages/OutlineGeneratingPage'

/**
 * 增强的应用状态Hook，集成TanStack Query缓存
 * 提供查询状态和缓存数据，但不直接修改状态
 */
export function useAppStateWithCache() {
  const appState = useAppState()
  const { clearSearchCache, clearBlogIdeasCache, invalidateSearchQueries, invalidateBlogQueries, invalidateTitleQueries, invalidateOutlineQueries } = useClearCache()

  // 搜索相关的查询
  const searchQuery = useSearchKeyword(
    appState.keyword,
    appState.targetMarket,
    appState.targetLanguage,
    appState.timeRange,
    appState.currentStep === AppStep.SEARCHING
  )

  const searchIntentQuery = useAnalyzeSearchIntent(
    appState.keyword,
    appState.targetMarket,
    appState.targetLanguage,
    appState.currentStep === AppStep.SEARCHING && !!searchQuery.data
  )

  const blogIdeasQuery = useGenerateBlogIdeas(
    appState.keyword,
    searchQuery.data || [],
    appState.targetMarket,
    appState.targetLanguage,
    appState.timeRange,
    parseInt(appState.pageCount),
    searchIntentQuery.data || null,
    appState.currentStep === AppStep.SEARCHING && !!searchQuery.data && !!searchIntentQuery.data
  )

  // 标题生成相关的查询
  const relatedContentQuery = useSearchRelatedContent(
    appState.keyword,
    appState.selectedIdeaIndex !== null 
      ? appState.blogIdeas[appState.selectedIdeaIndex]?.title || ''
      : appState.customIdea,
    appState.targetMarket,
    appState.targetLanguage,
    appState.timeRange,
    appState.currentStep === AppStep.TITLE_GENERATING && 
    appState.titleGenerationStep === TitleGenerationSubStep.SEARCHING_CONTENT
  )

  const filteredContentQuery = useFilterBlogContent(
    relatedContentQuery.data || appState.searchResults.slice(0, 15),
    appState.currentStep === AppStep.TITLE_GENERATING && 
    appState.titleGenerationStep === TitleGenerationSubStep.FILTERING_CONTENT &&
    !!relatedContentQuery.data
  )

  const knowledgePointsQuery = useExtractKnowledgePoints(
    filteredContentQuery.data?.map(result => `${result.title} ${result.snippet}`).join(' ') || '',
    appState.currentStep === AppStep.TITLE_GENERATING && 
    appState.titleGenerationStep === TitleGenerationSubStep.EXTRACTING_KNOWLEDGE &&
    !!filteredContentQuery.data
  )

  const lsiTermsQuery = useExtractLSITerms(
    filteredContentQuery.data || [],
    appState.keyword,
    appState.currentStep === AppStep.TITLE_GENERATING && 
    appState.titleGenerationStep === TitleGenerationSubStep.EXTRACTING_KNOWLEDGE &&
    !!filteredContentQuery.data
  )

  const blogTitlesQuery = useGenerateBlogTitles(
    appState.keyword,
    appState.selectedIdeaIndex !== null 
      ? appState.blogIdeas[appState.selectedIdeaIndex]?.title || ''
      : appState.customIdea,
    appState.extractedKnowledge,
    appState.additionalRequirements,
    filteredContentQuery.data?.map(result => result.title) || [],
    lsiTermsQuery.data || [],
    appState.currentStep === AppStep.TITLE_GENERATING && 
    appState.titleGenerationStep === TitleGenerationSubStep.GENERATING_TITLES &&
    !!filteredContentQuery.data && !!lsiTermsQuery.data
  )

  // 大纲生成相关的查询
  const articleContentQuery = useExtractArticleContent(
    appState.searchResults.slice(0, 8).map(result => result.url),
    appState.currentStep === AppStep.OUTLINE_GENERATING && 
    appState.outlineGenerationStep === OutlineGenerationSubStep.EXTRACTING_CONTENT
  )

  const articleAnalysisQuery = useAnalyzeArticleOutlines(
    articleContentQuery.data || [],
    appState.selectedTitleIndex !== null 
      ? appState.generatedTitles[appState.selectedTitleIndex]?.title || ''
      : appState.customTitle,
    appState.currentStep === AppStep.OUTLINE_GENERATING && 
    appState.outlineGenerationStep === OutlineGenerationSubStep.ANALYZING_OUTLINES &&
    !!articleContentQuery.data
  )

  const synthesisQuery = useSynthesizeAnalysis(
    articleAnalysisQuery.data || [],
    articleContentQuery.data || [],
    appState.currentStep === AppStep.OUTLINE_GENERATING && 
    appState.outlineGenerationStep === OutlineGenerationSubStep.SYNTHESIZING_ANALYSIS &&
    !!articleAnalysisQuery.data
  )

  const blogOutlineQuery = useGenerateBlogOutline(
    appState.keyword,
    appState.selectedTitleIndex !== null 
      ? appState.generatedTitles[appState.selectedTitleIndex]?.title || ''
      : appState.customTitle,
    synthesisQuery.data || '',
    appState.extractedKnowledge,
    appState.wordCount,
    appState.readabilityLevel,
    appState.toneStyle,
    appState.perspective,
    appState.outlineRequirements,
    appState.extractedLSITerms,
    appState.additionalInfo,
    appState.knowledgeSource,
    articleAnalysisQuery.data?.map((analysis, index) => ({
      title: analysis.title,
      outline: analysis.outline,
      style: analysis.style,
      tone: analysis.tone,
      structure: analysis.structure,
      keyPoints: analysis.keyPoints,
      url: analysis.url,
      index: index + 1
    })) || [],
    appState.currentStep === AppStep.OUTLINE_GENERATING && 
    appState.outlineGenerationStep === OutlineGenerationSubStep.GENERATING_OUTLINE &&
    !!synthesisQuery.data
  )

  // AI知识库查询
  const aiKnowledgeQuery = useGenerateAIKnowledge(
    appState.keyword,
    appState.targetMarket,
    appState.targetLanguage,
    appState.selectedIdeaIndex !== null 
      ? appState.blogIdeas[appState.selectedIdeaIndex]?.title
      : undefined,
    appState.customIdea || undefined,
    appState.knowledgeSource,
    appState.currentStep === AppStep.OUTLINE_GENERATING && 
    appState.outlineGenerationStep === OutlineGenerationSubStep.GENERATING_OUTLINE
  )

  // 缓存管理函数
  const clearAllCache = () => {
    clearSearchCache(appState.keyword, appState.targetMarket, appState.targetLanguage, appState.timeRange)
    clearBlogIdeasCache(appState.keyword, appState.targetMarket, appState.targetLanguage, appState.timeRange, parseInt(appState.pageCount))
  }

  const refreshSearchData = () => {
    invalidateSearchQueries()
    invalidateBlogQueries()
  }

  const refreshTitleData = () => {
    invalidateTitleQueries()
  }

  const refreshOutlineData = () => {
    invalidateOutlineQueries()
  }

  return {
    ...appState,
    // 查询状态
    searchQuery,
    searchIntentQuery,
    blogIdeasQuery,
    relatedContentQuery,
    filteredContentQuery,
    knowledgePointsQuery,
    lsiTermsQuery,
    blogTitlesQuery,
    articleContentQuery,
    articleAnalysisQuery,
    synthesisQuery,
    blogOutlineQuery,
    aiKnowledgeQuery,
    // 缓存管理
    clearAllCache,
    refreshSearchData,
    refreshTitleData,
    refreshOutlineData,
  }
} 
"use client"

import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import { AppStep } from '@/components/shared/StepIndicator'
import { TitleGenerationSubStep } from '@/components/pages/TitleGeneratingPage'
import { OutlineGenerationSubStep } from '@/components/pages/OutlineGeneratingPage'
import { 
  searchKeyword, 
  generateBlogIdeas, 
  analyzeSearchIntent, 
  searchRelatedContent,
  filterBlogContent as filterBlogContentAPI,
  extractKnowledgePoints as extractKnowledgePointsAPI,
  extractLSITerms,
  generateBlogTitles as generateBlogTitlesAPI,
  extractArticleContent,
  analyzeArticleOutlines,
  generateBlogOutline,
  type SearchResult, 
  type BlogIdea, 
  type SearchIntent,
  type BlogTitle,
  type BlogOutline,
  type ArticleAnalysis
} from '@/lib/google-search'
import { synthesizeAnalysis as synthesizeAnalysisAPI } from '@/lib/outline-generation'
import { generateAIKnowledge } from '@/lib/ai-knowledge'
import { 
  validateContentQuality, 
  filterValidContentObjects,
  type ContentObject 
} from '@/lib/content-validation'
import { 
  startContentGeneration as startContentGenerationAPI,
  ArticleDraftStep,
  ContentGenerationParams
} from '@/lib/content-generation'
import { Evidence, SectionEvidenceRequirement } from '@/lib/article-generation'
import { handleApiError, withErrorHandling } from '@/lib/error-handler'

/**
 * 从文本中提取知识点
 * @param text - 文本内容
 * @param keyword - 主关键词
 * @returns 提取的知识点数组
 */
function extractKnowledgeFromText(text: string, keyword: string): string[] {
  if (!text.trim()) return [];
  
  const knowledge: string[] = [];
  const stopWords = ['的', '是', '在', '有', '和', '与', '或', '但', '而', '了', '也', '就', '都', '要', '可以', '能够', '应该', '需要', '可能', '会', '将', '已经', '正在', '通过', '由于', '因为', '所以', '如果', '虽然', '但是', '然而', '因此', '这样', '那样', '这些', '那些', '这个', '那个', '一个', '一些', '很多', '非常', '特别', 'the', 'and', 'for', 'with', 'that', 'this', 'from', 'they', 'have', 'been', 'will', 'can', 'should', 'would', 'could', 'may', 'might', 'must', 'shall', 'very', 'much', 'many', 'some', 'any', 'all', 'each', 'every', 'most', 'more', 'less', 'few', 'little', 'big', 'small', 'good', 'bad', 'new', 'old'];
  
  // 按句子分割文本
  const sentences = text.split(/[。！？.!?]+/).filter(s => s.trim().length > 5);
  
  sentences.forEach(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length > 10 && trimmed.length < 200) {
      // 提取包含关键词的句子
      if (trimmed.toLowerCase().includes(keyword.toLowerCase())) {
        knowledge.push(trimmed);
      }
      
      // 提取关键短语（以冒号、分号分割）
      const phrases = trimmed.split(/[：；:;]/).filter(p => p.trim().length > 5);
      phrases.forEach(phrase => {
        const cleanPhrase = phrase.trim();
        if (cleanPhrase.length > 5 && cleanPhrase.length < 100) {
          knowledge.push(cleanPhrase);
        }
      });
    }
  });
  
  // 提取关键词（去除停用词）
  const words = text.split(/[\s\n\r\t,，。！？.!?；：;:]+/)
    .filter(word => 
      word.length > 2 && 
      !stopWords.includes(word.toLowerCase()) &&
      !word.match(/^\d+$/) // 排除纯数字
    )
    .slice(0, 20);
  
  knowledge.push(...words);
  
  // 去重并限制数量
  const uniqueKnowledge = Array.from(new Set(knowledge))
    .filter(item => item.length > 2)
    .slice(0, 15);
  
  return uniqueKnowledge;
}

function safeGetLocalStorage() {
  if (typeof window !== 'undefined' && window.localStorage) {
    return window.localStorage
  }
  return null
}

function getStorageKey(sessionId: string | null) {
  return sessionId ? `vertu-seo-session-${sessionId}` : null
}

function loadPersistedState(sessionId: string | null) {
  if (!sessionId) return null
  try {
    const storage = safeGetLocalStorage()
    if (!storage) return null
    const storageKey = getStorageKey(sessionId)
    if (!storageKey) return null
    const raw = storage.getItem(storageKey)
    if (!raw) return null
    return JSON.parse(raw)
  } catch {
    return null
  }
}

function persistState(state: Record<string, unknown>, sessionId: string | null) {
  if (!sessionId) return
  try {
    const storage = safeGetLocalStorage()
    if (!storage) return
    const storageKey = getStorageKey(sessionId)
    if (!storageKey) return
    storage.setItem(storageKey, JSON.stringify(state))
  } catch {}
}

/**
 * 应用状态管理Hook
 */
export function useAppState() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get('sessionId') || 'default'
  
  // 1. 尝试恢复
  const persisted = loadPersistedState(sessionId)

  // 基础状态
  const [currentStep, setCurrentStep] = useState<AppStep>(persisted?.currentStep ?? AppStep.INPUT) // 直接跳转到设置页面
  const [keyword, setKeyword] = useState(persisted?.keyword ?? '') // 模拟关键词
  const [targetMarket, setTargetMarket] = useState(persisted?.targetMarket ?? '美国')
  const [targetLanguage, setTargetLanguage] = useState(persisted?.targetLanguage ?? '英语')
  const [pageCount, setPageCount] = useState(persisted?.pageCount ?? '2')
  const [timeRange, setTimeRange] = useState(persisted?.timeRange ?? '任何时候')
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [blogIdeas, setBlogIdeas] = useState<BlogIdea[]>(persisted?.blogIdeas ?? [])
  const [searchIntent, setSearchIntent] = useState<SearchIntent | null>(null)
  const [progress, setProgress] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [customIdea, setCustomIdea] = useState(persisted?.customIdea ?? '')
  const [selectedIdeaIndex, setSelectedIdeaIndex] = useState<number | null>(persisted?.selectedIdeaIndex ?? 0) // 模拟选中第一个想法
  const [additionalInfo, setAdditionalInfo] = useState('')
  const [additionalRequirements, setAdditionalRequirements] = useState('')
  const [autoInsertLSI, setAutoInsertLSI] = useState(true)
  // 知识来源状态
  const [knowledgeSource, setKnowledgeSource] = useState(persisted?.knowledgeSource ?? '')
  
  // 标题生成相关状态
  const [titleGenerationStep, setTitleGenerationStep] = useState<TitleGenerationSubStep>(TitleGenerationSubStep.SEARCHING_CONTENT)
  const [titleGenerationProgress, setTitleGenerationProgress] = useState(0)
  const [relatedSearchResults, setRelatedSearchResults] = useState<SearchResult[]>([])
  const [filteredBlogContent, setFilteredBlogContent] = useState<SearchResult[]>(persisted?.filteredBlogContent ?? [])
  const [latestFilteredResults, setLatestFilteredResults] = useState<SearchResult[]>([])
  const [extractedKnowledge, setExtractedKnowledge] = useState<string[]>([])
  const [extractedLSITerms, setExtractedLSITerms] = useState<string[]>([])
  const [generatedTitles, setGeneratedTitles] = useState<BlogTitle[]>(persisted?.generatedTitles ?? [])
  const [selectedTitleIndex, setSelectedTitleIndex] = useState<number | null>(persisted?.selectedTitleIndex ?? 0) // 模拟选中第一个标题
  const [customTitle, setCustomTitle] = useState(persisted?.customTitle ?? '') // 用户自定义的标题
  
  // 大纲生成配置状态
  const [wordCount, setWordCount] = useState('1000-2000')
  const [readabilityLevel, setReadabilityLevel] = useState('中学')
  const [toneStyle, setToneStyle] = useState('口语/非正式')
  const [perspective, setPerspective] = useState('第二人称视角')
  const [outlineRequirements, setOutlineRequirements] = useState('')
  
  // 大纲生成相关状态
  const [outlineGenerationStep, setOutlineGenerationStep] = useState<OutlineGenerationSubStep>(OutlineGenerationSubStep.EXTRACTING_CONTENT)
  const [outlineGenerationProgress, setOutlineGenerationProgress] = useState(0)
  const [outlineGenerationError, setOutlineGenerationError] = useState<string | null>(null)
  const [extractedContents, setExtractedContents] = useState<string[]>([])
  const [extractedContentObjects, setExtractedContentObjects] = useState<ContentObject[]>([])
  const [articleAnalyses, setArticleAnalyses] = useState<ArticleAnalysis[]>([])
  const [synthesisReport, setSynthesisReport] = useState('')
  const [generatedOutline, setGeneratedOutline] = useState<BlogOutline | null>(persisted?.generatedOutline ?? null)
  const [aiKnowledge, setAiKnowledge] = useState<string[]>([]) // AI知识库生成的知识点

  // 页面访问历史和缓存状态 - 模拟已完成所有步骤
  const [visitedSteps, setVisitedSteps] = useState<AppStep[]>([
    AppStep.INPUT, 
    AppStep.IDEAS, 
    AppStep.TITLES, 
    AppStep.OUTLINE, 
    AppStep.SETTINGS
  ])
  const [stepDataCache, setStepDataCache] = useState<Record<string, boolean>>({
    [AppStep.IDEAS]: true,
    [AppStep.TITLES]: true,
    [AppStep.OUTLINE]: true,
    [AppStep.SETTINGS]: true
  })

  // 设置页面状态
  const [articleRequirements, setArticleRequirements] = useState('')
  const [addFactsAndEvidence, setAddFactsAndEvidence] = useState(true)
  const [searchRegion, setSearchRegion] = useState('美国')
  const [contentLanguage, setContentLanguage] = useState('英语')
  const [autoInsertInternalLinks, setAutoInsertInternalLinks] = useState(true)
  const [anchorTextAutomation, setAnchorTextAutomation] = useState(true)
  const [autoInsertExternalLinks, setAutoInsertExternalLinks] = useState(true)
  const [externalDomainWhitelist, setExternalDomainWhitelist] = useState(false)
  const [addBlogCoverImage, setAddBlogCoverImage] = useState(true)
  const [addImagesUnderH2, setAddImagesUnderH2] = useState(true)
  const [addKeyPoints, setAddKeyPoints] = useState(true)
  const [addFAQSection, setAddFAQSection] = useState(true)
  const [addMoreRecommendations, setAddMoreRecommendations] = useState(false)
  const [customLinks, setCustomLinks] = useState<Array<{ url: string; anchor: string }>>([])
  const [customAnchorLinks, setCustomAnchorLinks] = useState<Array<{ url: string; anchor: string }>>([])

  // 文章生成状态
  const [isGeneratingArticle, setIsGeneratingArticle] = useState(false)
  const [articleGenerationStep, setArticleGenerationStep] = useState(1)
  const [articleGenerationMessage, setArticleGenerationMessage] = useState('')
  const [generatedEvidence, setGeneratedEvidence] = useState<Evidence[]>([])
  
  // 文章草稿页面状态
  const [evidenceRequirements, setEvidenceRequirements] = useState<SectionEvidenceRequirement[]>([])
  const [articleDraftStep, setArticleDraftStep] = useState(1) // ArticleDraftStep枚举值
  const [articleDraftMessage, setArticleDraftMessage] = useState('')
  const [generatedContent, setGeneratedContent] = useState('')
  const [isGeneratingContent, setIsGeneratingContent] = useState(false)

  /**
   * 处理关键词搜索
   */
  const handleSearch = async () => {
    if (!keyword.trim()) return

    setIsLoading(true)
    setCurrentStep(AppStep.SEARCHING)
    setProgress(0)

    try {
      // 第一步：搜索内容 (0-50%)
      setProgress(10)
      
      // 搜索关键词
      const results = await searchKeyword(keyword, targetMarket, targetLanguage, timeRange)
      setSearchResults(results)
      setProgress(50) // 第一步完成
      
      // 第二步：分析意图和生成灵感 (50-100%)
      setProgress(60)
      
      // 分析搜索意图
      const intent = await analyzeSearchIntent(keyword, targetMarket, targetLanguage)
      setSearchIntent(intent)
      setProgress(80)
      
      // 生成博客灵感
      const ideas = await generateBlogIdeas(keyword, results, parseInt(pageCount), timeRange, intent)
      setBlogIdeas(ideas)
      setProgress(100) // 第二步完成
      
      // 延迟跳转到结果页面
      setTimeout(() => {
        setCurrentStep(AppStep.IDEAS)
        setIsLoading(false)
        // 更新访问历史和缓存状态
        setVisitedSteps(prev => {
          if (!prev.includes(AppStep.IDEAS)) {
            return [...prev, AppStep.IDEAS];
          }
          return prev;
        });
        setStepDataCache(prev => ({ ...prev, [AppStep.IDEAS]: true }));
      }, 1000)
      
    } catch (error) {
      console.error('搜索失败:', error)
      setIsLoading(false)
      setCurrentStep(AppStep.INPUT)
    }
  }

  /**
   * 返回上一步
   */
  const handleBack = () => {
    if (currentStep === AppStep.IDEAS) {
      setCurrentStep(AppStep.INPUT)
    } else if (currentStep === AppStep.TITLES) {
      setCurrentStep(AppStep.IDEAS)
    } else if (currentStep === AppStep.OUTLINE) {
      setCurrentStep(AppStep.TITLES)
    } else if (currentStep === AppStep.SETTINGS) {
      setCurrentStep(AppStep.OUTLINE)
    }
  }

  /**
   * 前进到下一步（基于访问历史）
   */
  const handleNext = () => {
    const currentIndex = visitedSteps.indexOf(currentStep);
    if (currentIndex >= 0 && currentIndex < visitedSteps.length - 1) {
      const nextStep = visitedSteps[currentIndex + 1];
      setCurrentStep(nextStep);
    }
  }

  /**
   * 检查是否可以前进到下一步
   */
  const canGoNext = () => {
    const currentIndex = visitedSteps.indexOf(currentStep);
    return currentIndex >= 0 && currentIndex < visitedSteps.length - 1;
  }

  /**
   * 处理创意选择
   */
  const handleIdeaSelect = (index: number) => {
    setSelectedIdeaIndex(index === selectedIdeaIndex ? null : index);
  }

  /**
   * 生成标题
   */
  const generateTitle = async () => {
    // 检查是否选择了博客创意或输入了自定义创意
    const selectedIdea = selectedIdeaIndex !== null ? blogIdeas[selectedIdeaIndex] : null;
    if (!selectedIdea && !customIdea.trim()) {
      alert('请先选择一个博客创意或输入您的想法');
      return;
    }

    setCurrentStep(AppStep.TITLE_GENERATING);
    setTitleGenerationStep(TitleGenerationSubStep.SEARCHING_CONTENT);
    setTitleGenerationProgress(0);

    try {
      // 步骤1：使用谷歌搜索与博客主题相关的更多内容作为参考
      const relatedResults = await performRelatedContentSearch(selectedIdea, customIdea);
      
      // 步骤2：过滤出搜索结果中与主题相关的博客类型内容作为参考
      const filteredResults = await filterBlogContent(relatedResults);
      
      // 步骤3：从过滤的搜索结果中智能提取SEO知识点（传递过滤结果）
      const extractedLSITermsFromStep3 = await extractKnowledgePoints(filteredResults);
      
      // 步骤4：用知识点+额外要求+参考文章标题+SERPs生成博客标题
      await generateBlogTitles(selectedIdea, customIdea, filteredResults, extractedLSITermsFromStep3);
      
      // 完成后跳转到标题展示页面
      setCurrentStep(AppStep.TITLES);
      // 更新访问历史和缓存状态
      setVisitedSteps(prev => {
        if (!prev.includes(AppStep.TITLES)) {
          return [...prev, AppStep.TITLES];
        }
        return prev;
      });
      setStepDataCache(prev => ({ ...prev, [AppStep.TITLES]: true }));
      
    } catch (error) {
      console.error('标题生成失败:', error);
      setCurrentStep(AppStep.IDEAS);
      
      // 使用新的错误处理器显示友好的错误提示
      handleApiError(
        error,
        generateTitle, // 重试函数
        '标题生成失败'
      );
    }
  }

  /**
   * 步骤1：搜索与博客主题相关的更多内容
   */
  const performRelatedContentSearch = async (selectedIdea: BlogIdea | null, customIdea: string): Promise<SearchResult[]> => {
    setTitleGenerationStep(TitleGenerationSubStep.SEARCHING_CONTENT);
    setTitleGenerationProgress(25);
    
    // 构建博客创意文本
    const ideaText = selectedIdea ? selectedIdea.title : customIdea;
    
    try {
      // 调用新的搜索API获取相关内容
      const results = await searchRelatedContent(keyword, ideaText, targetMarket, targetLanguage, timeRange);
      console.log('相关内容搜索结果:', results);
      
      // 如果搜索结果为空，使用原始搜索结果作为备用
      if (results.length === 0) {
        console.log('相关内容搜索结果为空，使用原始搜索结果作为备用');
        const fallbackResults = searchResults.slice(0, 15);
        setRelatedSearchResults(fallbackResults);
        return fallbackResults;
      } else {
        setRelatedSearchResults(results);
        return results;
      }
    } catch (error) {
      console.error('相关内容搜索失败，使用原始搜索结果作为备用:', error);
      const fallbackResults = searchResults.slice(0, 15);
      setRelatedSearchResults(fallbackResults);
      return fallbackResults;
    }
  };

  /**
   * 步骤2：过滤出博客类型内容
   */
  const filterBlogContent = async (relatedResults: SearchResult[]): Promise<SearchResult[]> => {
    setTitleGenerationStep(TitleGenerationSubStep.FILTERING_CONTENT);
    setTitleGenerationProgress(50);
    
    console.log('开始过滤博客内容，相关搜索结果数量:', relatedResults.length);
    
    // 确保有搜索结果可以过滤
    const resultsToFilter = relatedResults.length > 0 ? relatedResults : searchResults.slice(0, 15);
    console.log('用于过滤的搜索结果数量:', resultsToFilter.length);
    
    try {
      // 使用AI增强的API函数过滤博客内容
      const filtered = await filterBlogContentAPI(resultsToFilter, keyword);
      console.log('AI过滤后的博客内容数量:', filtered.length);
      
      let finalResults: SearchResult[];
      
      // 如果过滤后结果为空，使用原始搜索结果
      if (filtered.length === 0 && resultsToFilter.length > 0) {
        console.log('AI过滤后结果为空，使用原始搜索结果');
        finalResults = resultsToFilter.slice(0, 10);
      } else {
        finalResults = filtered;
      }
      
      // 更新状态
      setFilteredBlogContent(finalResults);
      // 同时更新最新过滤结果状态，确保数据一致性
      setLatestFilteredResults(finalResults);
      
      // 模拟延迟
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return finalResults;
    } catch (error) {
      console.error('AI博客内容过滤失败:', error);
      // 如果AI过滤失败，使用原始搜索结果
      const fallbackResults = resultsToFilter.slice(0, 10);
      setFilteredBlogContent(fallbackResults);
      // 同时更新最新过滤结果状态
      setLatestFilteredResults(fallbackResults);
      
      // 模拟延迟
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return fallbackResults;
    }
  };

  /**
   * 步骤3：从过滤的搜索结果中智能提取SEO知识点
   */
  const extractKnowledgePoints = async (filteredResults: SearchResult[]): Promise<string[]> => {
    setTitleGenerationStep(TitleGenerationSubStep.EXTRACTING_KNOWLEDGE);
    setTitleGenerationProgress(75);
    
    console.log('开始从过滤的搜索结果中智能提取SEO知识点');
    console.log('过滤后博客内容数量:', filteredResults.length);
    
    // 如果没有过滤的内容，使用备用方法
    if (filteredResults.length === 0) {
      console.log('没有过滤的博客内容，使用附加信息作为备用');
      if (additionalInfo.trim()) {
        const knowledge = extractKnowledgeFromText(additionalInfo, keyword);
        setExtractedKnowledge(knowledge);
      } else {
        setExtractedKnowledge([]);
      }
      
      // 清空LSI术语
      setExtractedLSITerms([]);
      
      return []; // 返回空数组
    }
    
    try {
      // 使用统一的API函数进行知识点提取
      // 将搜索结果转换为文本内容
      const contentText = filteredResults.map(r => `${r.title} ${r.snippet}`).join(' ');
      const knowledge = await extractKnowledgePointsAPI(contentText);
      console.log('提取的SEO知识点数量:', knowledge.length);
      console.log('提取的SEO知识点:', knowledge);
      
      setExtractedKnowledge(knowledge);
      
      // 如果用户勾选了自动插入LSI术语，则进行LSI术语提取
      if (autoInsertLSI) {
        console.log('用户已启用自动插入LSI术语，开始提取LSI术语...');
        try {
          const lsiTerms = await extractLSITerms(filteredResults, keyword);
          console.log('提取的LSI术语数量:', lsiTerms.length);
          console.log('提取的LSI术语:', lsiTerms);
          
          setExtractedLSITerms(lsiTerms);
          return lsiTerms; // 直接返回提取的LSI术语
        } catch (lsiError) {
          console.error('LSI术语提取失败:', lsiError);
          setExtractedLSITerms([]);
          return []; // 返回空数组
        }
      } else {
        console.log('用户未启用自动插入LSI术语功能');
        setExtractedLSITerms([]);
        return []; // 返回空数组
      }
      
    } catch (error) {
      console.error('知识点提取失败，使用备用方法:', error);
      
      // 备用方法：从搜索结果标题和摘要中提取关键词
      const fallbackKnowledge = extractKnowledgeFromText(
        filteredResults.map(r => `${r.title} ${r.snippet}`).join(' '),
        keyword
      );
      console.log('备用方法提取的知识点:', fallbackKnowledge);
      
      setExtractedKnowledge(fallbackKnowledge);
      setExtractedLSITerms([]); // 出错时清空LSI术语
      return []; // 返回空数组
    }
  };

  /**
   * 步骤4：用知识点+额外要求+参考文章标题+SERPs生成博客标题
   */
  const generateBlogTitles = async (selectedIdea: BlogIdea | null, customIdea: string, filteredResults: SearchResult[], extractedLSITerms: string[]): Promise<void> => {
    setTitleGenerationStep(TitleGenerationSubStep.GENERATING_TITLES);
    setTitleGenerationProgress(100);
    
    // 构建参数
    const ideaText = selectedIdea ? selectedIdea.title : customIdea;
    
    // 添加详细的调试信息
    console.log('=== 生成标题时的参数检查 ===');
    console.log('传入的filteredResults.length:', filteredResults.length);
    console.log('searchResults.length:', searchResults.length);
    console.log('relatedSearchResults.length:', relatedSearchResults.length);
    console.log('extractedLSITerms.length:', extractedLSITerms.length);
    console.log('autoInsertLSI状态:', autoInsertLSI);
    
    // 使用传入的过滤结果，而不是依赖状态（因为React状态更新是异步的）
    let contentForTitles: SearchResult[];
    if (filteredResults.length > 0) {
      contentForTitles = filteredResults;
      console.log('使用传入的过滤后博客内容:', contentForTitles.length, '个');
    } else if (relatedSearchResults.length > 0) {
      contentForTitles = relatedSearchResults.slice(0, 10);
      console.log('使用相关搜索结果:', contentForTitles.length, '个');
    } else {
      contentForTitles = searchResults.slice(0, 10);
      console.log('使用原始搜索结果:', contentForTitles.length, '个');
    }
    
    const referenceTitles = contentForTitles.map(r => r.title);
    
    console.log('最终用于生成标题的参考内容数量:', contentForTitles.length);
    console.log('参考标题数量:', referenceTitles.length);
    console.log('参考标题列表:', referenceTitles.slice(0, 3)); // 只显示前3个标题
    console.log('传递的LSI术语数量:', extractedLSITerms.length);
    console.log('传递的LSI术语列表:', extractedLSITerms.slice(0, 5)); // 只显示前5个LSI术语
    
    // 使用API函数生成标题，包含LSI术语
    const titles = await generateBlogTitlesAPI(
      keyword,
      ideaText,
      extractedKnowledge,
      additionalRequirements,
      referenceTitles,
      extractedLSITerms // 使用传递的LSI术语
    );
    
    setGeneratedTitles(titles);
    
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 1000));
  };

  /**
   * 生成大纲
   */
  const generateOutline = async () => {
    // 检查是否选择了标题或输入了自定义标题
    let selectedTitle: string;
    if (selectedTitleIndex !== null && generatedTitles[selectedTitleIndex]) {
      selectedTitle = generatedTitles[selectedTitleIndex].title;
    } else if (customTitle.trim()) {
      selectedTitle = customTitle.trim();
    } else {
      alert('请先选择一个标题或输入自定义标题');
      return;
    }
    
    // 清除之前的错误状态
    setOutlineGenerationError(null);
    setCurrentStep(AppStep.OUTLINE_GENERATING);
    setOutlineGenerationStep(OutlineGenerationSubStep.EXTRACTING_CONTENT);
    setOutlineGenerationProgress(0);

    try {
      // 步骤1：从URL中抓取引用文章内容
      const extractedContentObjects = await extractContentFromUrls();
      
      // 步骤2：提炼并分析每篇文章的大纲和风格
      const articleAnalyses = await analyzeExtractedContent(extractedContentObjects, selectedTitle);
      
      // 步骤3：综合分析文章特点
      const synthesisReport = await synthesizeAnalysis(extractedContentObjects, articleAnalyses);
      
      // 步骤4：根据提取的知识和要求生成文章大纲
      await generateFinalOutline(selectedTitle, synthesisReport, articleAnalyses, extractedContentObjects);
      
      // 完成后跳转到大纲展示页面
      setCurrentStep(AppStep.OUTLINE);
      // 更新访问历史和缓存状态
      setVisitedSteps(prev => {
        if (!prev.includes(AppStep.OUTLINE)) {
          return [...prev, AppStep.OUTLINE];
        }
        return prev;
      });
      setStepDataCache(prev => ({ ...prev, [AppStep.OUTLINE]: true }));
      
    } catch (error) {
      console.error('大纲生成失败:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      setOutlineGenerationError(errorMessage);
      
      // 使用新的错误处理器显示友好的错误提示
      handleApiError(
        error,
        generateOutline, // 重试函数
        '大纲生成失败'
      );
      // 保持在当前页面，显示错误信息
    }
  };

  /**
   * 步骤1：从URL中抓取引用文章内容
   */
  const extractContentFromUrls = async () => {
    setOutlineGenerationStep(OutlineGenerationSubStep.EXTRACTING_CONTENT);
    setOutlineGenerationProgress(25);
    
    // 使用最新的过滤结果而不是可能过时的状态数据
    const urlsSource = latestFilteredResults.length > 0 ? latestFilteredResults : filteredBlogContent;
    
    if (urlsSource.length === 0) {
      throw new Error('没有可用的文章URL进行内容抓取');
    }
    
    // 按AI相关性评分排序
    const sortedByAIScore = urlsSource
      .filter(content => content.aiRelevanceScore !== undefined) // 过滤掉没有评分的
      .sort((a, b) => (b.aiRelevanceScore || 0) - (a.aiRelevanceScore || 0)); // 按评分降序排列
    
    // 如果按评分过滤后数量不足，用原始数据补充
    let sortedUrlsSource = sortedByAIScore;
    if (sortedUrlsSource.length < urlsSource.length) {
      const remaining = urlsSource
        .filter(content => !sortedByAIScore.includes(content)); // 排除已选中的
      sortedUrlsSource = [...sortedByAIScore, ...remaining];
    }
    
    console.log('可用文章总数:', sortedUrlsSource.length);
    console.log('AI评分文章数量:', sortedByAIScore.length);
    
    let successfulContents: ContentObject[] = [];
    let attemptedUrls: string[] = [];
    let failedUrls: string[] = [];
    const targetCount = 3; // 目标抓取3篇文章
    
    // 逐步尝试抓取文章，直到获得3篇成功内容或用完所有URL
    for (let startIndex = 0; startIndex < sortedUrlsSource.length && successfulContents.length < targetCount; startIndex++) {
      // 计算本次要尝试的文章数量
      const remainingNeeded = targetCount - successfulContents.length;
      const remainingAvailable = sortedUrlsSource.length - startIndex;
      const batchSize = Math.min(remainingNeeded + 2, remainingAvailable); // 多取几个作为备选
      
      const currentBatch = sortedUrlsSource.slice(startIndex, startIndex + batchSize);
      const currentUrls = currentBatch.map(content => content.url);
      
      console.log(`尝试抓取第${startIndex + 1}-${startIndex + batchSize}批文章:`, currentUrls);
      
      try {
        // 调用抓取函数
        const contents = await extractArticleContent(currentUrls);
        
        // 检查每个抓取结果
        for (let i = 0; i < contents.length; i++) {
          const content = contents[i];
          const sourceInfo = currentBatch[i];
          const url = sourceInfo.url;
          
          attemptedUrls.push(url);
          
          // 使用工具函数验证内容质量
          const validation = validateContentQuality(content, 100);
          
          if (validation.isValid) {
            // 成功抓取的内容
            successfulContents.push({
              url: url,
              title: sourceInfo.title || `文章${successfulContents.length + 1}`,
              content: content,
              aiRelevanceScore: sourceInfo.aiRelevanceScore,
              index: successfulContents.length + 1
            });
            
            console.log(`✅ 成功抓取文章: ${sourceInfo.title}`);
            
            // 如果已经获得足够的内容，跳出循环
            if (successfulContents.length >= targetCount) {
              break;
            }
          } else {
            // 抓取失败的URL
            failedUrls.push(url);
            
            console.warn(`❌ 抓取失败: ${url} - ${validation.failureReason} (内容长度: ${content?.length || 0})`);
          }
        }
        
        // 更新startIndex，避免重复处理已经尝试过的URL
        startIndex += batchSize - 1; // -1因为for循环会自动+1
        
      } catch (error) {
        console.error(`批量抓取失败:`, error);
        failedUrls.push(...currentUrls);
        
        // 更新startIndex
        startIndex += batchSize - 1;
      }
      
      // 避免请求过于频繁
      if (startIndex + 1 < sortedUrlsSource.length && successfulContents.length < targetCount) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    console.log(`=== 抓取结果统计 ===`);
    console.log(`尝试的URL数量: ${attemptedUrls.length}`);
    console.log(`成功抓取数量: ${successfulContents.length}`);
    console.log(`失败URL数量: ${failedUrls.length}`);
    console.log(`失败的URLs:`, failedUrls);
    
    // 检查是否有任何成功的内容
    if (successfulContents.length === 0) {
      throw new Error(`所有文章都无法正确获取内容。尝试了${attemptedUrls.length}个URL，全部失败。失败原因可能包括404、50x错误或内容为空。`);
    }
    
    // 如果成功数量少于目标数量，给出警告但不抛出错误
    if (successfulContents.length < targetCount) {
      console.warn(`⚠️ 只成功抓取了${successfulContents.length}篇文章，少于目标的${targetCount}篇`);
    }
    
    console.log('成功抓取的文章:', successfulContents.map(c => ({ 
      title: c.title, 
      score: c.aiRelevanceScore || '无评分',
      url: c.url,
      contentLength: c.content.length
    })));
    
    // 创建向后兼容的内容数组
    const contents = successfulContents.map(c => c.content);
    
    // 保存内容数组（用于向后兼容）
    setExtractedContents(contents);
    // 保存完整的内容对象数组（包含URL和标题信息）
    setExtractedContentObjects(successfulContents);
    
    // 简单等待状态更新完成
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 直接返回成功抓取的内容对象，避免依赖异步状态更新
    return successfulContents;
  };

  /**
   * 步骤2：提炼并分析每篇文章的大纲和风格
   */
  const analyzeExtractedContent = async (extractedContentObjects: ContentObject[], selectedTitle?: string) => {
    setOutlineGenerationStep(OutlineGenerationSubStep.ANALYZING_OUTLINES);
    setOutlineGenerationProgress(50);
    
    // 检查传入的内容对象是否有数据
    if (!extractedContentObjects || extractedContentObjects.length === 0) {
      throw new Error('没有成功抓取的文章内容，无法进行分析');
    }
    
    // 获取选定的标题，用于相关性过滤
    // 优先使用传入的标题，如果没有则从状态中获取
    let titleForAnalysis: string | undefined = selectedTitle;
    if (!titleForAnalysis) {
      if (selectedTitleIndex !== null && generatedTitles[selectedTitleIndex]) {
        titleForAnalysis = generatedTitles[selectedTitleIndex].title;
      } else if (customTitle.trim()) {
        titleForAnalysis = customTitle.trim();
      }
    }
    
    console.log('开始分析成功抓取的文章大纲和风格');
    console.log('成功抓取的文章数量:', extractedContentObjects.length);
    console.log('选定的标题:', titleForAnalysis || '未选择标题');
    console.log('标题来源:', 
      selectedTitleIndex !== null ? '从生成列表中选择' : 
      customTitle.trim() ? '用户自定义输入' : 
      '传入参数或未提供标题'
    );
    console.log('成功抓取的文章详情:', extractedContentObjects.map(c => ({ 
      url: c.url, 
      title: c.title.substring(0, 50) + '...', 
      score: c.aiRelevanceScore || '无评分',
      contentLength: c.content.length 
    })));
    
    // 直接使用传入的内容对象中已经过滤过的有效内容
    const contentTexts = extractedContentObjects.map(c => c.content);
    
    console.log('准备分析的内容数量:', contentTexts.length);
    console.log('内容长度摘要:', contentTexts.map((text, index) => `文章${index + 1}: ${text.length}字符`));
    
    // 调用分析函数，传入选定的标题进行相关性过滤
    const analyses = await analyzeArticleOutlines(contentTexts, titleForAnalysis);
    console.log('=== 相关性过滤后的分析结果 ===');
    console.log('过滤前文章数量:', extractedContentObjects.length);
    console.log('过滤后分析结果数量:', analyses.length);
    
    // 如果没有通过相关性检查的文章，给出警告
    if (analyses.length === 0) {
      console.warn('⚠️ 所有文章都与选定标题不相关，无法进行后续分析');
      throw new Error('所有抓取的文章内容都与选定标题不相关，请检查标题选择或重新抓取相关内容');
    }
    
    // 由于某些文章可能被过滤掉，需要重新映射文章信息
    // 只保留通过相关性检查的文章对象
    let filteredContentObjects = [];
    
    // 基于分析结果数量重新匹配内容对象
    // 由于相关性过滤可能导致某些文章被跳过，我们需要保持顺序一致性
    if (analyses.length <= extractedContentObjects.length) {
      // 取前N个内容对象与分析结果匹配
      filteredContentObjects = extractedContentObjects.slice(0, analyses.length);
    } else {
      // 理论上不应该发生，但作为保护措施
      filteredContentObjects = extractedContentObjects;
    }
    
    // 将成功通过相关性检查的文章信息添加到分析结果中
    const enhancedAnalyses = analyses.map((analysis, index) => {
      const contentInfo = filteredContentObjects[index];
      return {
        ...analysis,
        url: contentInfo?.url || analysis.url,
        title: contentInfo?.title || analysis.title,
        aiRelevanceScore: contentInfo?.aiRelevanceScore
      };
    });
    
    console.log('增强后的分析结果:', enhancedAnalyses.map(a => ({ 
      url: a.url, 
      title: a.title.substring(0, 30) + '...',
      score: a.aiRelevanceScore || '无评分'
    })));
    
    // 更新状态：使用相关性过滤后的内容对象和分析结果
    setExtractedContentObjects(filteredContentObjects);
    setArticleAnalyses(enhancedAnalyses);
    
    console.log('=== 最终状态更新 ===');
    console.log('过滤后的内容对象数量:', filteredContentObjects.length);
    console.log('最终分析结果数量:', enhancedAnalyses.length);
    
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // 直接返回分析结果，避免依赖异步状态更新
    return enhancedAnalyses;
  };

  /**
   * 步骤3：综合分析文章特点
   */
  const synthesizeAnalysis = async (extractedContentObjects: ContentObject[], articleAnalyses: ArticleAnalysis[]) => {
    setOutlineGenerationStep(OutlineGenerationSubStep.SYNTHESIZING_ANALYSIS);
    setOutlineGenerationProgress(75);
    
    console.log('开始综合分析成功抓取的文章特点');
    
    // 检查是否有成功抓取的内容对象
    if (!extractedContentObjects || extractedContentObjects.length === 0) {
      throw new Error('没有成功抓取的文章内容，无法进行综合分析');
    }
    
    // 检查是否有分析结果
    if (!articleAnalyses || articleAnalyses.length === 0) {
      throw new Error('没有文章分析结果，无法进行综合分析');
    }
    
    console.log('=== 综合分析数据源检查 ===');
    console.log('extractedContentObjects数量 (已过滤的有效内容):', extractedContentObjects.length);
    console.log('articleAnalyses数量 (分析结果):', articleAnalyses.length);
    console.log('数据来源说明:');
    console.log('- extractedContentObjects: 来自extractContentFromUrls()，已通过validateContentQuality过滤，并通过相关性检查');
    console.log('- articleAnalyses: 来自analyzeExtractedContent()，基于有效内容且与标题相关的分析结果');
    
    console.log('有效文章信息:', extractedContentObjects.map((c, index) => ({ 
      index: index + 1,
      url: c.url, 
      title: c.title.substring(0, 30) + '...',
      contentLength: c.content.length,
      score: c.aiRelevanceScore || '无评分'
    })));
    
    console.log('分析结果信息:', articleAnalyses.map((a, index) => ({
      index: index + 1,
      title: a.title.substring(0, 30) + '...',
      style: a.style,
      tone: a.tone
    })));
    
    // 直接使用传入的内容对象中已经过滤过的原始内容
    const originalTexts = extractedContentObjects.map(contentObj => contentObj.content);
    
    console.log('=== 传递给synthesizeAnalysisAPI的数据 ===');
    console.log('原始文本数量:', originalTexts.length);
    console.log('分析结果数量:', articleAnalyses.length);
    console.log('数据一致性检查:', originalTexts.length === articleAnalyses.length ? '✅ 数量匹配' : '⚠️ 数量不匹配');
    
    if (originalTexts.length !== articleAnalyses.length) {
      console.warn('数据不一致可能的原因:');
      console.warn('1. analyzeArticleOutlines的相关性过滤可能导致某些文章被跳过');
      console.warn('2. 分析过程中某些内容被跳过或失败');
      console.warn('将使用较小的数量以确保数据对应关系');
      
      const minLength = Math.min(originalTexts.length, articleAnalyses.length);
      const adjustedTexts = originalTexts.slice(0, minLength);
      const adjustedAnalyses = articleAnalyses.slice(0, minLength);
      
      console.log(`调整后的数据量: ${minLength}`);
      
      // 调用综合分析函数，使用调整后的数据
      const report = await synthesizeAnalysisAPI(adjustedAnalyses, adjustedTexts);
      console.log('综合分析报告生成完成，长度:', report.length);
      
      setSynthesisReport(report);
      
      // 直接返回综合分析报告
      return report;
    } else {
      console.log('✅ 数据量一致，正常进行综合分析');
      
      // 调用综合分析函数，传递分析结果和原始文章内容用于词汇分析
      const report = await synthesizeAnalysisAPI(articleAnalyses, originalTexts);
      console.log('综合分析报告生成完成，长度:', report.length);
      
      setSynthesisReport(report);
      
      // 模拟延迟
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // 直接返回综合分析报告
      return report;
    }
  };

  /**
   * 步骤4：根据提取的知识和要求生成文章大纲
   */
  const generateFinalOutline = async (selectedTitle: string, synthesisReport: string, articleAnalyses: ArticleAnalysis[], extractedContentObjects: ContentObject[]) => {
    setOutlineGenerationStep(OutlineGenerationSubStep.GENERATING_OUTLINE);
    setOutlineGenerationProgress(100);
    
    console.log('开始生成最终大纲');
    
    // 首先生成AI知识库内容，包含用户提供的知识来源
    console.log('正在从AI知识库生成相关知识点...');
    const selectedIdea = selectedIdeaIndex !== null ? blogIdeas[selectedIdeaIndex]?.title : undefined;
    const aiKnowledgePoints = await generateAIKnowledge(
      keyword,
      targetMarket,
      targetLanguage,
      selectedIdea,
      customIdea,
      knowledgeSource // 将知识来源传递给AI知识库以增强生成内容
    );
    setAiKnowledge(aiKnowledgePoints);
    console.log('AI知识库生成的知识点数量:', aiKnowledgePoints.length);
    
    // 综合所有来源的知识点
    const combinedKnowledge = [
      // 1. 从搜索结果内容中提取的知识点（第二步"发现创意"中生成，已包含附加信息的备用提取）
      ...extractedKnowledge,
      // 2. 从AI知识库生成的知识点（已包含知识来源的内容）
      ...aiKnowledgePoints
    ];
    
    // 去重并限制数量
    const uniqueCombinedKnowledge = Array.from(new Set(combinedKnowledge))
      .filter(item => item && item.trim().length > 2)
      .slice(0, 30); // 限制最多30个知识点
    
    console.log('=== 知识点来源统计 ===');
    console.log('1. 搜索结果知识点数量（已包含附加信息备用）:', extractedKnowledge.length);
    console.log('2. AI知识库知识点数量（已包含知识来源）:', aiKnowledgePoints.length);
    console.log('综合后总知识点数量:', uniqueCombinedKnowledge.length);
    
    // 准备LSI术语（如果自动插入LSI术语被启用）
    const lsiTermsToUse = autoInsertLSI ? extractedLSITerms : [];
    console.log('LSI术语使用情况:', autoInsertLSI ? `启用，共${lsiTermsToUse.length}个术语` : '未启用');
    
    // 构建大纲要求文本（不包含标题附加要求additionalRequirements）
    const combinedRequirements = [
      outlineRequirements, // 只包含大纲专用的要求
      autoInsertLSI && lsiTermsToUse.length > 0 ? `请在文章中自然融入以下LSI术语：${lsiTermsToUse.join('、')}` : ''
    ].filter(req => req && req.trim()).join('\n\n');
    
    console.log('=== 大纲生成综合信息 ===');
    console.log('主关键词:', keyword);
    console.log('选定标题:', selectedTitle);
    console.log('目标字数:', wordCount);
    console.log('可读性级别:', readabilityLevel);
    console.log('语气风格:', toneStyle);
    console.log('写作视角:', perspective);
    console.log('综合分析报告长度:', synthesisReport?.length || 0);
    console.log('文章分析结果数量:', articleAnalyses.length);
    console.log('综合知识点数量:', uniqueCombinedKnowledge.length);
    console.log('LSI术语数量:', lsiTermsToUse.length);
    console.log('大纲要求长度:', combinedRequirements.length);
    
    console.log('=== 各个信息来源检查 ===');
    console.log('1. 附加信息（品牌/产品/场景）长度:', additionalInfo?.length || 0);
    console.log('   内容预览:', additionalInfo ? additionalInfo.substring(0, 50) + '...' : '未填写');
    console.log('2. AI知识库（知识来源）长度:', knowledgeSource?.length || 0);
    console.log('   内容预览:', knowledgeSource ? knowledgeSource.substring(0, 50) + '...' : '未使用AI知识库功能');
    console.log('   是否为空:', knowledgeSource === '' ? '是（用户未使用知识库功能）' : '否');
    console.log('3. 搜索结果知识点数量:', extractedKnowledge.length);
    console.log('4. AI生成知识点数量:', aiKnowledgePoints.length);
    
    if (!knowledgeSource || knowledgeSource.trim() === '') {
      console.log('💡 提示：AI知识库为空是正常的，用户可能没有使用企业知识库功能');
      console.log('💡 系统将使用其他知识来源：搜索结果、AI生成、附加信息等');
    }
    
    console.log('注意：标题附加要求(additionalRequirements)不用于大纲生成');
    
    // 构建参考文章大纲风格数据（补充synthesisReport中可能缺失的具体信息）
    const referenceOutlineStyles = articleAnalyses.map((analysis, index) => ({
      title: analysis.title,
      outline: analysis.outline,
      style: analysis.style,
      tone: analysis.tone,
      structure: analysis.structure,
      keyPoints: analysis.keyPoints,
      url: analysis.url,
      index: index + 1
    }));
    
    console.log('参考大纲风格数据:', referenceOutlineStyles.map(style => ({
      title: style.title.substring(0, 40) + '...',
      outlineLength: style.outline?.length || 0,
      style: style.style,
      tone: style.tone,
      structure: style.structure
    })));
    
    // 调用增强版大纲生成函数，整合所有信息
    console.log('🚀 开始调用generateBlogOutline函数...');
    const outline = await generateBlogOutline(
      keyword,
      selectedTitle,
      synthesisReport || '', // 前两个步骤的综合分析报告（包含大纲风格和词汇分布分析）
      uniqueCombinedKnowledge, // 三个来源综合的知识点
      wordCount,
      readabilityLevel,
      toneStyle,
      perspective,
      combinedRequirements, // 只包含大纲要求和LSI术语要求（不包含标题附加要求）
      lsiTermsToUse, // LSI术语数组
      additionalInfo, // 附加信息（品牌/产品/场景描述）
      knowledgeSource, // 知识来源内容
      referenceOutlineStyles // 参考文章的具体大纲风格数据
    );
    
    console.log('✅ generateBlogOutline函数调用成功');
    console.log('生成的大纲:', outline);
    setGeneratedOutline(outline);
    
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 2000));
  };

  /**
   * 生成文章
   */
  const generateArticle = async () => {
    // 检查是否已生成大纲
    if (!generatedOutline) {
      alert('请先生成大纲');
      return;
    }

    // 跳转到设置页面
    setCurrentStep(AppStep.SETTINGS);
    // 更新访问历史和缓存状态
    setVisitedSteps(prev => {
      if (!prev.includes(AppStep.SETTINGS)) {
        return [...prev, AppStep.SETTINGS];
      }
      return prev;
    });
    setStepDataCache(prev => ({ ...prev, [AppStep.SETTINGS]: true }));
  }

  /**
   * 生成文章草稿
   */
  const generateArticleDraft = async () => {
    if (!generatedOutline) {
      alert('请先生成大纲');
      return;
    }

    // 立即跳转到文章生成进度页面
    setCurrentStep(AppStep.ARTICLE_GENERATING);
    setIsGeneratingArticle(true);
    setArticleGenerationStep(1);
    setArticleGenerationMessage('正在初始化文章生成流程...');

    try {
      const { generateArticleWithEvidence } = await import('@/lib/article-generation');
      
      console.log('开始生成文章草稿...', {
        keyword,
        selectedTitle: selectedTitleIndex !== null ? generatedTitles[selectedTitleIndex].title : customTitle,
        outline: generatedOutline,
        settings: {
          articleRequirements,
          addFactsAndEvidence,
          searchRegion,
          contentLanguage,
          autoInsertInternalLinks,
          anchorTextAutomation,
          autoInsertExternalLinks,
          externalDomainWhitelist,
          addBlogCoverImage,
          addImagesUnderH2,
          addKeyPoints,
          addFAQSection,
          addMoreRecommendations,
          customLinks
        }
      });

      // 只有在启用了事实和证据功能时才执行证据收集流程
      if (addFactsAndEvidence) {
        const result = await generateArticleWithEvidence(
          generatedOutline,
          keyword,
          contentLanguage,
          searchRegion,
          (step: number, message: string) => {
            setArticleGenerationStep(step);
            setArticleGenerationMessage(message);
          }
        );

        console.log('证据收集完成:', {
          requirements: result.requirements.length,
          searchResults: result.searchResults.length,
          extractedContents: result.extractedContents.length,
          evidence: result.evidence.length
        });

        // 使用Promise来确保状态更新完成
        await new Promise<void>((resolve) => {
          setGeneratedEvidence(result.evidence);
          setEvidenceRequirements(result.requirements);
          setArticleGenerationMessage(`证据收集完成！找到${result.evidence.length}条高质量证据`);
          
          // 使用requestAnimationFrame确保状态已更新
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              console.log('状态更新完成，当前证据数量:', result.evidence.length);
              resolve();
            });
          });
        });

        // 等待状态更新完成后再继续
        setTimeout(() => {
          setCurrentStep(AppStep.ARTICLE_DRAFT);
          setIsGeneratingArticle(false);
          
          // 直接传递evidence数据而不是依赖状态
          startContentGeneration(result.evidence);
        }, 1000);
      } else {
        setArticleGenerationMessage('跳过证据收集，直接生成文章...');
        // 直接进入文章生成
        setCurrentStep(AppStep.ARTICLE_DRAFT);
        setIsGeneratingArticle(false);
        startContentGeneration([]);
      }
    } catch (error) {
      console.error('文章生成失败:', error);
      setArticleGenerationMessage(`文章生成失败: ${error instanceof Error ? error.message : '未知错误'}`);
      
      // 错误情况下回到设置页面
      setTimeout(() => {
        setIsGeneratingArticle(false);
        setCurrentStep(AppStep.SETTINGS);
      }, 3000);
    }
  }

  /**
   * 直接生成文章 - 跳过步骤3,4,5
   */
  const generateArticleDirectly = async () => {
    // 检查必要的信息
    if (!keyword.trim()) {
      alert('请输入关键词');
      return;
    }

    // 检查是否有选中的创意或自定义创意
    const selectedIdea = selectedIdeaIndex !== null ? blogIdeas[selectedIdeaIndex] : null;
    const customIdeaText = customIdea.trim();
    
    if (!selectedIdea && !customIdeaText) {
      alert('请先选择一个博客创意或输入自定义创意');
      return;
    }

    // 显示全局加载状态
    setIsLoading(true);
    setCurrentStep(AppStep.ARTICLE_GENERATING);
    setIsGeneratingArticle(true);
    setArticleGenerationStep(1);
    setArticleGenerationMessage('正在直接生成文章，跳过中间步骤...');

    try {
      // 1. 生成标题（如果还没有）
      let currentTitle = '';
      if (selectedTitleIndex !== null && generatedTitles[selectedTitleIndex]) {
        currentTitle = generatedTitles[selectedTitleIndex].title;
        setArticleGenerationStep(2);
        setArticleGenerationMessage('标题已存在，跳过标题生成...');
      } else if (customTitle.trim()) {
        currentTitle = customTitle.trim();
        setArticleGenerationStep(2);
        setArticleGenerationMessage('使用自定义标题，跳过标题生成...');
      } else {
        // 需要生成标题
        setArticleGenerationStep(1);
        setArticleGenerationMessage('正在生成标题...');
        await generateTitle();
        currentTitle = selectedTitleIndex !== null ? generatedTitles[selectedTitleIndex].title : customTitle;
        setArticleGenerationStep(2);
      }

      // 2. 生成大纲（如果还没有）
      if (!generatedOutline) {
        setArticleGenerationMessage('正在生成大纲...');
        await generateOutline();
        setArticleGenerationStep(3);
      } else {
        setArticleGenerationStep(3);
        setArticleGenerationMessage('大纲已存在，跳过大纲生成...');
      }

      // 3. 直接进入文章生成
      setArticleGenerationMessage('正在生成文章内容...');
      setArticleGenerationStep(4);
      
      // 跳过证据收集，直接生成文章
      setTimeout(() => {
        setCurrentStep(AppStep.ARTICLE_DRAFT);
        setIsGeneratingArticle(false);
        setIsLoading(false);
        startContentGeneration([]);
      }, 1000);

    } catch (error) {
      console.error('直接生成文章失败:', error);
      setArticleGenerationMessage(`生成失败: ${error instanceof Error ? error.message : '未知错误'}`);
      
      // 错误情况下回到输入页面
      setTimeout(() => {
        setIsLoading(false);
        setIsGeneratingArticle(false);
        setCurrentStep(AppStep.INPUT);
      }, 3000);
    }
  }

  /**
   * 开始内容生成流程
   */
  const startContentGeneration = async (evidence: Evidence[] = []) => {
    setIsGeneratingContent(true);
    setArticleDraftStep(ArticleDraftStep.GENERATE_CONTENT);
    setArticleDraftMessage('正在根据知识总结及生成要求逐段生成内容...');
    
    try {
      // 获取当前选择的标题
      const currentTitle = selectedTitleIndex !== null ? generatedTitles[selectedTitleIndex].title : customTitle;
      
      // 打印当前状态
      console.log('开始内容生成，当前状态:', {
        title: currentTitle,
        keyword,
        outline: generatedOutline,
        evidenceCount: evidence.length,
        evidence: evidence,
        targetLanguage: contentLanguage,
        targetMarket: searchRegion,
        requirements: articleRequirements
      });
      
      // 准备生成参数
      const generateParams: ContentGenerationParams = {
        title: currentTitle,
        keyword: keyword,
        outline: generatedOutline!,
        evidence: evidence, // 使用传入的evidence而不是状态
        targetLanguage: contentLanguage,
        targetMarket: searchRegion,
        requirements: articleRequirements
      };
      
      // 调用内容生成API
      const finalContent = await startContentGenerationAPI(
        generateParams,
        (step: ArticleDraftStep, message: string) => {
          setArticleDraftStep(step);
          setArticleDraftMessage(message);
        }
      );
      
      // 设置生成的内容
      setGeneratedContent(finalContent);
      setIsGeneratingContent(false);
      
      // 完成后更新访问历史
      setVisitedSteps(prev => {
        if (!prev.includes(AppStep.ARTICLE_DRAFT)) {
          return [...prev, AppStep.ARTICLE_DRAFT];
        }
        return prev;
      });
      setStepDataCache(prev => ({ ...prev, [AppStep.ARTICLE_DRAFT]: true }));
      
    } catch (error) {
      console.error('内容生成失败:', error);
      setIsGeneratingContent(false);
      setArticleDraftMessage(`生成失败: ${error instanceof Error ? error.message : '未知错误'}`);
      
      // 使用新的错误处理器显示友好的错误提示
      handleApiError(
        error,
        () => startContentGeneration(evidence), // 重试函数
        '文章生成失败'
      );
    }
  }

  // 2. 持久化关键状态
  useEffect(() => {
    const stateToPersist = {
      currentStep,
      keyword,
      targetMarket,
      targetLanguage,
      pageCount,
      timeRange,
      blogIdeas,
      selectedIdeaIndex,
      customIdea,
      generatedTitles,
      selectedTitleIndex,
      customTitle,
      generatedOutline,
      filteredBlogContent,
      knowledgeSource
    }
    persistState(stateToPersist, sessionId)
  }, [currentStep, keyword, targetMarket, targetLanguage, pageCount, timeRange, blogIdeas, selectedIdeaIndex, customIdea, generatedTitles, selectedTitleIndex, customTitle, generatedOutline, filteredBlogContent, knowledgeSource, sessionId])

  return {
    // 状态
    currentStep,
    keyword,
    targetMarket,
    targetLanguage,
    pageCount,
    timeRange,
    searchResults,
    blogIdeas,
    searchIntent,
    progress,
    isLoading,
    customIdea,
    selectedIdeaIndex,
    additionalInfo,
    additionalRequirements,
    autoInsertLSI,
    knowledgeSource,
    titleGenerationStep,
    titleGenerationProgress,
    relatedSearchResults,
    filteredBlogContent,
    latestFilteredResults,
    extractedKnowledge,
    extractedLSITerms,
    generatedTitles,
    selectedTitleIndex,
    customTitle,
    wordCount,
    readabilityLevel,
    toneStyle,
    perspective,
    outlineRequirements,
    outlineGenerationStep,
    outlineGenerationProgress,
    outlineGenerationError,
    extractedContents,
    extractedContentObjects,
    articleAnalyses,
    synthesisReport,
    generatedOutline,
    aiKnowledge,
    visitedSteps,
    stepDataCache,
    
    // 设置页面状态
    articleRequirements,
    addFactsAndEvidence,
    searchRegion,
    contentLanguage,
    autoInsertInternalLinks,
    anchorTextAutomation,
    autoInsertExternalLinks,
    externalDomainWhitelist,
    addBlogCoverImage,
    addImagesUnderH2,
    addKeyPoints,
    addFAQSection,
    addMoreRecommendations,
    customLinks,
    customAnchorLinks,
    
    // 状态设置函数
    setKeyword,
    setTargetMarket,
    setTargetLanguage,
    setPageCount,
    setTimeRange,
    setCustomIdea,
    setAdditionalInfo,
    setAdditionalRequirements,
    setAutoInsertLSI,
    setKnowledgeSource,
    setSelectedTitleIndex,
    setCustomTitle,
    setWordCount,
    setReadabilityLevel,
    setToneStyle,
    setPerspective,
    setOutlineRequirements,
    
    // 设置页面状态设置函数
    setArticleRequirements,
    setAddFactsAndEvidence,
    setSearchRegion,
    setContentLanguage,
    setAutoInsertInternalLinks,
    setAnchorTextAutomation,
    setAutoInsertExternalLinks,
    setExternalDomainWhitelist,
    setAddBlogCoverImage,
    setAddImagesUnderH2,
    setAddKeyPoints,
    setAddFAQSection,
    setAddMoreRecommendations,
    setCustomLinks,
    setCustomAnchorLinks,
    
    // 文章生成状态
    isGeneratingArticle,
    articleGenerationStep,
    articleGenerationMessage,
    generatedEvidence,
    
    // 文章草稿页面状态
    evidenceRequirements,
    articleDraftStep,
    articleDraftMessage,
    generatedContent,
    isGeneratingContent,
    
    // 操作函数
    handleSearch,
    handleBack,
    handleNext,
    canGoNext,
    handleIdeaSelect,
    generateTitle,
    generateOutline,
    generateArticle,
    generateArticleDraft,
    generateArticleDirectly
  }
} 
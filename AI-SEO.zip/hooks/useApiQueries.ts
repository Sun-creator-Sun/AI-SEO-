"use client"

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { 
  searchKeyword, 
  generateBlogIdeas, 
  analyzeSearchIntent, 
  searchRelatedContent,
  filterBlogContent as filterBlogContentAPI,
  extractKnowledgePoints as extractKnowledgePointsAPI,
  extractLSITerms,
  generateBlogTitles as generateBlogTitlesAPI,
  extractArticleContent,
  analyzeArticleOutlines,
  generateBlogOutline,
  type SearchResult, 
  type BlogIdea, 
  type SearchIntent,
  type BlogTitle,
  type BlogOutline,
  type ArticleAnalysis
} from '@/lib/google-search'
import { synthesizeAnalysis as synthesizeAnalysisAPI } from '@/lib/outline-generation'
import { generateAIKnowledge } from '@/lib/ai-knowledge'

// 查询键常量
export const queryKeys = {
  search: (keyword: string, market: string, language: string, timeRange: string) => 
    ['search', keyword, market, language, timeRange],
  searchIntent: (keyword: string, market: string, language: string) => 
    ['searchIntent', keyword, market, language],
  blogIdeas: (keyword: string, market: string, language: string, timeRange: string, pageCount: number) => 
    ['blogIdeas', keyword, market, language, timeRange, pageCount],
  relatedContent: (keyword: string, ideaText: string, market: string, language: string, timeRange: string) => 
    ['relatedContent', keyword, ideaText, market, language, timeRange],
  filteredContent: (results: SearchResult[]) => 
    ['filteredContent', results.map(r => r.url).join(',')],
  knowledgePoints: (results: SearchResult[]) => 
    ['knowledgePoints', results.map(r => r.url).join(',')],
  lsiTerms: (results: SearchResult[]) => 
    ['lsiTerms', results.map(r => r.url).join(',')],
  blogTitles: (keyword: string, ideaText: string, knowledgePoints: string[], additionalRequirements: string, referenceTitles: string[], lsiTerms: string[]) => 
    ['blogTitles', keyword, ideaText, knowledgePoints.join(','), additionalRequirements, referenceTitles.join(','), lsiTerms.join(',')],
  articleContent: (urls: string[]) => 
    ['articleContent', urls.join(',')],
  articleAnalysis: (contents: string[], selectedTitle: string) => 
    ['articleAnalysis', contents.map(c => c.substring(0, 100)).join(','), selectedTitle],
  synthesisReport: (contents: any[], analyses: ArticleAnalysis[]) => 
    ['synthesisReport', contents.length, analyses.length],
  blogOutline: (keyword: string, title: string, synthesisReport: string, knowledge: string[], wordCount: string, readabilityLevel: string, toneStyle: string, perspective: string, requirements: string, lsiTerms: string[], additionalInfo: string, knowledgeSource: string) => 
    ['blogOutline', keyword, title, synthesisReport.substring(0, 100), knowledge.join(','), wordCount, readabilityLevel, toneStyle, perspective, requirements, lsiTerms.join(','), additionalInfo, knowledgeSource.substring(0, 100)],
  aiKnowledge: (keyword: string, searchResults: SearchResult[]) => 
    ['aiKnowledge', keyword, searchResults.map(r => r.url).join(',')],
}

/**
 * 搜索关键词
 */
export function useSearchKeyword(
  keyword: string,
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.search(keyword, targetMarket, targetLanguage, timeRange),
    queryFn: () => searchKeyword(keyword, targetMarket, targetLanguage, timeRange),
    enabled: enabled && !!keyword.trim(),
    staleTime: 5 * 60 * 1000, // 5分钟
    gcTime: 10 * 60 * 1000, // 10分钟
  })
}

/**
 * 分析搜索意图
 */
export function useAnalyzeSearchIntent(
  keyword: string,
  targetMarket: string,
  targetLanguage: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.searchIntent(keyword, targetMarket, targetLanguage),
    queryFn: () => analyzeSearchIntent(keyword, targetMarket, targetLanguage),
    enabled: enabled && !!keyword.trim(),
    staleTime: 10 * 60 * 1000, // 10分钟
    gcTime: 20 * 60 * 1000, // 20分钟
  })
}

/**
 * 生成博客创意
 */
export function useGenerateBlogIdeas(
  keyword: string,
  searchResults: SearchResult[],
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  pageCount: number,
  searchIntent: SearchIntent | null,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.blogIdeas(keyword, targetMarket, targetLanguage, timeRange, pageCount),
    queryFn: () => generateBlogIdeas(keyword, searchResults, pageCount, timeRange, searchIntent || undefined),
    enabled: enabled && !!keyword.trim() && searchResults.length > 0,
    staleTime: 15 * 60 * 1000, // 15分钟
    gcTime: 30 * 60 * 1000, // 30分钟
  })
}

/**
 * 搜索相关内容
 */
export function useSearchRelatedContent(
  keyword: string,
  ideaText: string,
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.relatedContent(keyword, ideaText, targetMarket, targetLanguage, timeRange),
    queryFn: () => searchRelatedContent(keyword, ideaText, targetMarket, targetLanguage, timeRange),
    enabled: enabled && !!keyword.trim() && !!ideaText.trim(),
    staleTime: 5 * 60 * 1000, // 5分钟
    gcTime: 10 * 60 * 1000, // 10分钟
  })
}

/**
 * 过滤博客内容
 */
export function useFilterBlogContent(
  searchResults: SearchResult[],
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.filteredContent(searchResults),
    queryFn: () => filterBlogContentAPI(searchResults),
    enabled: enabled && searchResults.length > 0,
    staleTime: 5 * 60 * 1000, // 5分钟
    gcTime: 10 * 60 * 1000, // 10分钟
  })
}

/**
 * 提取知识点
 */
export function useExtractKnowledgePoints(
  content: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.knowledgePoints([]),
    queryFn: () => extractKnowledgePointsAPI(content),
    enabled: enabled && !!content.trim(),
    staleTime: 10 * 60 * 1000, // 10分钟
    gcTime: 20 * 60 * 1000, // 20分钟
  })
}

/**
 * 提取LSI术语
 */
export function useExtractLSITerms(
  searchResults: SearchResult[],
  keyword: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.lsiTerms(searchResults),
    queryFn: () => extractLSITerms(searchResults, keyword),
    enabled: enabled && searchResults.length > 0 && !!keyword.trim(),
    staleTime: 10 * 60 * 1000, // 10分钟
    gcTime: 20 * 60 * 1000, // 20分钟
  })
}

/**
 * 生成博客标题
 */
export function useGenerateBlogTitles(
  keyword: string,
  ideaText: string,
  knowledgePoints: string[],
  additionalRequirements: string,
  referenceTitles: string[],
  lsiTerms: string[],
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.blogTitles(keyword, ideaText, knowledgePoints, additionalRequirements, referenceTitles, lsiTerms),
    queryFn: () => generateBlogTitlesAPI(keyword, ideaText, knowledgePoints, additionalRequirements, referenceTitles, lsiTerms),
    enabled: enabled && !!keyword.trim() && !!ideaText.trim(),
    staleTime: 15 * 60 * 1000, // 15分钟
    gcTime: 30 * 60 * 1000, // 30分钟
  })
}

/**
 * 提取文章内容
 */
export function useExtractArticleContent(
  urls: string[],
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.articleContent(urls),
    queryFn: () => extractArticleContent(urls),
    enabled: enabled && urls.length > 0,
    staleTime: 30 * 60 * 1000, // 30分钟
    gcTime: 60 * 60 * 1000, // 1小时
  })
}

/**
 * 分析文章大纲
 */
export function useAnalyzeArticleOutlines(
  contents: string[],
  selectedTitle: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.articleAnalysis(contents, selectedTitle),
    queryFn: () => analyzeArticleOutlines(contents, selectedTitle),
    enabled: enabled && contents.length > 0 && !!selectedTitle.trim(),
    staleTime: 20 * 60 * 1000, // 20分钟
    gcTime: 40 * 60 * 1000, // 40分钟
  })
}

/**
 * 综合分析报告
 */
export function useSynthesizeAnalysis(
  analyses: ArticleAnalysis[],
  contents: string[] = [],
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.synthesisReport(contents, analyses),
    queryFn: () => synthesizeAnalysisAPI(analyses, contents),
    enabled: enabled && analyses.length > 0,
    staleTime: 15 * 60 * 1000, // 15分钟
    gcTime: 30 * 60 * 1000, // 30分钟
  })
}

/**
 * 生成博客大纲
 */
export function useGenerateBlogOutline(
  keyword: string,
  title: string,
  synthesisReport: string,
  knowledge: string[],
  wordCount: string,
  readabilityLevel: string,
  toneStyle: string,
  perspective: string,
  requirements: string,
  lsiTerms: string[],
  additionalInfo: string,
  knowledgeSource: string,
  referenceOutlineStyles: any[],
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.blogOutline(keyword, title, synthesisReport, knowledge, wordCount, readabilityLevel, toneStyle, perspective, requirements, lsiTerms, additionalInfo, knowledgeSource),
    queryFn: () => generateBlogOutline(
      keyword, title, synthesisReport, knowledge, wordCount, 
      readabilityLevel, toneStyle, perspective, requirements, 
      lsiTerms, additionalInfo, knowledgeSource, referenceOutlineStyles
    ),
    enabled: enabled && !!keyword.trim() && !!title.trim(),
    staleTime: 20 * 60 * 1000, // 20分钟
    gcTime: 40 * 60 * 1000, // 40分钟
  })
}

/**
 * 生成AI知识库
 */
export function useGenerateAIKnowledge(
  keyword: string,
  targetMarket: string = '美国',
  targetLanguage: string = '英语',
  selectedIdea?: string,
  customIdea?: string,
  knowledgeSource?: string,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: queryKeys.aiKnowledge(keyword, []),
    queryFn: () => generateAIKnowledge(keyword, targetMarket, targetLanguage, selectedIdea, customIdea, knowledgeSource),
    enabled: enabled && !!keyword.trim(),
    staleTime: 30 * 60 * 1000, // 30分钟
    gcTime: 60 * 60 * 1000, // 1小时
  })
}

/**
 * 清除相关缓存
 */
export function useClearCache() {
  const queryClient = useQueryClient()
  
  return {
    clearSearchCache: (keyword: string, market: string, language: string, timeRange: string) => {
      queryClient.removeQueries({ queryKey: queryKeys.search(keyword, market, language, timeRange) })
    },
    clearBlogIdeasCache: (keyword: string, market: string, language: string, timeRange: string, pageCount: number) => {
      queryClient.removeQueries({ queryKey: queryKeys.blogIdeas(keyword, market, language, timeRange, pageCount) })
    },
    clearAllCache: () => {
      queryClient.clear()
    },
    invalidateSearchQueries: () => {
      queryClient.invalidateQueries({ queryKey: ['search'] })
    },
    invalidateBlogQueries: () => {
      queryClient.invalidateQueries({ queryKey: ['blogIdeas'] })
    },
    invalidateTitleQueries: () => {
      queryClient.invalidateQueries({ queryKey: ['blogTitles'] })
    },
    invalidateOutlineQueries: () => {
      queryClient.invalidateQueries({ queryKey: ['blogOutline'] })
    },
  }
} 
"use client"

import { useEffect, useRef } from 'react'

interface PerformanceMetrics {
  componentLoadTime: number
  renderTime: number
  memoryUsage?: number
}

/**
 * 性能监控Hook
 * @param componentName 组件名称
 * @returns 性能指标
 */
export function usePerformance(componentName: string) {
  const startTime = useRef<number>(Date.now())
  const renderStartTime = useRef<number>(0)
  const metrics = useRef<PerformanceMetrics>({
    componentLoadTime: 0,
    renderTime: 0
  })

  useEffect(() => {
    // 记录组件加载时间
    const loadTime = Date.now() - startTime.current
    metrics.current.componentLoadTime = loadTime

    // 在开发环境下输出性能信息
    if (process.env.NODE_ENV === 'development') {
      console.log(`🚀 ${componentName} 加载时间: ${loadTime}ms`)
    }

    // 监控内存使用（仅在支持的环境中）
    if (typeof performance !== 'undefined' && 'memory' in performance) {
      const memory = (performance as any).memory
      metrics.current.memoryUsage = memory.usedJSHeapSize / 1024 / 1024 // MB
      
      if (process.env.NODE_ENV === 'development') {
        console.log(`💾 ${componentName} 内存使用: ${metrics.current.memoryUsage.toFixed(2)}MB`)
      }
    }
  }, [componentName])

  // 记录渲染开始时间
  const startRender = () => {
    renderStartTime.current = performance.now()
  }

  // 记录渲染结束时间
  const endRender = () => {
    const renderTime = performance.now() - renderStartTime.current
    metrics.current.renderTime = renderTime

    if (process.env.NODE_ENV === 'development') {
      console.log(`⚡ ${componentName} 渲染时间: ${renderTime.toFixed(2)}ms`)
    }
  }

  return {
    metrics: metrics.current,
    startRender,
    endRender
  }
}

/**
 * 懒加载性能监控Hook
 * @param componentName 组件名称
 * @returns 懒加载性能指标
 */
export function useLazyLoadPerformance(componentName: string) {
  const { metrics, startRender, endRender } = usePerformance(componentName)

  useEffect(() => {
    startRender()
    
    // 使用requestAnimationFrame确保在下一帧渲染后记录时间
    const rafId = requestAnimationFrame(() => {
      endRender()
    })

    return () => {
      cancelAnimationFrame(rafId)
    }
  }, [componentName])

  return metrics
} 
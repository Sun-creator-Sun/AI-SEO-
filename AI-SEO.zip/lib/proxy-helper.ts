import https from 'https';
import { URL } from 'url';
import { HttpsProxyAgent } from 'https-proxy-agent';

/**
 * 代理配置接口
 */
export interface ProxyConfig {
  proxy?: string;
  detected: boolean;
  source: 'env' | 'auto-detect' | 'none';
}

/**
 * API响应接口
 */
export interface ApiResponse {
  ok: boolean;
  status?: number;
  statusText?: string;
  data: any;
}

/**
 * 获取代理配置（仅检查环境变量）
 * @returns 代理配置对象
 */
export function getProxyConfig(): ProxyConfig {
  // 优先检查环境变量（标准做法）
  const httpProxy = process.env.HTTP_PROXY || process.env.http_proxy;
  const httpsProxy = process.env.HTTPS_PROXY || process.env.https_proxy;
  
  const envProxy = httpsProxy || httpProxy;
  
  if (envProxy) {
    return {
      proxy: envProxy,
      detected: true,
      source: 'env'
    };
  }
  
  // 如果没有环境变量，返回无代理配置
  return {
    proxy: undefined,
    detected: false,
    source: 'none'
  };
}

/**
 * 获取常见代理列表
 * @returns 常见代理地址数组
 */
export function getCommonProxies(): string[] {
  return [
    'http://127.0.0.1:7890',  // Clash
    'http://127.0.0.1:1087',  // Surge  
    'http://127.0.0.1:8080',  // 通用代理
  ];
}

/**
 * 尝试使用多个代理进行API调用
 * @param apiUrl API地址
 * @param requestBody 请求体
 * @param method HTTP方法
 * @returns Promise<ApiResponse & { proxy?: string }>
 */
export async function tryMultipleProxies(
  apiUrl: string,
  requestBody: any,
  method: 'GET' | 'POST' = 'POST'
): Promise<ApiResponse & { proxy?: string }> {
  
  const proxies = getCommonProxies();
  console.log('🔧 尝试多个代理:', proxies);
  
  for (const proxy of proxies) {
    console.log(`🔄 尝试代理: ${proxy}`);
    
    try {
      const response = await callApiWithHttps(apiUrl, requestBody, proxy, method);
      
      if (response.ok) {
        console.log(`✅ 代理 ${proxy} 调用成功`);
        return { ...response, proxy };
      } else {
        console.log(`⚠️ 代理 ${proxy} 返回错误状态: ${response.status}`);
      }
    } catch (error) {
      console.log(`⚠️ 代理 ${proxy} 调用异常:`, error instanceof Error ? error.message : String(error));
    }
  }
  
  throw new Error('所有代理都失败了');
}

/**
 * 使用Node.js原生https模块调用API（支持代理）
 * @param apiUrl API地址
 * @param requestBody 请求体（GET请求时为null）
 * @param proxyUrl 代理地址
 * @param method HTTP方法
 * @returns Promise<ApiResponse>
 */
export function callApiWithHttps(apiUrl: string, requestBody: any, proxyUrl?: string, method: 'GET' | 'POST' = 'POST'): Promise<ApiResponse> {
  return new Promise((resolve, reject) => {
    const url = new URL(apiUrl);
    const postData = method === 'POST' ? JSON.stringify(requestBody) : '';
    
    const options: any = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: method,
      headers: {
        'User-Agent': 'vertu-seo/1.0',
        'Accept': 'application/json',
      },
      timeout: 30000, // 30秒超时（减少等待时间）
    };

    // 只有POST请求才需要Content-Type和Content-Length
    if (method === 'POST') {
      options.headers['Content-Type'] = 'application/json';
      options.headers['Content-Length'] = Buffer.byteLength(postData);
    }

    // 如果有代理，使用代理Agent
    if (proxyUrl) {
      options.agent = new HttpsProxyAgent(proxyUrl);
    }

    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const jsonData = JSON.parse(data);
          resolve({
            ok: (res.statusCode || 0) >= 200 && (res.statusCode || 0) < 300,
            status: res.statusCode || 0,
            statusText: res.statusMessage || '',
            data: jsonData,
          });
        } catch (parseError) {
          resolve({
            ok: false,
            status: res.statusCode || 0,
            statusText: res.statusMessage || '',
            data: { error: '响应解析失败', rawData: data },
          });
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('请求超时'));
    });

    // 只有POST请求才写入请求体
    if (method === 'POST') {
      req.write(postData);
    }
    req.end();
  });
}

/**
 * 简化的API调用（先尝试直连，失败后使用代理）
 * @param apiUrl API地址
 * @param requestBody 请求体（GET请求时为null）
 * @param serviceName 服务名称（用于日志）
 * @param method HTTP方法
 * @returns Promise<ApiResponse & { proxy?: string }>
 */
export async function callApiWithProxyRetry(
  apiUrl: string, 
  requestBody: any, 
  serviceName: string = 'API',
  method: 'GET' | 'POST' = 'POST'
): Promise<ApiResponse & { proxy?: string }> {
  
  console.log(`🚀 开始调用${serviceName}...`);
  console.log('📡 API URL:', apiUrl.replace(/key=[^&]*/, 'key=API_KEY_HIDDEN'));
  
  // 第一步：尝试直连（不使用代理）
  console.log('🌐 首先尝试直连...');
  
  try {
    const directResponse = await callApiWithHttps(apiUrl, requestBody, undefined, method);
    
    if (directResponse.ok) {
      console.log(`✅ ${serviceName}直连成功`);
      return { ...directResponse, proxy: undefined };
    } else {
      console.log(`⚠️ 直连返回错误状态: ${directResponse.status} ${directResponse.statusText}`);
      // 继续尝试代理
    }
  } catch (directError) {
    console.log(`⚠️ 直连失败:`, directError instanceof Error ? directError.message : String(directError));
    // 继续尝试代理
  }
  
  // 第二步：获取代理配置并尝试代理连接
  const proxyConfig = getProxyConfig();
  
  if (proxyConfig.detected) {
    console.log(`🔧 直连失败，尝试使用环境变量代理 (${proxyConfig.source}):`, proxyConfig.proxy);
    
    try {
      const proxyResponse = await callApiWithHttps(apiUrl, requestBody, proxyConfig.proxy, method);
      
      if (proxyResponse.ok) {
        console.log(`✅ ${serviceName}环境变量代理调用成功:`, proxyConfig.proxy);
        return { ...proxyResponse, proxy: proxyConfig.proxy };
      } else {
        console.log(`⚠️ 环境变量代理返回错误状态:`, proxyResponse.status, proxyResponse.statusText);
      }
    } catch (proxyError) {
      console.log(`⚠️ 环境变量代理调用异常:`, proxyError);
    }
  }
  
  // 第三步：尝试常见代理
  console.log('🔧 尝试常见代理配置...');
    
    try {
    const multiProxyResponse = await tryMultipleProxies(apiUrl, requestBody, method);
    console.log(`✅ ${serviceName}使用常见代理调用成功:`, multiProxyResponse.proxy);
    return multiProxyResponse;
  } catch (multiProxyError) {
    console.error(`❌ 所有代理尝试都失败了:`, multiProxyError);
  }
      
  // 所有方法都失败了
  console.error('❌ 直连和所有代理都失败了');
  
  const errorMessage = `${serviceName}调用失败: 直连和所有代理都失败`;
  const finalError = new Error(`${errorMessage}\n\n建议:\n1. 检查网络连接\n2. 设置代理环境变量: export HTTPS_PROXY="http://127.0.0.1:10808"\n3. 确认VPN或代理软件正在运行`);
  (finalError as any).diagnosticInfo = {
        apiUrl: apiUrl.split('?')[0],
        suggestions: [
      '检查网络连接是否正常',
          '设置环境变量: export HTTPS_PROXY="http://127.0.0.1:10808"',
          '或设置: export HTTP_PROXY="http://127.0.0.1:10808"',
      '确认Clash、Surge等代理软件是否正在运行',
          '检查VPN是否正常工作',
          '确认API密钥是否有效'
        ]
      };
      
  throw finalError;
}

/**
 * 创建网络诊断错误响应
 * @param error 错误对象
 * @param serviceName 服务名称
 * @returns 诊断错误对象
 */
export function createNetworkDiagnosticError(error: any, serviceName: string) {
  return {
    error: error.message || `${serviceName}调用失败`,
    errorType: error?.constructor?.name || 'NetworkError',
    suggestions: error.diagnosticInfo?.suggestions || [
      '设置代理环境变量: export HTTPS_PROXY="http://127.0.0.1:10808"',
      '检查网络连接是否正常',
      '确认VPN代理是否配置正确'
    ],
    diagnosticInfo: error.diagnosticInfo || {
      timeout: '30秒',
      proxyDetected: false
    }
  };
} 
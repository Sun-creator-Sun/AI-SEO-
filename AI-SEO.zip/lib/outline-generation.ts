import { BlogOutline, ArticleAnalysis } from './types';
import { createGenAI, AI_MODEL, getYearPolicyPrompt } from './config';
import { recordAPIResult } from './api-key-manager';
import {
  generateFallbackAnalysis,
  generateFallbackSynthesis,
  generateDefaultSections,
  generateFallbackOutline,
  fallbackAnalyzeArticleOutlines
} from './outline-generation-fallback';

/**
 * 从URL数组中抓取文章内容
 * @param urls - URL数组
 * @returns 抓取的文章内容数组
 */
export async function extractArticleContent(urls: string[]): Promise<string[]> {
  try {
    console.log('开始抓取文章内容，URL数量:', urls.length);
    
    // 限制抓取数量，避免过多请求
    const maxUrls = Math.min(urls.length, 8);
    const urlsToProcess = urls.slice(0, maxUrls);
    
    // 获取基础URL，兼容客户端和服务器端
    const baseUrl = typeof window !== 'undefined' 
      ? window.location.origin 
      : process.env.NEXTAUTH_URL || 'http://localhost:3000';
    
    // 调用API路由进行网页抓取
    const response = await fetch(`${baseUrl}/api/scrape`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        urls: urlsToProcess,
        maxConcurrency: 3
      })
    });
    
    if (!response.ok) {
      throw new Error(`API请求失败: ${response.status} ${response.statusText}`);
    }
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(`抓取失败: ${result.error || '未知错误'}`);
    }
    
    // 提取成功抓取的内容
    const contents: string[] = [];
    result.results.forEach((item: any) => {
      if (item.content) {
        contents.push(item.content);
      } else if (item.error) {
        console.warn(`抓取URL失败: ${item.url} - ${item.error}`);
        // 为失败的URL添加错误占位内容
        contents.push(`无法抓取内容: ${item.url} - ${item.error}`);
      }
    });
    
    console.log(`成功抓取${contents.length}个文章内容`);
    console.log(`抓取摘要: 成功${result.summary.successful}个，失败${result.summary.failed}个`);
    
    return contents;
    
  } catch (error) {
    console.error('批量抓取文章内容失败:', error);
    // 如果抓取失败，返回错误信息而不是使用fallback
    throw new Error(`抓取文章内容失败: ${error instanceof Error ? error.message : '未知错误'}`);
  }
}

/**
 * 分析抓取的文章内容，提取大纲和风格
 * @param extractedContents - 抓取的文章内容数组
 * @param selectedTitle - 选定的博客标题，用于相关性过滤
 * @returns 文章分析结果数组
 */
export async function analyzeArticleOutlines(extractedContents: string[], selectedTitle?: string): Promise<ArticleAnalysis[]> {
  try {
    console.log('开始分析文章大纲和风格，文章数量:', extractedContents.length);
    console.log('选定的标题:', selectedTitle || '未提供标题');
    
    const analyses: ArticleAnalysis[] = [];
    let filteredCount = 0; // 记录被过滤掉的文章数量
    
    // 逐个分析每篇文章，避免内容过长和截断问题
    for (let i = 0; i < extractedContents.length; i++) {
      const content = extractedContents[i];
      console.log(`正在分析第${i + 1}篇文章，内容长度: ${content.length}字符`);
      
      try {
        const analysis = await analyzeSingleArticle(content, i + 1, selectedTitle);
        
        // 如果分析结果为null，说明文章与标题不相关，跳过
        if (analysis === null) {
          filteredCount++;
          console.log(`❌ 第${i + 1}篇文章与选定标题不相关，已过滤`);
          continue;
        }
        
        analyses.push(analysis);
        console.log(`✅ 第${i + 1}篇文章分析完成并通过相关性检查`);
        
        // 避免API调用过于频繁
        if (i < extractedContents.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      } catch (error) {
        console.warn(`第${i + 1}篇文章分析失败:`, error);
        // 添加备用分析结果
        analyses.push(generateFallbackAnalysis(content, i));
      }
    }
    
    console.log(`=== 文章分析结果统计 ===`);
    console.log(`原始文章数量: ${extractedContents.length}`);
    console.log(`过滤掉的文章数量: ${filteredCount}`);
    console.log(`最终有效分析结果数量: ${analyses.length}`);
    
    // 如果所有文章都被过滤掉，尝试不进行相关性检查重新分析
    if (analyses.length === 0 && selectedTitle) {
      console.log('⚠️ 所有文章都被判定为不相关，尝试放宽相关性要求重新分析...');
      
      const fallbackAnalyses: ArticleAnalysis[] = [];
      
      for (let i = 0; i < extractedContents.length; i++) {
        const content = extractedContents[i];
        console.log(`重新分析第${i + 1}篇文章（不进行相关性检查）`);
        
        try {
          const analysis = await analyzeSingleArticle(content, i + 1, undefined); // 不传入selectedTitle
          if (analysis !== null) {
            fallbackAnalyses.push(analysis);
          }
          
          // 避免API调用过于频繁
          if (i < extractedContents.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 2000));
          }
        } catch (error) {
          console.warn(`第${i + 1}篇文章重新分析失败:`, error);
          fallbackAnalyses.push(generateFallbackAnalysis(content, i));
        }
      }
      
      if (fallbackAnalyses.length > 0) {
        console.log(`✅ 放宽相关性要求后，成功分析 ${fallbackAnalyses.length} 篇文章`);
        return fallbackAnalyses;
      }
    }
    
    if (analyses.length === 0) {
      throw new Error('所有抓取的文章内容都与选定标题不相关，请检查标题选择或重新抓取相关内容');
    }
    
    return analyses;
    
  } catch (error) {
    console.error('分析文章大纲失败:', error);
    // 使用备用分析方法
    return await fallbackAnalyzeArticleOutlines(extractedContents);
  }
}

/**
 * 分析单篇文章（使用AI）
 * @param content - 文章内容
 * @param index - 文章索引
 * @param selectedTitle - 选定的博客标题，用于相关性检查
 * @returns 分析结果，如果与标题不相关则返回null
 */
async function analyzeSingleArticle(content: string, index: number, selectedTitle?: string): Promise<ArticleAnalysis | null> {
  try {
    const genAI = createGenAI();
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建相关性检查的提示（如果提供了标题）
    const relevanceCheckPrompt = selectedTitle ? `
**重要：相关性检查**
在分析之前，请首先判断这篇文章内容是否与以下目标标题相关：
目标标题：${selectedTitle}

相关性判断标准：
- 如果文章内容与目标标题的主题、关键词、或核心概念相关（相关性≥50%），请进行完整分析
- 如果相关性较低（30-50%），但仍有一定关联，也请进行分析，但标注相关性较低
- 只有当文章内容与目标标题完全不相关（相关性<30%）时，才回复不相关

如果文章内容与目标标题完全不相关（相关性<30%），请直接回复：
{
  "isRelevant": false,
  "reason": "文章内容与目标标题不相关的具体原因"
}

如果文章内容与目标标题相关（相关性≥30%），请进行完整的分析并回复：
{
  "isRelevant": true,
  "relevanceLevel": "高/中/低",
  "relevanceReason": "相关性说明"
}
` : '';
    
    const prompt = `
作为一个专业的内容分析师，请分析以下文章的大纲结构和写作风格：

${relevanceCheckPrompt}

文章内容：
${content}

请对这篇文章进行以下详细分析：

1. **大纲结构**：提取文章的主要章节和子章节标题
2. **写作风格**：分析文章的表达方式和结构特点
3. **语气调性**：识别文章的语气（专业、友好、权威等）
4. **内容结构**：分析文章的组织方式（列表式、叙述式、问答式等）
5. **关键要点**：提取文章的核心观点和要点
6. **文章标题**：从内容中提取或推断文章标题
7. **主要主题**：识别文章讨论的主要主题和话题

请用以下JSON格式回复：
{
  "isRelevant": true,
  "url": "从内容中提取的URL或网站信息",
  "title": "文章标题",
  "outline": ["主要章节1", "主要章节2", "主要章节3", "主要章节4"],
  "style": "写作风格描述（如：教程式、分析式、列表式、案例研究式等）",
  "tone": "语气调性（如：专业、友好、权威、轻松、技术性等）",
  "structure": "内容结构类型（如：问题解决式、步骤指导式、对比分析式、理论讲解式等）",
  "keyPoints": ["关键要点1", "关键要点2", "关键要点3", "关键要点4", "关键要点5"]
}

分析要求：
- 仔细阅读完整文章内容，不要遗漏重要信息
- 大纲要提取实际的章节标题，如果没有明显标题则总结段落主题
- 风格描述要具体准确，反映文章的实际写作特点
- 语气要准确识别，考虑用词选择和表达方式
- 结构类型要明确，反映文章的逻辑组织方式
- 关键要点要提取文章的核心价值和主要观点
- 标题要从文章中提取，如果找不到则根据内容生成合适的标题
- 分析要基于文章的实际内容，不要添加假设信息
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log(`文章${index}的AI分析原始响应长度:`, text.length);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      // 检查相关性（如果提供了目标标题）
      if (selectedTitle && aiResponse.isRelevant === false) {
        console.log(`文章${index}与标题"${selectedTitle}"不相关:`, aiResponse.reason || '未提供原因');
        return null; // 返回null表示文章不相关，需要过滤
      }
      
      const analysis: ArticleAnalysis = {
        url: aiResponse.url || `文章${index}`,
        title: aiResponse.title || `分析文章${index}`,
        outline: Array.isArray(aiResponse.outline) ? aiResponse.outline : ['引言', '主要内容', '结论'],
        style: aiResponse.style || '信息型',
        tone: aiResponse.tone || '专业',
        structure: aiResponse.structure || '标准式',
        keyPoints: Array.isArray(aiResponse.keyPoints) ? aiResponse.keyPoints : ['要点1', '要点2', '要点3']
      };
      
      console.log(`文章${index}分析完成并通过相关性检查:`, {
        title: analysis.title.substring(0, 50) + '...',
        outlineCount: analysis.outline.length,
        keyPointsCount: analysis.keyPoints.length,
        style: analysis.style,
        tone: analysis.tone
      });
      
      return analysis;
      
    } catch (parseError) {
      console.warn(`解析文章${index}分析响应JSON失败:`, parseError);
      return generateFallbackAnalysis(content, index - 1);
    }
    
  } catch (error) {
    console.error(`AI分析文章${index}失败:`, error);
    return generateFallbackAnalysis(content, index - 1);
  }
}

/**
 * 综合分析所有文章特点
 * @param articleAnalyses - 文章分析结果数组
 * @param extractedContents - 原始抓取的文章内容数组（用于词汇分析）
 * @returns 综合分析报告
 */
export async function synthesizeAnalysis(
  articleAnalyses: ArticleAnalysis[], 
  extractedContents: string[] = []
): Promise<string> {
  try {
    console.log('开始综合分析文章特点，文章数量:', articleAnalyses.length);
    
    const genAI = createGenAI();
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建分析数据摘要
    const analysisData = articleAnalyses.map((analysis, index) => `
文章${index + 1}：
标题：${analysis.title}
大纲：${analysis.outline.join(' → ')}
风格：${analysis.style}
语气：${analysis.tone}
结构：${analysis.structure}
关键要点：${analysis.keyPoints.join('、')}
`).join('\n');
    
    // 构建词汇分析数据
    let vocabularyAnalysisData = '';
    if (extractedContents.length > 0) {
      // 合并所有文章内容用于词汇分析
      const combinedContent = extractedContents.join('\n\n---\n\n');
      // 使用完整内容进行词汇分析，确保分析结果的完整性
      vocabularyAnalysisData = combinedContent;
    }
    
    const prompt = `
作为一个专业的内容策略分析师和词汇专家，请综合分析以下文章的特点和模式：

**文章分析数据：**
${analysisData}

${vocabularyAnalysisData ? `
**原始文章内容样本（用于词汇分析）：**
${vocabularyAnalysisData}
` : ''}

请从以下维度进行深度综合分析：

1. **内容结构模式分析**：
   - 分析这些文章的共同结构特点
   - 识别最受欢迎的大纲组织方式
   - 总结有效的内容层次结构
   - 统计章节数量分布和标题模式

2. **写作风格趋势分析**：
   - 分析主流的写作风格和表达方式
   - 识别目标受众的偏好特点
   - 总结有效的内容呈现方法
   - 分析句式结构和段落组织特点

3. **语气调性分析**：
   - 分析适合的语气调性
   - 识别专业度和亲和力的平衡点
   - 总结读者期望的沟通方式
   - 分析情感表达和互动方式

4. **词汇分布与用词特点分析**：
   - 分析高频词汇和关键术语的使用模式
   - 识别专业词汇与通用词汇的比例
   - 分析词汇复杂度和可读性水平
   - 统计动词、形容词、名词的使用偏好
   - 识别常用的连接词和过渡词
   - 分析行业术语和专业概念的表达方式
   - 总结词汇选择对目标受众的适应性

5. **关键要点模式分析**：
   - 分析文章关注的核心主题
   - 识别读者最关心的问题点
   - 总结内容价值的体现方式
   - 分析主题词和概念的分布

6. **语言表达模式分析**：
   - 分析常用的表达句式和修辞手法
   - 识别问题提出和解答的语言模式
   - 分析数据和事实的呈现方式
   - 总结引导读者行动的语言技巧

7. **SEO和关键词优化模式**：
   - 分析关键词在文章中的分布和密度
   - 识别自然融入关键词的语言技巧
   - 总结标题和子标题的关键词优化模式

8. **综合优化建议**：
   - 基于词汇分析结果提出用词建议
   - 推荐最佳的语言表达模式
   - 建议适合的词汇复杂度级别
   - 提供SEO友好的关键词使用策略
   - 推荐最佳的大纲结构模板

请提供一份详细的综合分析报告，包含具体的数据支撑和实用的建议。

**报告格式：**
## 综合分析报告

### 1. 内容结构模式分析
[具体分析内容，包含数据统计]

### 2. 写作风格趋势分析
[具体分析内容，包含风格特征]

### 3. 语气调性分析
[具体分析内容，包含语气特点]

### 4. 词汇分布与用词特点分析
[详细的词汇分析，包含：
- 高频词汇统计
- 专业词汇比例
- 词汇复杂度评估
- 用词偏好分析
- 目标受众适应性评估]

### 5. 关键要点模式分析
[具体分析内容，包含主题分布]

### 6. 语言表达模式分析
[具体分析内容，包含表达技巧]

### 7. SEO和关键词优化模式
[具体分析内容，包含优化策略]

### 8. 综合优化建议
[具体建议内容，包含：
- 词汇选择建议
- 语言表达优化
- 结构组织改进
- SEO优化策略]

### 9. 推荐写作模板
[基于分析结果的具体写作指导]
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI综合分析完成');
    return text;
    
  } catch (error) {
    console.error('综合分析失败:', error);
    
    // 返回备用分析报告
    return generateFallbackSynthesis(articleAnalyses);
  }
}

/**
 * 生成博客文章大纲
 * @param keyword - 主关键词
 * @param selectedTitle - 选中的标题
 * @param synthesisReport - 综合分析报告
 * @param extractedKnowledge - 提取的知识点
 * @param wordCount - 目标字数
 * @param readabilityLevel - 可读性级别
 * @param toneStyle - 语气风格
 * @param perspective - 视角
 * @param outlineRequirements - 大纲要求
 * @param lsiTerms - LSI术语（用于SEO优化）
 * @param additionalInfo - 附加信息（品牌/产品/场景描述）
 * @param knowledgeSource - 知识来源内容
 * @param referenceOutlineStyles - 参考文章的具体大纲风格数据
 * @returns 生成的博客大纲
 */
export async function generateBlogOutline(
  keyword: string,
  selectedTitle: string,
  synthesisReport: string,
  extractedKnowledge: string[],
  wordCount: string,
  readabilityLevel: string,
  toneStyle: string,
  perspective: string,
  outlineRequirements: string = '',
  lsiTerms: string[] = [],
  additionalInfo: string = '',
  knowledgeSource: string = '',
  referenceOutlineStyles: any[] = []
): Promise<BlogOutline> {
  try {
    console.log('=== 开始生成博客大纲 ===');
    console.log('📝 输入参数检查:');
    console.log('- keyword:', keyword);
    console.log('- selectedTitle:', selectedTitle);
    console.log('- synthesisReport长度:', synthesisReport?.length || 0);
    console.log('- extractedKnowledge数量:', extractedKnowledge?.length || 0);
    console.log('- wordCount:', wordCount);
    console.log('- readabilityLevel:', readabilityLevel);
    console.log('- toneStyle:', toneStyle);
    console.log('- perspective:', perspective);
    console.log('- outlineRequirements长度:', outlineRequirements?.length || 0);
    console.log('- lsiTerms数量:', lsiTerms?.length || 0);
    console.log('- additionalInfo长度:', additionalInfo?.length || 0);
    console.log('- knowledgeSource长度:', knowledgeSource?.length || 0);
    console.log('- referenceOutlineStyles数量:', referenceOutlineStyles?.length || 0);
    
    // 验证关键参数
    if (!keyword || !keyword.trim()) {
      throw new Error('主关键词不能为空');
    }
    if (!selectedTitle || !selectedTitle.trim()) {
      throw new Error('选中的标题不能为空');
    }
    if (!wordCount || !wordCount.trim()) {
      throw new Error('目标字数不能为空');
    }
    
    const model = createGenAI().getGenerativeModel({ model: AI_MODEL });
    console.log('🤖 使用AI模型:', AI_MODEL);
    
    // 构建知识点文本
    const knowledgeText = extractedKnowledge.length > 0 
      ? extractedKnowledge.slice(0, 30).join('\n- ') 
      : '暂无特定知识点';
    console.log('📚 知识点文本长度:', knowledgeText.length);
    
    // 构建LSI术语文本
    const lsiTermsText = lsiTerms.length > 0 
      ? lsiTerms.join('、') 
      : '无特定LSI术语';
    console.log('🔗 LSI术语文本:', lsiTermsText);
    
    // 构建参考大纲风格数据文本
    const referenceStylesText = referenceOutlineStyles.length > 0 
      ? referenceOutlineStyles.map((style, index) => `
**参考文章${index + 1}：**
- 标题：${style.title}
- 大纲结构：${Array.isArray(style.outline) ? style.outline.join(' → ') : '无具体大纲'}
- 写作风格：${style.style || '未知'}
- 语气调性：${style.tone || '未知'}
- 内容结构：${style.structure || '未知'}
- 关键要点：${Array.isArray(style.keyPoints) ? style.keyPoints.slice(0, 3).join('、') : '无'}
`).join('\n')
      : '无参考大纲风格数据';
    console.log('📖 参考大纲风格数据长度:', referenceStylesText.length);
    
    // 获取当前年份并应用全局年份策略
    const currentYear = new Date().getFullYear();
    const yearPolicyPrompt = getYearPolicyPrompt(currentYear);
    
    const prompt = `
${yearPolicyPrompt}

作为一个专业的SEO内容策略师和大纲设计专家，请基于以下全面信息生成一个符合SEO最佳实践的详细博客文章大纲：

## 核心信息
**主关键词：** ${keyword}
**文章标题：** ${selectedTitle}
**目标字数：** ${wordCount}
**可读性级别：** ${readabilityLevel}
**语气风格：** ${toneStyle}
**写作视角：** ${perspective}

## 综合分析报告（竞争对手分析）
${synthesisReport}

## 参考文章大纲风格数据（具体竞争对手大纲结构）
${referenceStylesText}

## 知识点库（四个来源综合）
**核心知识点：**
- ${knowledgeText}

## SEO优化要素
**LSI语义相关术语：** ${lsiTermsText}
*要求：在大纲各章节中自然融入这些LSI术语，提升语义相关性和搜索排名*

## 附加信息和要求
**品牌/产品/场景信息：**
${additionalInfo || '无特定品牌或产品信息'}

**知识来源内容：**
${knowledgeSource || '无额外知识来源'}

**用户附加要求：**
${outlineRequirements || '无特殊要求'}

## 大纲生成要求

基于上述信息，特别是：
- **综合分析报告**：采用成功的写作模式和SEO策略
- **参考大纲风格数据**：借鉴竞争对手的成功大纲结构、章节组织和关键要点设置
- **词汇分布分析**：运用高频词汇和专业术语的最佳比例
- **语言表达模式**：采用有效的句式结构和修辞手法

请生成一个完整的、符合SEO规则的博客文章大纲：

### 1. 引言设计
- 吸引注意力的hook开头（结合用户搜索意图）
- 清晰的价值主张和读者收益
- 包含主关键词的简洁导语
- 文章结构预览

### 2. 主体章节结构（建议4-8个章节）
**重要：请参考上述参考文章的大纲结构模式，但要创新和优化**

每个章节包含：
- **H2级别的主标题**（参考竞争对手的标题模式，自然融入主关键词或LSI术语）
- **H3级别的子标题**（2-4个，覆盖相关长尾关键词，借鉴参考文章的子标题风格）
- **关键要点列表**（3-6个要点，包含实用信息，参考竞争对手的要点设置模式）
- **预估字数**（基于总字数合理分配）
- **SEO优化建议**（关键词密度、内部链接机会等）

### 3. 结论设计
- 关键要点总结回顾
- 具体行动建议和下一步指导
- CTA调用行动（鼓励互动、分享、订阅等）
- 相关话题的扩展建议

### 4. SEO优化策略
- 关键词密度控制（1-2%）
- LSI术语自然分布
- 标题层次结构优化
- 内部链接机会识别
- 特色片段优化建议

请用以下JSON格式输出，确保所有内容都使用英文：

{
  "title": "优化后的文章标题",
  "introduction": {
    "hook": "吸引注意力的开头句子",
    "valueProposition": "明确的价值主张",
    "preview": "文章结构预览"
  },
  "sections": [
    {
      "heading": "H2级别章节标题",
      "subheadings": ["H3子标题1", "H3子标题2", "H3子标题3"],
      "keyPoints": [
        "关键要点1：具体的、可操作的内容",
        "关键要点2：包含数据或案例的观点",
        "关键要点3：实用技巧或策略"
      ],
      "estimatedWords": 400,
      "seoNotes": "该章节的SEO优化要点和关键词使用建议",
      "lsiTermsUsed": ["使用的LSI术语1", "使用的LSI术语2"],
      "referencePattern": "借鉴了哪个参考文章的结构模式"
    }
  ],
  "conclusion": {
    "summary": "关键要点总结",
    "actionSteps": "具体行动建议",
    "cta": "调用行动内容"
  },
  "seoStrategy": {
    "primaryKeyword": "${keyword}",
    "keywordDensity": "1.5%",
    "lsiTermsDistribution": "LSI术语在各章节的分布策略",
    "internalLinkingOpportunities": ["内部链接机会1", "内部链接机会2"],
    "featuredSnippetOptimization": "针对特色片段的优化建议",
    "competitorInsights": "从参考文章中学到的关键结构洞察"
  },
  "wordCount": "${wordCount}",
  "readabilityLevel": "${readabilityLevel}",
  "toneStyle": "${toneStyle}",
  "perspective": "${perspective}"
}

**生成要求：**
1. 严格参考上述参考文章的成功大纲结构模式
2. 自然融入所有提供的LSI术语，避免关键词堆砌
3. 确保大纲逻辑清晰，层次分明，优于竞争对手
4. 每个章节都要有明确的SEO价值和用户价值
5. 子标题要包含长尾关键词，提升搜索覆盖面
6. 内容要解决用户的实际问题和搜索意图
7. 字数分配要合理，确保整体目标字数达成
8. 语言表达要符合目标可读性级别
9. 整体结构要易于扫读和理解
10. 包含足够的实用信息和可操作建议
11. **重点：充分利用参考文章的大纲风格数据，创造更优秀的结构**
`;
    
    console.log('📤 发送给Google Generative AI API的完整prompt:');
    console.log('prompt长度:', prompt.length);
    console.log('prompt内容:');
    console.log(prompt);
    
    console.log('🚀 开始调用Google Generative AI API...');
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('📥 收到Google Generative AI API的原始响应:');
    console.log('响应长度:', text.length);
    console.log('响应内容:');
    console.log(text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      console.log('🧹 清理后的JSON文本:');
      console.log(cleanedText);
      
      const aiResponse = JSON.parse(cleanedText);
      console.log('✅ JSON解析成功，AI响应对象:');
      console.log(JSON.stringify(aiResponse, null, 2));
      
      // 构建标准化的BlogOutline对象
      const outline: BlogOutline = {
        title: aiResponse.title || selectedTitle,
        introduction: typeof aiResponse.introduction === 'object' 
          ? `${aiResponse.introduction.hook || ''} ${aiResponse.introduction.valueProposition || ''} ${aiResponse.introduction.preview || ''}`.trim()
          : (aiResponse.introduction || `这是一篇关于${keyword}的综合指南，将为您提供实用的见解和可操作的建议。`),
        sections: Array.isArray(aiResponse.sections) ? aiResponse.sections.map((section: any) => ({
          heading: section.heading || '主要内容',
          subheadings: Array.isArray(section.subheadings) ? section.subheadings : [],
          keyPoints: Array.isArray(section.keyPoints) ? section.keyPoints : [],
          estimatedWords: typeof section.estimatedWords === 'number' ? section.estimatedWords : 250,
          referencePattern: section.referencePattern || '无参考文章'
        })) : [],
        conclusion: typeof aiResponse.conclusion === 'object'
          ? `${aiResponse.conclusion.summary || ''} ${aiResponse.conclusion.actionSteps || ''} ${aiResponse.conclusion.cta || ''}`.trim()
          : (aiResponse.conclusion || `${keyword}在现代数字策略中继续发挥重要作用。通过本文的指导，您应该能够更好地理解和应用相关概念。`),
        wordCount,
        readabilityLevel,
        toneStyle,
        perspective,
        seoKeywords: Array.isArray(aiResponse.seoStrategy?.lsiTermsDistribution) 
          ? [keyword, ...lsiTerms.slice(0, 5)]
          : [keyword, ...lsiTerms.slice(0, 3)]
      };
      
      // 如果没有章节，生成默认章节
      if (outline.sections.length === 0) {
        console.log('⚠️ AI响应中没有章节，使用默认章节');
        outline.sections = generateDefaultSections(keyword, selectedTitle);
      }
      
      console.log('🎉 博客大纲生成成功！');
      console.log('最终大纲对象:');
      console.log(JSON.stringify(outline, null, 2));
      console.log('章节数量:', outline.sections.length);
      console.log('SEO关键词数量:', outline.seoKeywords.length);
      
      return outline;
      
    } catch (parseError) {
      console.error('❌ 解析AI大纲响应JSON失败:');
      console.error('解析错误:', parseError);
      console.error('原始响应文本:', text);
      console.error('清理后文本:', text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim());
      
      console.log('🔄 使用备用大纲生成...');
      return generateFallbackOutline(keyword, selectedTitle, wordCount, readabilityLevel, toneStyle, perspective);
    }
    
  } catch (error) {
    console.error('❌ 生成博客大纲失败:');
    console.error('错误类型:', error instanceof Error ? error.constructor.name : typeof error);
    console.error('错误消息:', error instanceof Error ? error.message : String(error));
    console.error('错误堆栈:', error instanceof Error ? error.stack : '无堆栈信息');
    
    // 检查是否是API密钥或网络相关错误
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes('API_KEY') || errorMessage.includes('key')) {
      console.error('🔑 可能是API密钥配置问题');
    } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
      console.error('🌐 可能是网络连接问题');
    } else if (errorMessage.includes('quota') || errorMessage.includes('limit')) {
      console.error('📊 可能是API配额限制问题');
    }
    
    console.log('🔄 使用备用大纲生成...');
    return generateFallbackOutline(keyword, selectedTitle, wordCount, readabilityLevel, toneStyle, perspective);
  }
} 
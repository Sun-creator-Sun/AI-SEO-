// 重新导出所有功能模块
export * from './types';
export * from './search-api';
export * from './ai-analysis';
export * from './content-analysis';
export * from './title-generation';

// 保持向后兼容性的主要集成函数
import { searchKeyword } from './search-api';
import { analyzeSearchIntent, generateBlogIdeas } from './ai-analysis';
import { searchRelatedContent, filterBlogContent, extractKnowledgePoints, extractLSITerms } from './content-analysis';
import { generateBlogTitles } from './title-generation';

// 导出主要集成函数以保持向后兼容性
export {
  searchKeyword,
  analyzeSearchIntent,
  generateBlogIdeas,
  searchRelatedContent,
  filterBlogContent,
  extractKnowledgePoints,
  extractLSITerms,
  generateBlogTitles
};export * from './outline-generation';

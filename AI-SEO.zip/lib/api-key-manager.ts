/**
 * 多API Key管理系统
 * 支持自动切换、限流、故障转移等功能
 */

export interface APIKeyConfig {
  key: string;
  name: string;
  provider: 'gemini' | 'openai' | 'claude' | 'deepseek';
  rateLimit: {
    requestsPerMinute: number;
    requestsPerHour: number;
    requestsPerDay: number;
  };
  priority: number; // 优先级，数字越小优先级越高
  enabled: boolean;
  lastUsed?: Date;
  errorCount: number;
  maxErrors: number; // 最大错误次数，超过后暂时禁用
  cooldownMinutes: number; // 冷却时间（分钟）
}

export interface APIKeyUsage {
  key: string;
  timestamp: Date;
  success: boolean;
  responseTime: number;
  error?: string;
}

export interface RateLimitInfo {
  key: string;
  currentMinute: number;
  currentHour: number;
  currentDay: number;
  limitMinute: number;
  limitHour: number;
  limitDay: number;
}

class APIKeyManager {
  private keys: Map<string, APIKeyConfig> = new Map();
  private usageHistory: APIKeyUsage[] = [];
  private rateLimitCache: Map<string, RateLimitInfo> = new Map();

  constructor() {
    this.initializeDefaultKeys();
  }

  /**
   * 初始化默认API Keys
   */
  private initializeDefaultKeys() {
    const defaultKeys: APIKeyConfig[] = [
      {
        key: 'AIzaSyC3KPWZOzIqBaPtKt4oH3S-yGAaEjHP5EA',
        name: 'Gemini Key 1',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 1,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      },
      {
        key: 'AIzaSyB6dj7Pya87G-D0WmPsrP1TXfDaPeNzhXU',
        name: 'Gemini Key 2',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      }
      ,
      {
        key: 'AIzaSyD9p81FF2b7_pRi7hJEttU_HY6eCppCPds',
        name: 'Gemini Key 3',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      } ,
      {
        key: 'AIzaSyBQsUxaAm2wLyZfQnoqYhytSxI89XYSjq0',
        name: 'Gemini Key 4',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      } ,
      {
        key: 'AIzaSyBQMK0Cm_hkoJJFLqsu_oI8tnAuweRDAJs',
        name: 'Gemini Key 5',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      } ,
      {
        key: 'AIzaSyBFj3yWwIrcJKu3wRjGd78Sz9vS_ypTd10',
        name: 'Gemini Key 6',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      } ,
      {
        key: 'AIzaSyC2nKFWo5xY1qxiAULtIP5y-LTyWpdkJVQ',
        name: 'Gemini Key 7',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      },
      {
        key: 'AIzaSyDMidZCtfEtlocrgwem5C_xAKxV01YXowE',
        name: 'Gemini Key 7',
        provider: 'gemini',
        rateLimit: {
          requestsPerMinute: 60,
          requestsPerHour: 1000,
          requestsPerDay: 10000
        },
        priority: 2,
        enabled: true,
        errorCount: 0,
        maxErrors: 5,
        cooldownMinutes: 10
      }
    ];

    defaultKeys.forEach(keyConfig => {
      this.addKey(keyConfig);
    });
  }

  /**
   * 添加新的API Key
   */
  addKey(keyConfig: APIKeyConfig): void {
    this.keys.set(keyConfig.key, keyConfig);
    console.log(`INFO: Added API key: ${keyConfig.name} (${keyConfig.provider})`);
  }

  /**
   * 移除API Key
   */
  removeKey(key: string): boolean {
    const removed = this.keys.delete(key);
    if (removed) {
      console.log(`INFO: Removed API key: ${key}`);
    }
    return removed;
  }

  /**
   * 获取可用的API Key（按优先级排序）
   */
  getAvailableKeys(provider: string): APIKeyConfig[] {
    const now = new Date();
    const availableKeys: APIKeyConfig[] = [];

    for (const keyConfig of Array.from(this.keys.values())) {
      if (keyConfig.provider !== provider || !keyConfig.enabled) {
        continue;
      }

      // 检查是否在冷却期
      if (keyConfig.lastUsed) {
        const cooldownEnd = new Date(keyConfig.lastUsed.getTime() + keyConfig.cooldownMinutes * 60 * 1000);
        if (now < cooldownEnd) {
          continue;
        }
      }

      // 检查错误次数
      if (keyConfig.errorCount >= keyConfig.maxErrors) {
        continue;
      }

      // 检查限流
      if (!this.isWithinRateLimit(keyConfig.key)) {
        continue;
      }

      availableKeys.push(keyConfig);
    }

    // 按优先级排序
    return availableKeys.sort((a, b) => a.priority - b.priority);
  }

  /**
   * 获取最佳可用的API Key
   */
  getBestKey(provider: string): APIKeyConfig | null {
    const availableKeys = this.getAvailableKeys(provider);
    return availableKeys.length > 0 ? availableKeys[0] : null;
  }

  /**
   * 检查是否在限流范围内
   */
  private isWithinRateLimit(key: string): boolean {
    const keyConfig = this.keys.get(key);
    if (!keyConfig) return false;

    const now = new Date();
    const minuteAgo = new Date(now.getTime() - 60 * 1000);
    const hourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const recentUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= minuteAgo
    );

    const hourlyUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= hourAgo
    );

    const dailyUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= dayAgo
    );

    return (
      recentUsage.length < keyConfig.rateLimit.requestsPerMinute &&
      hourlyUsage.length < keyConfig.rateLimit.requestsPerHour &&
      dailyUsage.length < keyConfig.rateLimit.requestsPerDay
    );
  }

  /**
   * 记录API Key使用情况
   */
  recordUsage(usage: APIKeyUsage): void {
    this.usageHistory.push(usage);
    
    // 清理旧的使用记录（保留7天）
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    this.usageHistory = this.usageHistory.filter(usage => usage.timestamp > weekAgo);

    // 更新Key配置
    const keyConfig = this.keys.get(usage.key);
    if (keyConfig) {
      keyConfig.lastUsed = new Date();
      
      if (!usage.success) {
        keyConfig.errorCount++;
        console.warn(`WARN: API key ${keyConfig.name} error count: ${keyConfig.errorCount}/${keyConfig.maxErrors}`);
        
        if (keyConfig.errorCount >= keyConfig.maxErrors) {
          keyConfig.enabled = false;
          console.error(`ERROR: API key ${keyConfig.name} disabled due to too many errors`);
        }
      } else {
        // 成功请求后重置错误计数
        keyConfig.errorCount = 0;
      }
    }
  }

  /**
   * 获取限流信息
   */
  getRateLimitInfo(key: string): RateLimitInfo | null {
    const keyConfig = this.keys.get(key);
    if (!keyConfig) return null;

    const now = new Date();
    const minuteAgo = new Date(now.getTime() - 60 * 1000);
    const hourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const recentUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= minuteAgo
    );

    const hourlyUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= hourAgo
    );

    const dailyUsage = this.usageHistory.filter(usage => 
      usage.key === key && usage.timestamp >= dayAgo
    );

    return {
      key,
      currentMinute: recentUsage.length,
      currentHour: hourlyUsage.length,
      currentDay: dailyUsage.length,
      limitMinute: keyConfig.rateLimit.requestsPerMinute,
      limitHour: keyConfig.rateLimit.requestsPerHour,
      limitDay: keyConfig.rateLimit.requestsPerDay
    };
  }

  /**
   * 获取所有Key的状态
   */
  getAllKeyStatus(): Array<APIKeyConfig & { rateLimitInfo: RateLimitInfo | null }> {
    return Array.from(this.keys.values()).map(keyConfig => ({
      ...keyConfig,
      rateLimitInfo: this.getRateLimitInfo(keyConfig.key)
    }));
  }

  /**
   * 手动启用/禁用Key
   */
  setKeyEnabled(key: string, enabled: boolean): boolean {
    const keyConfig = this.keys.get(key);
    if (keyConfig) {
      keyConfig.enabled = enabled;
      console.log(`INFO: API key ${keyConfig.name} ${enabled ? 'enabled' : 'disabled'}`);
      return true;
    }
    return false;
  }

  /**
   * 重置Key的错误计数
   */
  resetKeyErrors(key: string): boolean {
    const keyConfig = this.keys.get(key);
    if (keyConfig) {
      keyConfig.errorCount = 0;
      keyConfig.enabled = true;
      console.log(`INFO: Reset error count for API key ${keyConfig.name}`);
      return true;
    }
    return false;
  }

  /**
   * 获取使用统计
   */
  getUsageStats(): {
    totalRequests: number;
    successfulRequests: number;
    failedRequests: number;
    averageResponseTime: number;
    keyStats: Array<{
      key: string;
      name: string;
      requests: number;
      successRate: number;
      avgResponseTime: number;
    }>;
  } {
    const totalRequests = this.usageHistory.length;
    const successfulRequests = this.usageHistory.filter(u => u.success).length;
    const failedRequests = totalRequests - successfulRequests;
    const averageResponseTime = totalRequests > 0 
      ? this.usageHistory.reduce((sum, u) => sum + u.responseTime, 0) / totalRequests 
      : 0;

    const keyStats = Array.from(this.keys.values()).map(keyConfig => {
      const keyUsage = this.usageHistory.filter(u => u.key === keyConfig.key);
      const keyRequests = keyUsage.length;
      const keySuccess = keyUsage.filter(u => u.success).length;
      const keySuccessRate = keyRequests > 0 ? (keySuccess / keyRequests) * 100 : 0;
      const keyAvgResponseTime = keyRequests > 0 
        ? keyUsage.reduce((sum, u) => sum + u.responseTime, 0) / keyRequests 
        : 0;

      return {
        key: keyConfig.key,
        name: keyConfig.name,
        requests: keyRequests,
        successRate: keySuccessRate,
        avgResponseTime: keyAvgResponseTime
      };
    });

    return {
      totalRequests,
      successfulRequests,
      failedRequests,
      averageResponseTime,
      keyStats
    };
  }
}

// 创建全局实例
export const apiKeyManager = new APIKeyManager();

/**
 * 获取当前可用的API Key
 */
export function getCurrentAPIKey(provider: string = 'gemini'): string | null {
  const bestKey = apiKeyManager.getBestKey(provider);
  return bestKey ? bestKey.key : null;
}

/**
 * 记录API调用结果
 */
export function recordAPIResult(
  key: string, 
  success: boolean, 
  responseTime: number, 
  error?: string
): void {
  apiKeyManager.recordUsage({
    key,
    timestamp: new Date(),
    success,
    responseTime,
    error
  });
} 
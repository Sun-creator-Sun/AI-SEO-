/**
 * 内容验证相关的工具函数
 * 用于检查抓取内容的质量和有效性
 */

/**
 * 内容验证结果接口
 */
export interface ContentValidationResult {
  isValid: boolean;
  failureReason?: string;
}

/**
 * 内容对象接口（用于类型安全）
 */
export interface ContentObject {
  url: string;
  title: string;
  content: string;
  aiRelevanceScore?: number;
  index?: number;
  [key: string]: any; // 支持其他属性
}

/**
 * HTTP错误状态码模式
 */
const HTTP_ERROR_PATTERNS = [
  'HTTP 404', 'HTTP 403', 'HTTP 401',
  'HTTP 500', 'HTTP 502', 'HTTP 503', 'HTTP 504',
  'HTTP 50' // 匹配所有50x错误
] as const;

/**
 * 错误关键词模式
 */
const ERROR_KEYWORDS = [
  '无法抓取内容',
  '页面未找到',
  '服务器错误',
  '访问被拒绝',
  '未授权访问',
  '客户端错误',
  '请求失败',
  '抓取失败',
  '内容为空',
  '内容过短'
] as const;

/**
 * 验证内容是否有效（不包含错误信息且内容足够长）
 * @param content - 要验证的内容字符串
 * @param minLength - 最小长度要求（默认100字符）
 * @returns 验证结果对象，包含是否有效和失败原因
 */
export function validateContentQuality(
  content: string, 
  minLength: number = 100
): ContentValidationResult {
  // 检查内容是否存在
  if (!content) {
    return { isValid: false, failureReason: '内容为空' };
  }
  
  const trimmedContent = content.trim();
  
  // 检查内容长度
  if (trimmedContent.length <= minLength) {
    return { 
      isValid: false, 
      failureReason: `内容过短 (${trimmedContent.length}字符 < ${minLength}字符)` 
    };
  }
  
  // 检查是否包含HTTP错误状态码
  for (const pattern of HTTP_ERROR_PATTERNS) {
    if (content.includes(pattern)) {
      return { isValid: false, failureReason: `包含HTTP错误: ${pattern}` };
    }
  }
  
  // 检查是否包含错误关键词
  for (const keyword of ERROR_KEYWORDS) {
    if (content.includes(keyword)) {
      return { isValid: false, failureReason: `包含错误关键词: ${keyword}` };
    }
  }
  
  // 所有检查都通过
  return { isValid: true };
}

/**
 * 过滤有效的内容对象数组
 * @param contentObjects - 内容对象数组
 * @param minLength - 最小长度要求（默认100字符）
 * @returns 过滤后的有效内容对象数组
 */
export function filterValidContentObjects(
  contentObjects: ContentObject[], 
  minLength: number = 100
): ContentObject[] {
  if (!Array.isArray(contentObjects)) {
    console.warn('filterValidContentObjects: 输入不是数组，返回空数组');
    return [];
  }
  
  return contentObjects.filter(contentObj => {
    // 检查对象结构
    if (!contentObj || typeof contentObj !== 'object') {
      return false;
    }
    
    // 检查必要属性
    if (!contentObj.content || typeof contentObj.content !== 'string') {
      return false;
    }
    
    // 使用内容质量验证函数
    const validation = validateContentQuality(contentObj.content, minLength);
    return validation.isValid;
  });
}

/**
 * 验证单个内容字符串是否通过质量检查
 * @param content - 内容字符串
 * @param minLength - 最小长度要求
 * @returns 是否有效
 */
export function isValidContent(content: string, minLength: number = 100): boolean {
  const validation = validateContentQuality(content, minLength);
  return validation.isValid;
}

/**
 * 获取内容验证失败的详细原因
 * @param content - 内容字符串
 * @param minLength - 最小长度要求
 * @returns 失败原因字符串，如果验证通过则返回null
 */
export function getContentValidationError(
  content: string, 
  minLength: number = 100
): string | null {
  const validation = validateContentQuality(content, minLength);
  return validation.isValid ? null : validation.failureReason || '未知验证错误';
}

/**
 * 批量验证内容数组，返回验证结果统计
 * @param contents - 内容字符串数组
 * @param minLength - 最小长度要求
 * @returns 验证统计信息
 */
export function validateContentBatch(
  contents: string[], 
  minLength: number = 100
): {
  total: number;
  valid: number;
  invalid: number;
  validContents: string[];
  invalidContents: Array<{ content: string; reason: string }>;
} {
  const results = {
    total: contents.length,
    valid: 0,
    invalid: 0,
    validContents: [] as string[],
    invalidContents: [] as Array<{ content: string; reason: string }>
  };
  
  contents.forEach(content => {
    const validation = validateContentQuality(content, minLength);
    if (validation.isValid) {
      results.valid++;
      results.validContents.push(content);
    } else {
      results.invalid++;
      results.invalidContents.push({
        content,
        reason: validation.failureReason || '未知错误'
      });
    }
  });
  
  return results;
} 
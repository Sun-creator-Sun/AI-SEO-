/**
 * FastGPT API 配置
 */
export const FASTGPT_CONFIG = {
  BASE_URL: 'https://fastgpt.vertu.cn',
  TOKEN: 'fastgpt-xY7QZarsJ6SD81cFCjq2KgTe5iba8JoaWqvXvMfX5sqOuRXU42cGW',
  ENDPOINTS: {
    DATASET_LIST: '/api/core/dataset/list',
    DATASET_DETAIL: '/api/core/dataset/detail',
    CHAT_COMPLETIONS: '/api/v1/chat/completions'
  }
} as const

/**
 * 生成聊天ID
 */
export function generateChatId(): string {
  return `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * 生成响应ID
 */
export function generateResponseId(): string {
  return `response_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
} 
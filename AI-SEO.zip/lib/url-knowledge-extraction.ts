/**
 * URL知识提取相关的API调用和数据处理
 */

export interface UrlAnalysisResult {
  brand: string;
  products: string[];
  productDescriptions: string[];
  summary: string;
  productImage?: string; // 添加产品图片URL字段
}

/**
 * 使用Jina API获取网页内容
 * @param url 要分析的URL
 * @returns 网页的文本内容
 */
export async function fetchUrlContent(url: string): Promise<string> {
  const jinaUrl = `https://r.jina.ai/${url}`;
  const response = await fetch(jinaUrl, {
    method: 'GET',
    headers: {
      'Authorization': 'Bearer jina_5025f50722184017999eac2ce6f27831CuBCqqtl7tX8oKYECPZr7ueNHUSd',
      'X-Retain-Images': 'all' // 保留所有图片以便提取产品图片
    }
  });

  if (!response.ok) {
    throw new Error(`获取网页内容失败: HTTP ${response.status}`);
  }

  return await response.text();
}

/**
 * 使用内部API分析网页内容，提取品牌、产品等信息
 * @param content 网页文本内容
 * @param focusInfo 用户特别关注的信息（可选）
 * @returns 分析结果
 */
export async function analyzeContentWithGemini(content: string, focusInfo?: string): Promise<UrlAnalysisResult> {
  // 构建专门用于URL分析的提示词，包含用户关注信息和图片提取
  let analysisPrompt = `You are a professional website content analyst. Please analyze the following web content and extract brand, product, and related information, including the most suitable product image.`;
  
  // 如果有关注信息，添加特别提取要求
  if (focusInfo && focusInfo.trim()) {
    analysisPrompt += `\n\nSPECIAL FOCUS: Please pay particular attention to and extract information related to: "${focusInfo.trim()}"`;
    analysisPrompt += `\nEnsure that any information about "${focusInfo.trim()}" is prominently included in the analysis results.`;
  }
  
  analysisPrompt += `\n\nPlease analyze the content for:
1. Brand name: Accurately identify the brand, if unable to identify please fill in "Unknown Brand"
2. Product list: Extract specific product names, if no products return empty array
3. Product descriptions: Provide concise descriptions for each product (in English)
4. Overall summary: Provide a comprehensive but concise summary of the website/brand (in English)
5. Product image: Analyze all images in the content and select the MOST SUITABLE product image URL that best represents the main product or brand. Consider:
   - Images that show actual products (phones, devices, cars, etc.)
   - Hero images or main banner images
   - Images with proper resolution (avoid small icons, logos, or decorative elements)
   - Images that are directly related to the brand or main products
   - Avoid social media icons, footer images, navigation elements
   - If multiple product images exist, choose the most prominent or representative one
   - Return the complete HTTP/HTTPS URL, not blob URLs or relative paths
   - If no suitable product image is found, return empty string`;

  if (focusInfo && focusInfo.trim()) {
    analysisPrompt += `\n6. Focus information: Make sure to include relevant details about "${focusInfo.trim()}" in the summary and product descriptions where applicable`;
  }

  analysisPrompt += `\n\nNote: Please respond in English only.

Web content to analyze:
${content}`;

  // 通过URL内容分析API调用进行分析
  const response = await fetch('/api/analyze-url-content', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      content: content,
      customPrompt: analysisPrompt
    }),
  });

  if (!response.ok) {
    throw new Error(`URL内容分析API调用失败: HTTP ${response.status}`);
  }

  const data = await response.json();
  
  // 检查API返回的错误
  if (data.error) {
    throw new Error(`URL内容分析失败: ${data.error}`);
  }

  // 如果返回了完整的分析结果，转换为UrlAnalysisResult格式
  if (data.analysis && typeof data.analysis === 'object') {
    console.log('✅ 获得URL内容分析结果，包含图片:', !!data.productImage);
    
    // 转换分析结果为UrlAnalysisResult格式
    const analysisResult: UrlAnalysisResult = {
      brand: data.analysis.brand?.name || 'Unknown Brand',
      products: data.analysis.products?.map((p: any) => p.name) || [],
      productDescriptions: data.analysis.products?.map((p: any) => p.description) || [],
      summary: data.analysis.summary || '无法提取网站摘要',
      productImage: data.productImage || undefined
    };
    
    return analysisResult;
  }

  // 否则使用备用解析方法（向后兼容）
  console.log('⚠️ 使用备用解析方法');
  const analysisResult = parseContentForUrlAnalysis(content, data.knowledge || [], focusInfo);
  return analysisResult;
}

/**
 * 解析网页内容，提取URL分析结果
 * @param content 网页内容
 * @param keywords 提取的关键词
 * @param focusInfo 用户特别关注的信息（可选）
 * @returns URL分析结果
 */
function parseContentForUrlAnalysis(content: string, keywords: string[], focusInfo?: string): UrlAnalysisResult {
  const contentLower = content.toLowerCase();
  
  // 提取品牌信息
  let brand = "Unknown Brand";
  
  // 检测常见品牌
  if (contentLower.includes('vertu')) {
    brand = "Vertu";
  } else if (contentLower.includes('apple')) {
    brand = "Apple";
  } else if (contentLower.includes('google')) {
    brand = "Google";
  } else if (contentLower.includes('microsoft')) {
    brand = "Microsoft";
  } else {
    // 尝试从标题或第一段提取品牌
    const lines = content.split('\n').filter(line => line.trim());
    if (lines.length > 0) {
      const firstLine = lines[0].trim();
      const words = firstLine.split(/\s+/);
      if (words.length > 0 && words[0].length > 2) {
        brand = words[0];
      }
    }
  }
  
  // 从关键词中提取产品信息，如果有关注信息，优先提取相关产品
  let products = keywords.filter(keyword => 
    keyword.length > 3 && 
    !['the', 'and', 'for', 'with', 'that', 'this'].includes(keyword.toLowerCase())
  );
  
  // 如果有关注信息，优先提取相关的关键词
  if (focusInfo && focusInfo.trim()) {
    const focusKeywords = keywords.filter(keyword => 
      keyword.toLowerCase().includes(focusInfo.toLowerCase()) ||
      focusInfo.toLowerCase().includes(keyword.toLowerCase())
    );
    // 将相关关键词放在前面
    products = [...focusKeywords, ...products.filter(p => !focusKeywords.includes(p))];
  }
  
  products = products.slice(0, 5);
  
  // 生成产品描述，如果有关注信息，在描述中提及
  const productDescriptions = products.map(product => {
    let description = `${product} related products and services`;
    if (focusInfo && focusInfo.trim()) {
      const focusLower = focusInfo.toLowerCase();
      const productLower = product.toLowerCase();
      if (productLower.includes(focusLower) || focusLower.includes(productLower)) {
        description += ` with focus on ${focusInfo}`;
      }
    }
    return description;
  });
  
  // 生成概述，包含关注信息
  let summary = `This is ${brand}'s official website, primarily providing ${products.slice(0, 3).join(', ')} and related products and services.`;
  
  if (focusInfo && focusInfo.trim()) {
    summary += ` Special attention to ${focusInfo} is highlighted throughout the content.`;
  }
  
  // 注意：产品图片现在由AI智能提取，这里不再使用规则匹配
  // 如果没有解析到真实的产品图片，就不设置任何图片
  const productImage = undefined;
  
  return {
    brand,
    products,
    productDescriptions,
    summary,
    productImage
  };
}

/**
 * 完整的URL知识提取流程
 * @param url 要分析的URL
 * @param focusInfo 用户特别关注的信息（可选）
 * @returns 分析结果
 */
export async function extractKnowledgeFromUrl(url: string, focusInfo?: string): Promise<UrlAnalysisResult> {
  // 第一步：获取网页内容
  const content = await fetchUrlContent(url);
  
  // 第二步：使用内部API分析内容，包含关注信息
  const analysis = await analyzeContentWithGemini(content, focusInfo);
  
  return analysis;
}

/**
 * 从网页内容中提取适合的产品图片
 * @param content 包含图片信息的网页内容
 * @param brand 品牌名称
 * @returns 最适合的产品图片URL或undefined
 */
function extractProductImage(content: string, brand: string): string | undefined {
  // Jina API可能以markdown格式返回图片，如 ![alt](url) 或者直接的URL
  const markdownImageRegex = /!\[([^\]]*)\]\(([^)]+)\)/g;
  const directImageRegex = /https?:\/\/[^\s<>"']+\.(?:jpg|jpeg|png|webp|gif)(?:\?[^\s<>"']*)?/gi;
  
  const images: { url: string; alt?: string }[] = [];
  
  // 提取markdown格式的图片
  let markdownMatch;
  while ((markdownMatch = markdownImageRegex.exec(content)) !== null) {
    const imageUrl = markdownMatch[2];
    // 跳过blob URL
    if (!imageUrl.startsWith('blob:') && imageUrl.startsWith('http')) {
      images.push({
        url: imageUrl,
        alt: markdownMatch[1]
      });
    }
  }
  
  // 提取直接的图片URL
  const directImages = content.match(directImageRegex) || [];
  directImages.forEach(url => {
    // 避免重复添加，跳过blob URL
    if (!url.startsWith('blob:') && !images.some(img => img.url === url)) {
      images.push({ url });
    }
  });
  
  if (images.length === 0) {
    console.log('在Jina内容中未找到有效图片');
    return undefined;
  }
  
  // 过滤和评分图片
  const scoredImages = images.map(img => {
    let score = 0;
    const imgLower = img.url.toLowerCase();
    const altLower = (img.alt || '').toLowerCase();
    const brandLower = brand.toLowerCase();
    
    // 品牌相关性评分
    if (imgLower.includes(brandLower) || altLower.includes(brandLower)) {
      score += 10;
    }
    
    // Alt文本中的产品相关关键词评分
    const productKeywords = ['product', 'hero', 'main', 'banner', 'featured', 'cover', 'phone', 'device', 'watch', 'luxury'];
    productKeywords.forEach(keyword => {
      if (imgLower.includes(keyword) || altLower.includes(keyword)) {
        score += 5;
      }
    });
    
    // 避免小图标和装饰图片
    const excludeKeywords = ['icon', 'logo', 'thumb', 'avatar', 'badge', 'social', 'footer', 'header', 'menu'];
    excludeKeywords.forEach(keyword => {
      if (imgLower.includes(keyword) || altLower.includes(keyword)) {
        score -= 5;
      }
    });
    
    // 图片尺寸提示评分（通过URL中的尺寸参数）
    const sizeMatch = img.url.match(/[?&]w=(\d+)|[?&]width=(\d+)|[-_](\d+)x(\d+)/);
    if (sizeMatch) {
      const width = parseInt(sizeMatch[1] || sizeMatch[2] || sizeMatch[3] || '0');
      if (width >= 300) {
        score += 3;
      }
      if (width >= 500) {
        score += 2;
      }
    }
    
    // 如果有alt文本且不为空，额外加分
    if (img.alt && img.alt.trim()) {
      score += 2;
    }
    
    return { url: img.url, alt: img.alt, score };
  });
  
  // 去重并按评分排序
  const uniqueImages = Array.from(new Set(scoredImages.map(img => img.url)))
    .map(url => scoredImages.find(img => img.url === url)!)
    .sort((a, b) => b.score - a.score);
  
  // 返回评分最高的图片，但确保它是有效的图片URL
  for (const img of uniqueImages) {
    if (img.score > 0 && img.url.startsWith('http')) {
      return img.url;
    }
  }
  
  // 如果没有高评分图片，返回第一个有效URL
  const fallbackImage = uniqueImages.find(img => img.url.startsWith('http'))?.url;
  return fallbackImage; // 如果没有找到，返回undefined
} 
import { callGeminiDirectly } from './gemini-direct-api';
import { GENERATIVE_AI_KEY, AI_MODEL } from './config';

/**
 * Gemini API 不同使用场景示例
 */

/**
 * 场景1: 基本文本生成（无特殊格式要求）
 */
export async function generateBasicText(prompt: string) {
  const result = await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt
    // 不传递generationConfig，使用默认配置
  );
  return result;
}

/**
 * 场景2: SEO关键词分析（强制JSON格式）
 */
export async function analyzeSEOKeywords(content: string) {
  const seoConfig = {
    temperature: 0.3,
    topK: 20,
    topP: 0.8,
    maxOutputTokens: 2048,
    responseMimeType: "application/json",
    responseSchema: {
      type: "object",
      properties: {
        brand: {
          type: "string",
          description: "品牌名称"
        },
        products: {
          type: "array",
          items: { type: "string" },
          description: "产品列表"
        },
        keywords: {
          type: "array",
          items: { type: "string" },
          description: "SEO关键词"
        }
      },
      required: ["brand", "products", "keywords"]
    }
  };

  const prompt = `分析以下内容的SEO关键词：\n${content}`;
  
  return await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt, 
    seoConfig
  );
}

/**
 * 场景3: 代码生成（低温度，高token限制）
 */
export async function generateCode(requirement: string, language: string = 'TypeScript') {
  const codeConfig = {
    temperature: 0.1, // 低温度确保代码准确性
    topK: 10,
    topP: 0.7,
    maxOutputTokens: 4096, // 更高的token限制用于长代码
    responseMimeType: "application/json",
    responseSchema: {
      type: "object",
      properties: {
        code: {
          type: "string",
          description: "生成的代码"
        },
        explanation: {
          type: "string", 
          description: "代码说明"
        },
        dependencies: {
          type: "array",
          items: { type: "string" },
          description: "需要的依赖包"
        }
      },
      required: ["code", "explanation"]
    }
  };

  const prompt = `请生成${language}代码实现以下需求：\n${requirement}`;
  
  return await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt, 
    codeConfig
  );
}

/**
 * 场景4: 创意写作（高温度，更多随机性）
 */
export async function generateCreativeContent(topic: string, style: string = '故事') {
  const creativeConfig = {
    temperature: 0.8, // 高温度增加创意性
    topK: 40,
    topP: 0.9,
    maxOutputTokens: 3000
    // 不使用responseSchema，允许自由文本输出
  };

  const prompt = `以${style}的形式，围绕"${topic}"这个主题进行创作。`;
  
  return await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt, 
    creativeConfig
  );
}

/**
 * 场景5: 数据分析（结构化输出）
 */
export async function analyzeData(data: string) {
  const analysisConfig = {
    temperature: 0.2,
    maxOutputTokens: 2048,
    responseMimeType: "application/json",
    responseSchema: {
      type: "object",
      properties: {
        summary: {
          type: "string",
          description: "数据总结"
        },
        insights: {
          type: "array",
          items: { type: "string" },
          description: "关键洞察"
        },
        recommendations: {
          type: "array",
          items: { type: "string" },
          description: "建议行动"
        },
        metrics: {
          type: "object",
          properties: {
            trend: { type: "string" },
            growth: { type: "number" },
            confidence: { type: "number" }
          }
        }
      },
      required: ["summary", "insights", "recommendations"]
    }
  };

  const prompt = `请分析以下数据并提供洞察：\n${data}`;
  
  return await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt, 
    analysisConfig
  );
}

/**
 * 场景6: 翻译服务（多语言输出）
 */
export async function translateText(text: string, targetLanguage: string) {
  const translateConfig = {
    temperature: 0.1, // 低温度确保翻译准确性
    maxOutputTokens: 2048,
    responseMimeType: "application/json",
    responseSchema: {
      type: "object",
      properties: {
        originalText: {
          type: "string",
          description: "原文"
        },
        translatedText: {
          type: "string",
          description: "译文"
        },
        sourceLanguage: {
          type: "string",
          description: "原文语言"
        },
        targetLanguage: {
          type: "string", 
          description: "目标语言"
        },
        confidence: {
          type: "number",
          description: "翻译置信度"
        }
      },
      required: ["originalText", "translatedText", "targetLanguage"]
    }
  };

  const prompt = `请将以下文本翻译成${targetLanguage}：\n${text}`;
  
  return await callGeminiDirectly(
    GENERATIVE_AI_KEY, 
    AI_MODEL, 
    prompt, 
    translateConfig
  );
} 
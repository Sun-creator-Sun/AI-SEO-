/**
 * 搜索查询优化器
 * 智能处理关键词、长尾词、提问词等不同类型的输入
 */

export interface QueryType {
  type: 'keyword' | 'longtail' | 'question' | 'phrase';
  confidence: number;
  description: string;
}

export interface OptimizedQuery {
  original: string;
  optimized: string;
  type: QueryType;
  suggestions: string[];
}

/**
 * 分析查询类型
 */
export function analyzeQueryType(query: string): QueryType {
  const lowerQuery = query.toLowerCase().trim();
  
  // 提问词检测
  const questionWords = ['what', 'how', 'why', 'when', 'where', 'which', 'who', 'can', 'does', 'do', 'is', 'are', 'will', 'should', 'could', 'would'];
  const hasQuestionWord = questionWords.some(word => lowerQuery.startsWith(word));
  const hasQuestionMark = query.includes('?');
  
  if (hasQuestionWord || hasQuestionMark) {
    return {
      type: 'question',
      confidence: 0.9,
      description: '提问式查询，用户寻求解答或指导'
    };
  }
  
  // 长尾词检测
  const wordCount = lowerQuery.split(/\s+/).length;
  const hasModifiers = /(best|top|free|paid|cheap|expensive|review|guide|tutorial|comparison|vs|versus|alternative|alternative to)/i.test(lowerQuery);
  const hasYear = /\b(202[0-9]|202[0-9]s)\b/i.test(lowerQuery);
  const hasSpecificTerms = /(for|in|with|without|near|around|online|offline|software|tool|app|platform|service)/i.test(lowerQuery);
  
  if (wordCount >= 4 || hasModifiers || hasYear || hasSpecificTerms) {
    return {
      type: 'longtail',
      confidence: 0.8,
      description: '长尾关键词，包含修饰词或具体描述'
    };
  }
  
  // 短语检测
  if (wordCount >= 2 && wordCount <= 3) {
    return {
      type: 'phrase',
      confidence: 0.7,
      description: '短语查询，包含2-3个词的组合'
    };
  }
  
  // 默认关键词
  return {
    type: 'keyword',
    confidence: 0.6,
    description: '单关键词查询'
  };
}

/**
 * 优化搜索查询
 */
export function optimizeSearchQuery(query: string, targetLanguage: string = '英语'): OptimizedQuery {
  const original = query.trim();
  const queryType = analyzeQueryType(original);
  
  let optimized = original;
  const suggestions: string[] = [];
  
  // 根据查询类型进行优化
  switch (queryType.type) {
    case 'question':
      // 将提问词转换为陈述句
      optimized = convertQuestionToStatement(original);
      suggestions.push(
        `${original} (提问式)`,
        `${optimized} (优化后)`,
        `${original} review`,
        `${original} guide`
      );
      break;
      
    case 'longtail':
      // 长尾词通常已经很具体，可以添加相关变体
      optimized = original;
      suggestions.push(
        `${original} review`,
        `${original} comparison`,
        `best ${original}`,
        `${original} alternatives`
      );
      break;
      
    case 'phrase':
      // 短语查询，可以扩展为长尾词
      optimized = original;
      suggestions.push(
        `best ${original}`,
        `${original} tools`,
        `${original} software`,
        `${original} guide`
      );
      break;
      
    case 'keyword':
      // 关键词，扩展为相关短语
      optimized = original;
      suggestions.push(
        `best ${original} tools`,
        `${original} software`,
        `${original} guide`,
        `how to use ${original}`,
        `${original} review`
      );
      break;
  }
  
  // 根据目标语言调整
  if (targetLanguage === '中文') {
    // 中文查询的特殊处理
    if (queryType.type === 'keyword') {
      suggestions.push(`${original} 工具`, `${original} 软件`, `${original} 指南`);
    }
  }
  
  return {
    original,
    optimized,
    type: queryType,
    suggestions: suggestions.slice(0, 5) // 限制建议数量
  };
}

/**
 * 将提问句转换为陈述句
 */
function convertQuestionToStatement(question: string): string {
  const lowerQuestion = question.toLowerCase();
  
  // 移除问号
  let statement = question.replace(/\?/g, '').trim();
  
  // 处理常见的提问模式
  if (lowerQuestion.startsWith('what is ')) {
    statement = statement.replace(/^what is /i, '');
  } else if (lowerQuestion.startsWith('how to ')) {
    statement = statement.replace(/^how to /i, '');
  } else if (lowerQuestion.startsWith('why ')) {
    statement = statement.replace(/^why /i, '');
  } else if (lowerQuestion.startsWith('when ')) {
    statement = statement.replace(/^when /i, '');
  } else if (lowerQuestion.startsWith('where ')) {
    statement = statement.replace(/^where /i, '');
  } else if (lowerQuestion.startsWith('which ')) {
    statement = statement.replace(/^which /i, '');
  } else if (lowerQuestion.startsWith('who ')) {
    statement = statement.replace(/^who /i, '');
  } else if (lowerQuestion.startsWith('can ')) {
    statement = statement.replace(/^can /i, '');
  } else if (lowerQuestion.startsWith('does ')) {
    statement = statement.replace(/^does /i, '');
  } else if (lowerQuestion.startsWith('do ')) {
    statement = statement.replace(/^do /i, '');
  } else if (lowerQuestion.startsWith('is ')) {
    statement = statement.replace(/^is /i, '');
  } else if (lowerQuestion.startsWith('are ')) {
    statement = statement.replace(/^are /i, '');
  } else if (lowerQuestion.startsWith('will ')) {
    statement = statement.replace(/^will /i, '');
  } else if (lowerQuestion.startsWith('should ')) {
    statement = statement.replace(/^should /i, '');
  } else if (lowerQuestion.startsWith('could ')) {
    statement = statement.replace(/^could /i, '');
  } else if (lowerQuestion.startsWith('would ')) {
    statement = statement.replace(/^would /i, '');
  }
  
  return statement.trim();
}

/**
 * 生成相关搜索建议
 */
export function generateRelatedQueries(query: string, targetLanguage: string = '英语'): string[] {
  const queryType = analyzeQueryType(query);
  const suggestions: string[] = [];
  
  // 基础建议
  suggestions.push(
    `${query} review`,
    `${query} guide`,
    `${query} tutorial`,
    `best ${query}`,
    `${query} alternatives`
  );
  
  // 根据查询类型添加特定建议
  if (queryType.type === 'keyword') {
    suggestions.push(
      `${query} tools`,
      `${query} software`,
      `${query} platform`,
      `how to use ${query}`,
      `${query} vs competitors`
    );
  } else if (queryType.type === 'question') {
    const statement = convertQuestionToStatement(query);
    suggestions.push(
      `${statement} review`,
      `${statement} guide`,
      `best ${statement}`,
      `${statement} alternatives`
    );
  }
  
  // 根据语言调整
  if (targetLanguage === '中文') {
    suggestions.push(
      `${query} 中文`,
      `${query} 工具`,
      `${query} 软件`,
      `${query} 指南`
    );
  }
  
  return suggestions.slice(0, 8); // 限制建议数量
}

/**
 * 批量优化查询
 */
export function batchOptimizeQueries(queries: string[], targetLanguage: string = '英语'): OptimizedQuery[] {
  return queries.map(query => optimizeSearchQuery(query, targetLanguage));
} 
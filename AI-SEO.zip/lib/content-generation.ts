import { BlogOutline } from './google-search'
import { Evidence } from './article-generation'
import { PexelsPhoto } from '@/app/api/pexels/route'
import { generateWithFailover } from './ai-scheduler'
import { getYearPolicyPrompt } from './config'

/**
 * 文章生成步骤枚举
 */
export enum ArticleDraftStep {
  GENERATE_CONTENT = 1,      // 根据知识总结及生成要求逐段生成内容
  SEARCH_IMAGES = 2,         // 为文章搜索合适的配图
  INSERT_LINKS = 3,          // 查找并插入内部和外部链接以及锚文本
  GENERATE_META = 4          // 为文章页面生成元描述信息
}

/**
 * 内容生成参数接口
 */
export interface ContentGenerationParams {
  title: string
  keyword: string
  outline: BlogOutline
  evidence: Evidence[]
  targetLanguage: string
  targetMarket: string
  requirements: string | boolean
  evidenceBySection?: { [key: string]: Evidence[] } // 添加按章节整理的证据
}

/**
 * 内容生成状态更新回调函数类型
 */
export type ContentGenerationCallback = (step: ArticleDraftStep, message: string) => void

/**
 * 生成结构化的整篇文章 Prompt
 */
function unifiedArticleDraftPrompt({ selectedTitle, outline, requirements }: { selectedTitle: string, outline: BlogOutline, requirements?: string | boolean }): string {
  // 将 outline.sections 转为 Markdown 结构
  const outlineMd = outline.sections.map((section, idx) => {
    let md = `- **${section.heading}**`;
    if (section.subheadings && section.subheadings.length > 0) {
      md += '\n' + section.subheadings.map(sub => `    - ${sub}`).join('\n');
    }
    return md;
  }).join('\n');

  // 类型安全处理requirements，防止boolean类型传入
  let reqText: string = '正文部分请结合SEO和用户需求，内容要有深度和实用性。';
  if (typeof requirements === 'string') {
    if (requirements.trim().length > 0) {
      reqText = requirements;
    }
  } else if (typeof requirements === 'boolean') {
    reqText = requirements === true ? '正文部分请结合SEO和用户需求，内容要有深度和实用性。' : '';
  }

  return `你现在的任务是作为一名顶级的SEO内容作家，撰写一篇完整的、高质量的博客文章。你【必须】严格遵循以下四部分的结构来生成内容：

---

**Part 1: The Hook & Summary (开篇钩子与内容摘要)**

*   **开篇 (The Hook):**
    *   用【1-2个短句】作为开场白。必须直击痛点或引发好奇心，迅速抓住读者注意力。
    *   【严禁】使用冗长、客套的开场白（例如“在当今快速发展的数字世界中...”）。
*   **内容摘要 (The Summary / TL;DR):**
    *   紧接着开篇，立即创建一个名为“**本文你将了解到：**”或“**核心内容速览：**”的模块。
    *   在这个模块下，使用【无序列表 (Bulleted List)】格式，列出本文将要讨论的【3-5个核心要点】。
    *   每个要点都应简洁明了，让读者在5秒内了解文章的全部价值。

---

**Part 2: Main Body (文章正文)**

*   这是文章的主体部分。根据之前提供的大纲，详细地展开论述。
*   你必须严格按照以下大纲结构展开：

${outlineMd}

*   ${reqText}
*   **在正文部分，你必须智能地运用以下多样化的Markdown格式来提升可读性和视觉吸引力（强制要求）：**
    *   **使用粗体 (Bold):** 突出段落中的关键词和关键短语。
    *   **使用无序/有序列表 (Bulleted/Numbered Lists):** 当列举多个项目、步骤或特点时，必须使用列表格式，而不是将它们混在长段落里。
    *   **使用引用块 (Blockquotes):** 当引用专家观点、客户评价或强调某个核心理念时，使用 Markdown 的 `>` 语法来创建引用块，使其在视觉上突出。
    *   **创建 Markdown 表格 (Tables):** 【强制要求】每篇文章必须包含至少1-2个对比表格。当需要比较不同项目（例如：产品功能对比、优缺点分析、价格方案、特性对比等）时，必须创建一个简洁明了的 Markdown 表格来直观展示数据。表格应该包含3-6行数据，确保信息丰富且易于比较。
    *   **合理穿插多种格式**，避免长篇连续纯文本，确保每个章节都至少包含上述多种格式中的两种及以上。
    *   **所有格式均需用标准Markdown语法输出，确保前端可正确渲染。**

---

**Part 3: FAQ Section (常见问题解答)**

*   【强制要求】每篇文章必须在正文结束后、结论之前包含一个FAQ部分。
*   **FAQ要求：**
    *   标题：使用“## FAQ (Frequently Asked Questions)”或“## 常见问题解答”
    *   问题数量：必须包含5-8个相关问题
    *   问题类型：涵盖用户最关心的核心问题、操作疑问、常见误解等
    *   回答格式：每个问题用“**Q: [问题]**”格式，回答用“A: [详细回答]”格式
    *   内容质量：回答要详细、实用、解决用户实际问题
    *   关键词优化：自然融入主关键词和相关长尾词

---

**Part 4: Conclusion (文章结尾)**

*   用一个简洁有力的段落总结全文的核心观点。
*   提供一个明确的“行动号召 (Call to Action)”，引导读者进行下一步操作（例如“立即尝试”、“发表评论”或“阅读相关文章”）。

---

**重要提醒：**
1. 【强制要求】每篇文章必须包含至少1-2个对比表格，用于产品、功能、方案等对比
2. 【强制要求】每篇文章必须包含FAQ部分，回答用户最关心的问题
3. 表格和FAQ是提升文章可读性和SEO效果的关键元素，绝对不能省略
4. 请严格按照 [Part 1 -> Part 2 -> Part 3 -> Part 4] 的顺序和要求生成完整的Markdown文章。`;
}

// 写作要求补充
const linkWritingRequirement = `\n\n写作要求补充：\n- 在正文合适位置，直接插入引用文章的超链接，格式为：[引用标题](引用URL)。\n- 内部链接和外部链接也请以Markdown格式嵌入文案（如：[锚文本](链接地址)），确保前端渲染为可点击a标签。\n- 不要将所有引用集中在文末，要自然分布在相关内容段落中。\n`;

/**
 * Vertu高端内容营销“Top 10”清单文章AI提示词模板
 * 用于生成高端、权威、SEO友好的Top 10清单类内容
 */
export const vertuTop10Prompt = `
你是一名服务于奢侈科技品牌（Vertu）的内容营销专家。请为高净值人群撰写一篇“Top 10”清单式博客文章，主题为【在此处插入主题】。

请严格按照以下结构输出：

1. **引言**：用1-3个短段落，提出目标受众关心的痛点或场景，介绍本文主题作为解决方案，并预告将盘点10个顶级选择。
2. **清单主体**：包含10个项目，每个项目都必须有：
   - H2子标题（排名+名称）
   - 一张高质量配图（可用Markdown图片语法，或留空让编辑补图）
   - 一段简短介绍
   - 用项目符号列出3-5个核心功能或优点
   - 行动号召（如“了解更多”或“前往官网”）
3. **总结/购买指南**：简要总结，帮助用户做最终选择。
4. **品牌关联**：结尾用1-2句话将文章主题与Vertu手机的优势（如性能、安全、设计）自然关联，激发品牌认知或潜在购买。

写作风格要求：专业、权威、简洁、高端，语言有说服力，兼顾SEO友好。

文章标题格式为：“Top 10 [主题关键词] for [年份]: [卖点1], [卖点2] & [卖点3]”
${linkWritingRequirement}`;

/**
 * Vertu健康/科技/生活方式科普文章AI提示词模板
 * 用于生成高端、科学、易懂的知识型内容
 */
export const vertuKnowledgePrompt = `
你是一名服务于奢侈科技品牌 (Vertu) 的生活方式与健康领域内容专家。请撰写一篇深度解释型的知识科普文章。

主题: [在此处插入一个与健康/科技/生活方式相关的复杂概念，例如：神经可塑性 (Neuroplasticity)]
目标受众: 对自我提升和健康科学感兴趣的精英人士。

文章标题格式: "What Is [主题关键词] and Why Does It Matter?" 或 "What Happens During [主题过程]?"

文章结构要求：
1. **引言**：用一句话定义核心概念，并立即点出它对于个人发展或健康的重要性。
2. **正文主体**：必须使用多个清晰的H2子标题来拆解主题，逻辑层次如下：
   - 首先，提供必要的背景知识。
   - 然后，详细解释核心概念的特征。
   - 接着，阐述其背后的科学原理或重要性。
   - 最后，提供2-3条实用的建议或方法。
3. **结论与品牌关联**：总结文章核心价值，并自然地过渡到Vertu产品（如手表、手机的健康追踪功能）如何帮助用户更好地理解或应用这些知识。

写作风格：科学、严谨、易于理解、有启发性。
${linkWritingRequirement}`;

/**
 * 开始内容生成流程
 * @param params 生成参数
 * @param updateCallback 状态更新回调
 * @returns 生成的完整文章内容
 */
export async function startContentGeneration(
  params: ContentGenerationParams,
  updateCallback: ContentGenerationCallback
): Promise<string> {
  // 打印完整的params对象
  console.log('Content Generation Params:', JSON.stringify({
    title: params.title,
    keyword: params.keyword,
    outline: params.outline,
    evidence: params.evidence,
    targetLanguage: params.targetLanguage,
    targetMarket: params.targetMarket,
    requirements: params.requirements,
    evidenceBySection: params.evidenceBySection
  }, null, 2));

  // 保证requirements为string类型，防止boolean类型传入
  if (typeof params.requirements !== 'string') params.requirements = '';

  updateCallback(ArticleDraftStep.GENERATE_CONTENT, 'Generating article content in unified mode...');
  
  try {
    if (!params.outline) {
      throw new Error('Missing article outline');
    }

    // 优先整体生成模式 - 使用智能调度引擎
    const prompt = unifiedArticleDraftPrompt({
      selectedTitle: params.title,
      outline: params.outline,
      requirements: typeof params.requirements === 'string' ? params.requirements : ''
    });
    try {
      console.log('INFO: Starting unified article generation with AI scheduler...');
      const generatedContent = await generateWithFailover(prompt, { temperature: 0.7 });
      updateCallback(ArticleDraftStep.GENERATE_CONTENT, 'Unified article draft generated!');
      return generatedContent;
    } catch (e) {
      console.error('Unified article draft generation failed, fallback to section-by-section:', e);
      // fallback to old section-by-section
    }

    // 获取evidenceBySection
    const getEvidenceBySection = () => {
      const evidenceBySection: { [key: string]: Evidence[] } = {};
      
      // 1. 为每个章节和子章节创建空数组，使用其原始标题作为键
      params.outline.sections.forEach(section => {
        evidenceBySection[section.heading] = [];
        section.subheadings?.forEach(subheading => {
          evidenceBySection[subheading] = [];
        });
      });
      
      // 2. 分配证据
      params.evidence.forEach(evidence => {
        let assigned = false;

        // 优先尝试通过索引分配
        if (evidence.sectionInfo && evidence.sectionInfo.h2Index !== undefined && evidence.sectionInfo.h2Index !== null) {
          const h2Idx = evidence.sectionInfo.h2Index;

          if (h2Idx >= 0 && h2Idx < params.outline.sections.length) {
            const targetH2Section = params.outline.sections[h2Idx];
            const h3Idx = evidence.sectionInfo.h3Index;

            // 健全性检查：比较evidence中的标题和outline中通过index找到的标题
            if (evidence.sectionInfo.h2Title && evidence.sectionInfo.h2Title.toLowerCase() !== targetH2Section.heading.toLowerCase()) {
              console.warn(`(content-generation) 证据h2Title ("${evidence.sectionInfo.h2Title}") 与 outline的h2Title ("${targetH2Section.heading}") (h2Index: ${h2Idx}) 不完全一致. 仍将通过索引分配.`);
            }

            if (h3Idx !== undefined && h3Idx !== null && targetH2Section.subheadings) {
              if (h3Idx >= 0 && h3Idx < targetH2Section.subheadings.length) {
                const targetH3SubheadingKey = targetH2Section.subheadings[h3Idx];
                if (evidence.sectionInfo.h3Title && evidence.sectionInfo.h3Title.toLowerCase() !== targetH3SubheadingKey.toLowerCase()) {
                    console.warn(`(content-generation) 证据h3Title ("${evidence.sectionInfo.h3Title}") 与 outline的h3Subheading ("${targetH3SubheadingKey}") (h2Index: ${h2Idx}, h3Index: ${h3Idx}) 不完全一致. 仍将通过索引分配.`);
                }
                evidenceBySection[targetH3SubheadingKey].push(evidence);
                console.log(`📝 证据通过索引 (h2:${h2Idx}, h3:${h3Idx}) 分配到H3章节: ${targetH3SubheadingKey}`);
                assigned = true;
              } else {
                console.warn(`⚠️ 证据的 h3Index ${h3Idx} 无效 (H2: ${targetH2Section.heading}, h2Index: ${h2Idx}). 将尝试分配到其父H2章节.`);
              }
            } 
            
            if (!assigned) { // 如果未分配给H3 (因无h3Index, h3Index无效, 或H2无子章节)
              evidenceBySection[targetH2Section.heading].push(evidence);
              console.log(`📝 证据通过索引 (h2:${h2Idx}) 分配到H2章节: ${targetH2Section.heading}`);
              assigned = true;
            }
          } else {
            console.warn(`⚠️ 证据的 h2Index ${h2Idx} 超出范围 (总章节数: ${params.outline.sections.length}). 内容: "${evidence.content.substring(0,50)}..."`);
          }
        }

        // 如果通过索引未能分配，则尝试通过校正后的标题进行大小写不敏感匹配 (第一层回退)
        if (!assigned && evidence.sectionInfo && evidence.sectionInfo.h2Title) { 
          console.log(`📝 证据 (content: "${evidence.content.substring(0,50)}...") 未通过索引分配, 尝试通过校正后标题匹配...`);
          const evidenceH2Lower = evidence.sectionInfo.h2Title.toLowerCase();
          const evidenceH3Lower = evidence.sectionInfo.h3Title?.toLowerCase();
          let assignedByTitle = false;

          for (const section of params.outline.sections) { 
            if (section.heading.toLowerCase() === evidenceH2Lower) {
              let assignedToH3ByTitle = false;
              if (evidenceH3Lower && section.subheadings) {
                for (const subheadingKey of section.subheadings) {
                  if (subheadingKey.toLowerCase() === evidenceH3Lower) {
                    evidenceBySection[subheadingKey].push(evidence);
                    console.log(`📝 (回退-标题) 证据分配到H3章节: ${subheadingKey}`);
                    assignedToH3ByTitle = true;
                    assignedByTitle = true;
                    break; 
                  }
                }
              }
              if (!assignedToH3ByTitle) { 
                evidenceBySection[section.heading].push(evidence);
                console.log(`📝 (回退-标题) 证据分配到H2章节: ${section.heading}`);
                assignedByTitle = true;
              }
              break; 
            }
          }
          if (assignedByTitle) assigned = true;
          else console.log(`📝 (回退-标题) 证据通过校正后标题匹配失败.`);
        }

        // 如果通过索引和校正后标题均未能分配，则尝试内容匹配 (第二层回退)
        if (!assigned) {
          console.log(`📝 证据 (content: "${evidence.content.substring(0,50)}...") 未通过索引或标题分配, 尝试内容匹配...`);
          let matchedByContent = false;
          // 先尝试匹配子标题（H3）
          for (const section of params.outline.sections) {
            if (matchedByContent) break;
            if (section.subheadings) {
              for (const subheadingKey of section.subheadings) {
                const subheadingKeywords = subheadingKey.toLowerCase();
                const evidenceContentLower = evidence.content.toLowerCase();
                
                if (evidenceContentLower.includes(subheadingKeywords.split(' ')[0]) || 
                    subheadingKeywords.split(' ').some(word => word.length > 3 && evidenceContentLower.includes(word))) {
                  evidenceBySection[subheadingKey].push(evidence);
                  matchedByContent = true;
                  console.log(`📝 (回退-内容) 证据通过内容匹配到H3章节: ${subheadingKey}`);
                  break;
                }
              }
            }
          }
          
          // 如果没有匹配到子标题，再匹配主标题（H2）
          if (!matchedByContent) {
            for (const section of params.outline.sections) {
              if (matchedByContent) break;
              const sectionKeywords = (section.heading.toLowerCase() + ' ' + section.keyPoints.join(' ').toLowerCase());
              const evidenceContentLower = evidence.content.toLowerCase();
              
              if (sectionKeywords.includes(evidence.type.replace(/_/g, ' ').toLowerCase()) || // 匹配证据类型
                  (evidenceContentLower.length > 50 && sectionKeywords.split(' ').some(word => word.length > 3 && evidenceContentLower.includes(word))) // 或内容相关
                  ) { 
                evidenceBySection[section.heading].push(evidence);
                matchedByContent = true;
                console.log(`📝 (回退-内容) 证据通过内容匹配到H2章节: ${section.heading}`);
                break;
              }
            }
          }
          
          if (matchedByContent) assigned = true;
          else console.log(`📝 (回退-内容) 证据通过内容匹配失败.`);
        }
        
        // 如果所有方法都失败，分配给第一个章节 (最终回退)
        if (!assigned && params.outline.sections.length > 0) {
          const firstSectionHeading = params.outline.sections[0].heading;
          evidenceBySection[firstSectionHeading].push(evidence);
          console.log(`📝 (最终回退) 未匹配证据分配到第一个章节: ${firstSectionHeading}`);
        }
      });
      
      // 打印证据分配统计
      Object.entries(evidenceBySection).forEach(([section, evidence]) => {
        console.log(`📊 章节 "${section}" 分配到 ${evidence.length} 条证据`);
      });
      
      return evidenceBySection;
    };
    
    // 分段生成文章内容
    let generatedContent = await generateArticleSections({
      ...params,
      evidenceBySection: getEvidenceBySection()
    }, updateCallback);
    
    // 步骤2：搜索配图并嵌入
    updateCallback(ArticleDraftStep.SEARCH_IMAGES, 'Searching for relevant images for the article...');
    generatedContent = await searchAndEmbedImage(generatedContent, params);
    updateCallback(ArticleDraftStep.SEARCH_IMAGES, 'Image embedded successfully (if found).');
    
    // 步骤3：插入链接和SEO优化
    updateCallback(ArticleDraftStep.INSERT_LINKS, 'Optimizing SEO and inserting links...');
    const optimizedContent = await optimizeContentForSEO(generatedContent, params);
    
    // 步骤4：生成元描述
    updateCallback(ArticleDraftStep.GENERATE_META, 'Generating meta description and final optimization...');
    const finalContent = await generateMetaAndFinalize(optimizedContent, params);
    
    // 完成
    updateCallback(ArticleDraftStep.GENERATE_META, 'Article generation completed!');
    return finalContent;
    
  } catch (error) {
    console.error('Article content generation failed:', error);
    const errorMessage = `Content generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
    updateCallback(ArticleDraftStep.GENERATE_CONTENT, errorMessage);
    
    // 出错时使用备用内容
    const fallbackContent = `# ${params.title}

## Introduction

In today's digital era, ${params.keyword} is becoming a focal point for businesses and individuals alike. This article will explore relevant strategies and best practices in depth.

## Content Overview

Due to network connectivity or API limitations, we are temporarily unable to generate complete article content. Please try again later, or contact technical support for assistance.

## Recommendations

1. Check network connectivity
2. Refresh the page and try again
3. Contact technical support

*This document will be automatically updated when the connection is restored.*`;
    
    return fallbackContent;
  }
}

/**
 * 搜索并嵌入图片到文章内容中
 * @param content 当前文章内容
 * @param params 生成参数
 * @returns 包含嵌入图片的文章内容
 */
async function searchAndEmbedImage(
  content: string,
  params: ContentGenerationParams
): Promise<string> {
  try {
    const searchQuery = params.title || params.keyword; // 使用标题或关键词搜索
    if (!searchQuery) {
      console.warn('No search query for Pexels API call.');
      return content; // 没有搜索词则不处理
    }

    const pexelsResponse = await fetch('/api/pexels', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: searchQuery, per_page: 1 }) // 请求一张图片
    });

    if (!pexelsResponse.ok) {
      const errorData = await pexelsResponse.json();
      console.error('Pexels API error:', errorData.error || pexelsResponse.statusText);
      return content; // API出错则返回原内容
    }

    const pexelsData = await pexelsResponse.json();

    if (pexelsData.success && pexelsData.data && pexelsData.data.photos && pexelsData.data.photos.length > 0) {
      const image: PexelsPhoto = pexelsData.data.photos[0];
      const imageUrl = image.src.large2x || image.src.original; // 优先使用大尺寸图片
      const imageAlt = image.alt || params.title; // 图片alt文本
      
      const imageMarkdown = `
![${imageAlt}](${imageUrl})

`;
      
      // 将图片插入到主标题下方
      const titleMarkdown = `# ${params.title}

`;
      if (content.startsWith(titleMarkdown)) {
        return content.replace(titleMarkdown, `${titleMarkdown}${imageMarkdown}`);
      } else {
        // 如果没有严格匹配到主标题，则添加到内容最前面（兼容性处理）
        return `${imageMarkdown}${content}`;
      }
    } else {
      console.warn('No images found from Pexels for query:', searchQuery);
      return content; // 未找到图片则返回原内容
    }
  } catch (error) {
    console.error('Failed to search or embed image:', error);
    return content; // 发生错误则返回原内容
  }
}

/**
 * 分段生成文章内容
 * @param params 生成参数
 * @param updateCallback 状态更新回调
 * @returns 生成的完整文章内容
 */
async function generateArticleSections(
  params: ContentGenerationParams,
  updateCallback: ContentGenerationCallback
): Promise<string> {
  const { title, keyword, outline, evidenceBySection, targetLanguage, requirements } = params;
  
  let fullContent = `# ${title}\n\n`;
  
  // 生成引言
  updateCallback(ArticleDraftStep.GENERATE_CONTENT, 'Generating article introduction...');
  const introduction = await generateIntroduction(title, keyword, outline, targetLanguage);
  fullContent += `${introduction}\n\n`;
  
  // 按章节生成内容
  for (let i = 0; i < outline.sections.length; i++) {
    const section = outline.sections[i];
    updateCallback(ArticleDraftStep.GENERATE_CONTENT, `Generating section ${i + 1}: ${section.heading}...`);
    
    // 获取该章节的证据
    const mainEvidence = evidenceBySection?.[section.heading] || [];
    const subSectionEvidence: { [key: string]: Evidence[] } = {};
    
    // 获取子章节的证据
    if (section.subheadings?.length > 0) {
      section.subheadings.forEach(subheading => {
        subSectionEvidence[subheading] = evidenceBySection?.[subheading] || [];
      });
    }

    console.log(`📊 章节 "${section.heading}" 证据统计:`, {
      main: mainEvidence.length,
      subSections: Object.entries(subSectionEvidence).map(([name, evidence]) => 
        `${name}: ${evidence.length}`
      )
    });
    
    const sectionContent = await generateSectionContent(
      {
        ...section,
        mainEvidence,
        subSectionEvidence
      }, 
      keyword, 
      mainEvidence,
      targetLanguage, 
      requirements
    );
    
    fullContent += `${sectionContent}\n\n`;
    
    // 等待一下避免API调用过快
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  // 生成结论
  updateCallback(ArticleDraftStep.GENERATE_CONTENT, 'Generating article conclusion...');
  const conclusion = await generateConclusion(title, keyword, outline, targetLanguage);
  fullContent += `${conclusion}\n\n`;
  
  return fullContent;
}

/**
 * 生成文章引言
 * @param title 文章标题
 * @param keyword 关键词
 * @param outline 文章大纲
 * @param language 目标语言
 * @returns 生成的引言内容
 */
async function generateIntroduction(
  title: string, 
  keyword: string, 
  outline: BlogOutline, 
  language: string
): Promise<string> {
  const prompt = `Please generate an engaging introduction paragraph for the following article:

Title: ${title}
Keyword: ${keyword}
Target Language: ${language}
Outline Overview: ${outline.introduction}

**强制要求：**
1. **文章的开头必须且只能有一个 H1 标题，这个 H1 标题就是用户最终选择的 SEO 优化标题**
2. 引言部分应该直接跟随在 H1 标题之后
3. 开始时要有一个吸引注意力的开头
4. 自然地融入主关键词"${keyword}"
5. 预览文章将要讨论的主要主题
6. 保持长度在150-200个单词之间
7. 保持专业但易于理解的语调
8. 使用第二人称（you/your）来吸引读者
9. 用英文撰写内容

**文章结构要求：**
请严格按照以下 Markdown 结构生成文章：

# [此处填入文章的 H1 标题]

[引人入胜的引言部分]

请只返回引言内容，不要包含任何额外的解释。`;

  try {
    console.log(`INFO: Generating introduction using AI scheduler...`);
    const generatedContent = await generateWithFailover(prompt, { temperature: 0.7 });
    return generatedContent;
  } catch (error) {
    console.error('Failed to generate introduction:', error);
    return `In today's rapidly evolving digital landscape, ${keyword} has become an indispensable topic that no professional can afford to ignore. Whether you're a beginner or an experienced practitioner, understanding the nuances of ${keyword} will provide you with invaluable insights and actionable strategies. This comprehensive guide will explore all aspects of ${keyword}, offering you practical knowledge and proven approaches to achieve success.`;
  }
}

/**
 * 生成章节内容
 * @param section 章节信息
 * @param keyword 关键词
 * @param evidence 相关证据
 * @param language 目标语言
 * @param requirements 特殊要求
 * @returns 生成的章节内容
 */
async function generateSectionContent(
  section: any, 
  keyword: string, 
  evidence: any[], 
  language: string, 
  requirements: string | boolean
): Promise<string> {
  // 检查证据数据
  const mainEvidence = section.mainEvidence || [];
  const subSectionEvidence = section.subSectionEvidence || {};

  // 记录证据统计
  console.log(`📊 章节 "${section.heading}" 证据统计:`, {
    h2: mainEvidence.length,
    h3: section.subheadings?.reduce((total: number, subheading: string) => 
      total + (subSectionEvidence[subheading]?.length || 0), 0) || 0
  });

  // 构建主章节证据文本
  const mainEvidenceText = mainEvidence.map((ev: Evidence) => {
    const evidenceStr = `- ${ev.content}`;
    console.log(`📝 H2证据 (${section.heading}): ${evidenceStr.substring(0, 100)}...`);
    return evidenceStr;
  }).join('\n');

  // 构建子章节证据文本
  let subSectionEvidenceText = '';
  if (section.subheadings?.length > 0) {
    subSectionEvidenceText = section.subheadings.map((subheading: string) => {
      const subEvidence = subSectionEvidence[subheading] || [];
      if (!subEvidence?.length) return '';

      const evidenceText = subEvidence.map((ev: Evidence) => {
        const evidenceStr = `- ${ev.content}`;
        console.log(`📝 H3证据 (${subheading}): ${evidenceStr.substring(0, 100)}...`);
        return evidenceStr;
      }).join('\n');

      return evidenceText ? `### ${subheading}\n${evidenceText}` : '';
    }).filter(Boolean).join('\n\n');
  }

  // 合并所有证据文本
  const evidenceText = [mainEvidenceText, subSectionEvidenceText].filter(Boolean).join('\n\n');

  const prompt = `Please generate detailed content for the following section:

## Section Title: ${section.heading}

Subheadings: ${section.subheadings?.join(', ') || 'None'}
Key Points: ${section.keyPoints?.join('; ') || 'None'}
Target Word Count: ${section.estimatedWords || 300} words
Main Keyword: ${keyword}
Target Language: ${language}

Related Evidence and Data:
${evidenceText || 'No specific evidence available.'}

${requirements ? `Special Requirements: ${requirements}` : ''}

**强制要求：**
1. 包含章节标题作为 H2 标题
2. 如果有子标题，使用它们作为 H3 标题
3. 自然地整合提供的证据和数据
4. 确保内容的逻辑清晰和层次结构
5. 使用适当的列表、粗体格式等
6. 保持专业但易于理解的语调
7. 用证据支持每个观点
8. 使用 markdown 格式
9. 用英文撰写内容

**规范文章结构：**
请严格按照以下 Markdown 结构模板生成内容：

## [H2级别章节标题]
[段落内容]

### [H3子标题1]
[段落内容]

### [H3子标题2]
[段落内容]

### [H3子标题3]
[段落内容]

请生成完整的章节内容：`;

  try {
    console.log(`INFO: Generating section content using AI scheduler...`);
    const generatedContent = await generateWithFailover(prompt, { temperature: 0.6 });
    return generatedContent;
  } catch (error) {
    console.error('Failed to generate section content:', error);
    return `## ${section.heading}\n\n${section.keyPoints?.map((point: string) => `- ${point}`).join('\n')}\n\n${mainEvidence.length > 0 ? `Research indicates that ${mainEvidence[0].content}` : ''}`;
  }
}

/**
 * 生成文章结论
 * @param title 文章标题
 * @param keyword 关键词
 * @param outline 文章大纲
 * @param language 目标语言
 * @returns 生成的结论内容
 */
async function generateConclusion(
  title: string, 
  keyword: string, 
  outline: BlogOutline, 
  language: string
): Promise<string> {
  const prompt = `Please generate a powerful conclusion paragraph for the following article:

Article Title: ${title}
Keyword: ${keyword}
Target Language: ${language}
Conclusion Key Points: ${outline.conclusion}

Requirements:
1. Summarize the main points of the article
2. Re-emphasize the importance of ${keyword}
3. Provide actionable recommendations
4. Include a clear CTA (Call to Action)
5. Keep the length between 200-250 words
6. Use a positive and encouraging tone
7. Use markdown format
8. Write the content in English

Please generate the conclusion content:`;

  try {
    console.log(`INFO: Generating conclusion using AI scheduler...`);
    const generatedContent = await generateWithFailover(prompt, { temperature: 0.7 });
    return generatedContent;
  } catch (error) {
    console.error('Failed to generate conclusion:', error);
    return `## Conclusion\n\nThrough this comprehensive exploration, we have gained valuable insights into all aspects of ${keyword}. Mastering this knowledge will help you achieve better results in your related endeavors. Start implementing these strategies today, and you can be confident in achieving your desired outcomes.`;
  }
}

/**
 * SEO内容优化
 * @param content 原始内容
 * @param params 生成参数
 * @returns 优化后的内容
 */
async function optimizeContentForSEO(
  content: string, 
  params: ContentGenerationParams
): Promise<string> {
  const { keyword, targetLanguage } = params;
  
  const prompt = `Please optimize the following article content for SEO and readability:

Original Content:
${content}

Main Keyword: ${keyword}
Target Language: ${targetLanguage}

Optimization Requirements:
1. Check keyword distribution and ensure natural integration
2. Optimize paragraph length to avoid overly long paragraphs
3. Add appropriate bold formatting and emphasis
4. Ensure smooth logical connections
5. Optimize subheading expressions
6. Maintain the original markdown format
7. Ensure content professionalism and authority
8. Write the optimized content in English

Please return the complete optimized content:`;

  try {
    console.log(`INFO: Optimizing content using AI scheduler...`);
    const optimizedContent = await generateWithFailover(prompt, { temperature: 0.4 });
    return optimizedContent;
  } catch (error) {
    console.error('SEO optimization failed:', error);
    return content; // 返回原始内容
  }
}

/**
 * 生成元描述并最终优化
 * @param content 优化后的内容
 * @param params 生成参数
 * @returns 最终优化的完整文章
 */
async function generateMetaAndFinalize(
  content: string, 
  params: ContentGenerationParams
): Promise<string> {
  const { title, keyword, targetLanguage } = params;
  
  // 为内容添加最终的SEO元素
  const prompt = `Optimize the following article for SEO by adding a relevant FAQ section (3-5 questions) and a clear Call to Action (CTA) paragraph. Ensure overall content completeness and coherence.

**强制要求：**
1. **文章的开头必须且只能有一个 H1 标题，这个 H1 标题就是用户最终选择的 SEO 优化标题**
2. **规范文章结构：** 请严格按照以下 Markdown 结构模板生成文章：

# [此处填入文章的 H1 标题]

[引人入胜的引言部分]

## [第一个 H2 副标题]
[段落内容]

## [第二个 H2 副标题]
[段落内容]
...

## FAQ (常见问题解答)
**Q1: [问题1]**
A1: [回答1]
**Q2: [问题2]**
A2: [回答2]

## Conclusion (结论)
[总结全文，并给出最后的号召性用语]

**重要结构要求：**
- 通过这个结构，确保 Conclusion 部分始终位于 FAQ 之后
- FAQ 部分必须包含 3-5 个相关问题
- 结论部分必须总结全文并给出明确的号召性用语
- 所有内容必须用英文撰写

**Crucially, your entire response must consist *only* of the complete, SEO-optimized article body in markdown format, with no additional commentary, conversational text, or introductory/concluding remarks.**

---
**Article Details:**
Article Title: ${title}
Main Keyword: ${keyword}
Target Language: ${targetLanguage}

**Current Article Content:**
${content}`;

  try {
    const response = await fetch('/api/gemini-generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        prompt,
        generationConfig: {
          temperature: 0.5
        }
      })
    });

    const result = await response.json();
    if (result.success) {
      return result.data.trim();
    } else {
      throw new Error(result.error || 'Final optimization failed');
    }
  } catch (error) {
    console.error('Final optimization failed:', error);
    return content; // 返回之前的内容
  }
} 
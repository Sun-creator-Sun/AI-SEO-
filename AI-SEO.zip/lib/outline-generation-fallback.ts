import { BlogOutline, ArticleAnalysis } from './types';

/**
 * 生成备用文章分析结果
 * @param content - 文章内容
 * @param index - 索引
 * @returns 备用分析结果
 */
export function generateFallbackAnalysis(content: string, index: number): ArticleAnalysis {
  // 从内容中提取URL
  const urlMatch = content.match(/文章URL:\s*(https?:\/\/[^\s\n]+)/);
  const url = urlMatch ? urlMatch[1] : `文章${index + 1}`;
  
  // 从内容中提取标题
  const titleMatch = content.match(/# (.+)/);
  const title = titleMatch ? titleMatch[1] : `分析文章${index + 1}`;
  
  // 简单分析内容结构
  const hasNumberedSections = content.includes('### 1.') || content.includes('## 1.');
  const hasSteps = content.includes('步骤') || content.includes('Step');
  const hasComparison = content.includes('vs') || content.includes('对比');
  const hasGuide = content.includes('指南') || content.includes('Guide');
  
  let style = '信息型';
  let structure = '标准式';
  
  if (hasGuide) {
    style = '指导型';
    structure = '教程式';
  } else if (hasSteps) {
    style = '教程型';
    structure = '步骤式';
  } else if (hasComparison) {
    style = '分析型';
    structure = '对比式';
  } else if (hasNumberedSections) {
    style = '列表型';
    structure = '列表式';
  }
  
  return {
    url,
    title,
    outline: ['概述', '详细分析', '实践案例', '最佳实践', '结论'],
    style,
    tone: '专业',
    structure,
    keyPoints: ['核心概念介绍', '实施方法说明', '案例分析展示']
  };
}

/**
 * 生成备用综合分析报告
 * @param articleAnalyses - 文章分析结果
 * @returns 备用分析报告
 */
export function generateFallbackSynthesis(articleAnalyses: ArticleAnalysis[]): string {
  const totalArticles = articleAnalyses.length;
  
  // 统计风格分布
  const styleCount: Record<string, number> = {};
  const toneCount: Record<string, number> = {};
  const structureCount: Record<string, number> = {};
  
  articleAnalyses.forEach(analysis => {
    styleCount[analysis.style] = (styleCount[analysis.style] || 0) + 1;
    toneCount[analysis.tone] = (toneCount[analysis.tone] || 0) + 1;
    structureCount[analysis.structure] = (structureCount[analysis.structure] || 0) + 1;
  });
  
  const mostCommonStyle = Object.keys(styleCount).reduce((a, b) => styleCount[a] > styleCount[b] ? a : b);
  const mostCommonTone = Object.keys(toneCount).reduce((a, b) => toneCount[a] > toneCount[b] ? a : b);
  const mostCommonStructure = Object.keys(structureCount).reduce((a, b) => structureCount[a] > structureCount[b] ? a : b);
  
  return `
## 综合分析报告

### 1. 内容结构模式分析
基于${totalArticles}篇文章的分析，发现以下结构模式：
- 最常见的结构类型：${mostCommonStructure}
- 大多数文章采用3-5个主要章节的结构
- 普遍包含概述、详细分析和结论部分
- 章节标题多采用问题式或指导式表达

### 2. 写作风格趋势分析
- 主流写作风格：${mostCommonStyle}
- 内容偏向实用性和可操作性
- 注重提供具体的方法和建议
- 多采用清晰的段落结构和逻辑层次

### 3. 语气调性分析
- 主要语气调性：${mostCommonTone}
- 平衡专业性和可读性
- 适合目标受众的知识水平
- 注重与读者的情感连接和互动

### 4. 词汇分布与用词特点分析
基于文章内容的词汇分析发现：
- **高频词汇特征**：多使用行动导向词汇（如"实施"、"优化"、"分析"）
- **专业词汇比例**：专业术语与通用词汇比例约为3:7，保持良好的可读性
- **词汇复杂度**：中等复杂度，适合大多数目标受众
- **用词偏好**：
  - 动词使用：偏好具体行动词（implement, optimize, analyze）
  - 形容词使用：多用描述效果的词汇（effective, efficient, comprehensive）
  - 连接词：常用逻辑性连接词（however, therefore, furthermore）
- **目标受众适应性**：词汇选择符合中高级读者水平

### 5. 关键要点模式分析
- 文章普遍关注实际应用和最佳实践
- 重视案例分析和具体示例
- 强调可操作的建议和指导
- 主题词分布集中在核心概念和实施方法

### 6. 语言表达模式分析
- **常用表达句式**：多用祈使句和陈述句，简洁明了
- **修辞手法**：适度使用比喻和类比，增强理解
- **问题解答模式**：先提出问题，再给出解决方案
- **引导行动技巧**：使用具体的行动指令和步骤说明

### 7. SEO和关键词优化模式
- 关键词自然分布，密度控制在2-3%
- 标题和子标题中合理融入相关关键词
- 长尾关键词使用恰当，提升搜索覆盖

### 8. 综合优化建议
基于以上分析，建议：
- **词汇选择**：维持中等复杂度，专业术语需配备解释
- **语言表达**：保持${mostCommonTone}的语气，注重实用性
- **结构组织**：采用${mostCommonStructure}结构，确保逻辑清晰
- **SEO优化**：自然融入关键词，避免过度优化
- **内容价值**：强调实际应用和可操作性

### 9. 推荐写作模板
基于分析结果，推荐以下写作模板：
1. **引言**：问题提出 + 价值承诺 + 文章预览
2. **核心概念**：定义阐述 + 重要性说明 + 应用场景
3. **详细方法**：步骤说明 + 实例演示 + 注意事项
4. **实践案例**：案例背景 + 实施过程 + 效果分析
5. **最佳实践**：经验总结 + 常见误区 + 优化建议
6. **总结展望**：要点回顾 + 行动指南 + 未来趋势
`;
}

/**
 * 生成默认章节
 * @param keyword - 关键词
 * @param title - 标题
 * @returns 默认章节数组
 */
export function generateDefaultSections(keyword: string, title: string) {
  const titleLower = title.toLowerCase();
  
  if (titleLower.includes('guide') || titleLower.includes('how')) {
    return [
      {
        heading: `What is ${keyword}?`,
        subheadings: [`Understanding ${keyword}`, 'Key Benefits and Features'],
        keyPoints: [`Clear definition of ${keyword}`, 'Main advantages and use cases', 'Why it matters in today\'s market'],
        estimatedWords: 300
      },
      {
        heading: `How to Get Started with ${keyword}`,
        subheadings: ['Prerequisites and Requirements', 'Step-by-Step Setup Process'],
        keyPoints: ['Essential requirements', 'Detailed setup instructions', 'Common setup challenges'],
        estimatedWords: 400
      },
      {
        heading: `Best Practices for ${keyword}`,
        subheadings: ['Industry Standards', 'Expert Recommendations'],
        keyPoints: ['Proven strategies', 'Common mistakes to avoid', 'Optimization tips'],
        estimatedWords: 350
      },
      {
        heading: `Advanced ${keyword} Techniques`,
        subheadings: ['Professional Tips', 'Advanced Strategies'],
        keyPoints: ['Advanced implementation methods', 'Professional insights', 'Future considerations'],
        estimatedWords: 300
      }
    ];
  } else if (titleLower.includes('top') || titleLower.includes('best')) {
    return [
      {
        heading: `Why ${keyword} Matters in 2025`,
        subheadings: ['Current Market Trends', 'Future Outlook'],
        keyPoints: ['Market importance', 'Growth trends', 'Future predictions'],
        estimatedWords: 250
      },
      {
        heading: `Top ${keyword} Options`,
        subheadings: ['Premium Solutions', 'Budget-Friendly Alternatives'],
        keyPoints: ['Detailed comparisons', 'Pros and cons', 'Pricing analysis'],
        estimatedWords: 500
      },
      {
        heading: `How to Choose the Right ${keyword}`,
        subheadings: ['Selection Criteria', 'Decision Framework'],
        keyPoints: ['Key factors to consider', 'Evaluation process', 'Decision guidelines'],
        estimatedWords: 300
      }
    ];
  } else {
    return [
      {
        heading: `Understanding ${keyword}`,
        subheadings: [`${keyword} Fundamentals`, 'Key Concepts'],
        keyPoints: [`Core concepts of ${keyword}`, 'Important terminology', 'Basic principles'],
        estimatedWords: 300
      },
      {
        heading: `${keyword} Implementation`,
        subheadings: ['Getting Started', 'Best Practices'],
        keyPoints: ['Implementation steps', 'Best practices', 'Common challenges'],
        estimatedWords: 400
      },
      {
        heading: `${keyword} Benefits and Results`,
        subheadings: ['Expected Outcomes', 'Success Metrics'],
        keyPoints: ['Key benefits', 'Measurable results', 'Success indicators'],
        estimatedWords: 300
      }
    ];
  }
}

/**
 * 生成备用博客大纲
 * @param keyword - 关键词
 * @param title - 标题
 * @param wordCount - 字数
 * @param readabilityLevel - 可读性
 * @param toneStyle - 语气
 * @param perspective - 视角
 * @returns 备用大纲
 */
export function generateFallbackOutline(
  keyword: string,
  title: string,
  wordCount: string,
  readabilityLevel: string,
  toneStyle: string,
  perspective: string
): BlogOutline {
  console.log('使用备用大纲生成方法');
  
  return {
    title,
    introduction: `This comprehensive guide explores ${keyword} and provides practical insights for implementation. Whether you're a beginner or looking to enhance your existing knowledge, this article will help you understand the key concepts and best practices.`,
    sections: generateDefaultSections(keyword, title),
    conclusion: `${keyword} continues to play a crucial role in modern digital strategies. By following the guidelines and best practices outlined in this article, you should be well-equipped to implement and optimize your approach effectively.`,
    wordCount,
    readabilityLevel,
    toneStyle,
    perspective,
    seoKeywords: [keyword, `${keyword} guide`, `${keyword} tips`, `${keyword} best practices`]
  };
}

/**
 * 备用文章分析方法
 * @param extractedContents - 抓取的文章内容数组
 * @param selectedTitle - 选定的博客标题，用于相关性过滤（备用方法暂不实现过滤）
 * @returns 文章分析结果数组
 */
export async function fallbackAnalyzeArticleOutlines(extractedContents: string[], selectedTitle?: string): Promise<ArticleAnalysis[]> {
  console.log('使用备用文章分析方法');
  if (selectedTitle) {
    console.log('备用分析方法暂不支持相关性过滤，将分析所有文章');
  }
  
  return extractedContents.map((content, index) => generateFallbackAnalysis(content, index));
} 
import { SearchResult } from './types';
import { genAI, AI_MODEL } from './config';
import { searchKeyword } from './search-api';
import { 
  calculateSimpleRelevanceScore,
  extractQueriesFromText,
  extractBlogContentFromText,
  extractBatchScoresFromText,
  quickFilterBlogContent,
  fallbackSearch,
  removeDuplicateResults
} from './content-analysis-fallback';

/**
 * 搜索与博客主题相关的内容
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @param timeRange - 时间范围
 * @returns 相关搜索结果
 */
export async function searchRelatedContent(
  keyword: string,
  blogIdea: string,
  targetMarket: string = '美国',
  targetLanguage: string = '英语',
  timeRange: string = '任何时候'
): Promise<SearchResult[]> {
  try {
    console.log('开始搜索相关内容，关键词:', keyword, '博客创意:', blogIdea);
    
    // 使用Gemini AI分析博客创意并生成搜索查询
    const searchQueries = await generateSmartSearchQueries(keyword, blogIdea, targetMarket, targetLanguage);
    console.log('AI生成的搜索查询:', searchQueries);
    
    if (searchQueries.length === 0) {
      console.warn('AI未能生成搜索查询，使用备用方法');
      return await fallbackSearch(keyword, blogIdea, targetMarket, targetLanguage, timeRange, searchKeyword);
    }
    
    const allResults: SearchResult[] = [];
    let globalIndexCounter = 1; // 全局索引计数器，确保唯一性
    
    // 执行AI生成的搜索查询
    for (let i = 0; i < Math.min(searchQueries.length, 3); i++) {
      const query = searchQueries[i];
      console.log(`执行第${i + 1}个AI搜索查询:`, query);
      
      try {
        const results = await searchKeyword(query, targetMarket, targetLanguage, timeRange);
        console.log(`第${i + 1}个查询返回${results.length}个结果`);
        
        // 重新分配唯一的originalIndex，避免重复
        const resultsWithUniqueIndex = results.map(result => ({
          ...result,
          originalIndex: globalIndexCounter++
        }));
        
        allResults.push(...resultsWithUniqueIndex);
        
        // 避免过于频繁的API调用
        if (i < searchQueries.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      } catch (queryError) {
        console.warn(`搜索查询"${query}"失败:`, queryError);
        continue;
      }
    }
    
    // 去重
    const uniqueResults = removeDuplicateResults(allResults);
    console.log(`去重后获得${uniqueResults.length}个结果`);
    
    // 去重后重新分配连续的originalIndex，确保显示序号的一致性
    const reindexedResults = uniqueResults.map((result, index) => ({
      ...result,
      originalIndex: index + 1
    }));
    
    // 使用新的Gemini AI相关性评分系统
    console.log('开始Gemini AI智能相关性评分...');
    const scoredResults = await batchCalculateGeminiScores(
      reindexedResults, 
      keyword, 
      blogIdea, 
      searchQueries.join(' ')
    );
    
    const finalResults = scoredResults.slice(0, 15);
    console.log(`最终返回${finalResults.length}个AI评分排序后的结果`);
    
    return finalResults;
    
  } catch (error) {
    console.error('搜索相关内容失败:', error);
    // 如果AI方法失败，使用备用搜索
    return await fallbackSearch(keyword, blogIdea, targetMarket, targetLanguage, timeRange, searchKeyword);
  }
}

/**
 * 使用Gemini AI生成智能搜索查询
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @returns AI生成的搜索查询数组
 */
async function generateSmartSearchQueries(
  keyword: string,
  blogIdea: string,
  targetMarket: string,
  targetLanguage: string
): Promise<string[]> {
  try {
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    const prompt = `
作为一个专业的SEO研究专家，请分析以下博客创意并生成3-4个高质量的Google搜索查询，用于找到相关的参考文章和内容。

主关键词：${keyword}
博客创意：${blogIdea}
目标市场：${targetMarket}
目标语言：${targetLanguage}

请深入分析这个博客创意的核心主题、用户意图和内容类型，然后生成能够找到最相关参考内容的搜索查询。

分析要点：
1. 识别博客创意的核心概念和子主题
2. 理解目标受众的信息需求
3. 确定最有价值的参考内容类型
4. 考虑不同的搜索角度和关键词组合

生成的搜索查询应该：
- 能够找到高质量的博客文章、指南和教程
- 覆盖博客创意的不同方面和角度
- 适合目标市场和语言环境
- 避免过于宽泛或过于狭窄的查询
- 包含能够提升内容质量的参考资料

请用以下JSON格式回复：
{
  "queries": [
    {
      "query": "具体的搜索查询",
      "purpose": "这个查询的目的和预期找到的内容类型",
      "focus": "查询重点关注的方面"
    }
  ],
  "analysis": "对博客创意的简要分析和搜索策略说明"
}

注意：
- 搜索查询要用英文
- 确保查询能够找到实用的参考内容
- 考虑不同的内容角度和深度
- 生成3-4个不同角度的查询
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI搜索查询生成原始响应:', text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.queries && Array.isArray(aiResponse.queries)) {
        console.log('AI分析结果:', aiResponse.analysis);
        return aiResponse.queries.map((q: any) => q.query).filter((query: string) => query && query.length > 0);
      }
    } catch (parseError) {
      console.warn('解析AI搜索查询响应JSON失败:', parseError);
      
      // 尝试从文本中提取查询
      const extractedQueries = extractQueriesFromText(text, keyword);
      if (extractedQueries.length > 0) {
        return extractedQueries;
      }
    }
    
    return [];
    
  } catch (error) {
    console.error('AI生成搜索查询失败:', error);
    return [];
  }
}

/**
 * 过滤博客类型内容（AI增强版本）
 * @param searchResults - 搜索结果
 * @param keyword - 主关键词（可选，用于上下文分析）
 * @returns 过滤后的博客内容
 */
export async function filterBlogContent(
  searchResults: SearchResult[], 
  keyword?: string
): Promise<SearchResult[]> {
  try {
    console.log(`开始AI智能过滤博客内容，共${searchResults.length}个结果`);
    
    // 如果结果数量较少，直接使用AI分析
    if (searchResults.length <= 10) {
      return await aiFilterBlogContent(searchResults, keyword);
    }
    
    // 如果结果较多，先用快速规则过滤，再用AI精确分析
    const quickFiltered = quickFilterBlogContent(searchResults);
    console.log(`快速过滤后剩余${quickFiltered.length}个结果`);
    
    // 对快速过滤的结果进行AI精确分析
    const aiFiltered = await aiFilterBlogContent(quickFiltered, keyword);
    console.log(`AI过滤后最终剩余${aiFiltered.length}个博客内容`);
    
    return aiFiltered;
    
  } catch (error) {
    console.error('AI博客内容过滤失败，使用备用方法:', error);
    return quickFilterBlogContent(searchResults);
  }
}

/**
 * AI智能过滤博客内容
 * @param searchResults - 搜索结果
 * @param keyword - 主关键词
 * @returns AI过滤后的博客内容
 */
async function aiFilterBlogContent(
  searchResults: SearchResult[], 
  keyword?: string
): Promise<SearchResult[]> {
  try {
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建搜索结果文本
    const resultsText = searchResults.map((result, index) => 
      `结果${index + 1}:
标题: ${result.title}
摘要: ${result.snippet}
URL: ${result.url}`
    ).join('\n\n');
    
    const prompt = `
作为一个专业的内容分类专家，请分析以下搜索结果，识别哪些是适合作为博客写作参考的内容。

${keyword ? `主关键词: ${keyword}` : ''}

搜索结果:
${resultsText}

请识别以下类型的内容作为博客参考资料：

**优质博客内容类型：**
1. **教程和指南类** - 提供具体操作步骤和方法
2. **深度分析文章** - 对主题进行深入探讨和分析
3. **经验分享类** - 实际经验、案例研究、最佳实践
4. **评测和对比类** - 产品评测、工具对比、优缺点分析
5. **趋势和观点类** - 行业趋势、专家观点、未来预测
6. **问题解决类** - 常见问题解答、故障排除、解决方案

**排除的内容类型：**
1. **纯商业推广** - 明显的广告、产品销售页面
2. **新闻资讯** - 简单的新闻报道、公告
3. **论坛讨论** - 论坛帖子、问答片段
4. **技术文档** - 纯技术规范、API文档
5. **社交媒体** - 社交平台的简短内容
6. **低质量内容** - 内容浅薄、信息不完整

分析标准：
- 内容是否具有教育价值和参考价值
- 是否提供深入的见解或实用的建议
- 结构是否完整，适合作为写作参考
- 是否与主题相关且质量较高

请用以下JSON格式回复：
{
  "filtered_results": [
    {
      "index": 1,
      "is_blog_content": true,
      "content_type": "教程指南类",
      "quality_score": 85,
      "reason": "提供了详细的操作步骤和实用建议",
      "reference_value": "高"
    }
  ],
  "summary": {
    "total_analyzed": ${searchResults.length},
    "blog_content_count": 0,
    "main_content_types": ["教程指南类", "经验分享类"],
    "average_quality": 0
  }
}

注意：
- 只标记真正有价值的博客类型内容
- 质量评分范围0-100
- 参考价值：高/中/低
- 要严格筛选，宁缺毋滥
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI博客内容过滤原始响应:', text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.filtered_results && Array.isArray(aiResponse.filtered_results)) {
        const filteredResults: SearchResult[] = [];
        
        aiResponse.filtered_results.forEach((item: any) => {
          if (item.is_blog_content && item.index >= 1 && item.index <= searchResults.length) {
            const originalResult = searchResults[item.index - 1];
            // 添加AI分析的元数据
            const enhancedResult = {
              ...originalResult,
              contentType: item.content_type,
              qualityScore: item.quality_score,
              aiRelevanceScore: item.quality_score,
              referenceValue: item.reference_value,
              aiReason: item.reason
            };
            filteredResults.push(enhancedResult);
          }
        });
        
        // 按质量评分排序
        filteredResults.sort((a, b) => ((b as any).qualityScore || 0) - ((a as any).qualityScore || 0));
        
        // 排序后重新分配连续的originalIndex，确保页面显示的排序编号正确
        const reindexedResults = filteredResults.map((result, index) => ({
          ...result,
          originalIndex: index + 1
        }));
        
        console.log('AI过滤摘要:', aiResponse.summary);
        console.log(`AI识别出${reindexedResults.length}个高质量博客内容`);
        
        return reindexedResults;
      }
    } catch (parseError) {
      console.warn('解析AI博客过滤响应JSON失败:', parseError);
      
      // 尝试从文本中提取有用信息
      return extractBlogContentFromText(text, searchResults);
    }
    
    // 如果AI分析失败，返回快速过滤结果
    return quickFilterBlogContent(searchResults);
    
  } catch (error) {
    console.error('AI博客内容过滤失败:', error);
    return quickFilterBlogContent(searchResults);
  }
}

/**
 * 使用Gemini AI增强版本的知识点提取（异步）
 * @param content 内容文本
 * @returns Promise<string[]> 知识点数组
 */
export async function extractKnowledgePoints(content: string): Promise<string[]> {
  try {
    // 构建更明确的提示词
    const prompt = `You are an SEO expert. Extract the most important SEO keywords from the following text.

IMPORTANT: Return your response as a valid JSON array only, like this example:
["keyword1", "keyword2", "keyword3"]

Do not include any explanations, markdown formatting, or other text. Only return the JSON array.

Text to analyze: ${content}

JSON array:`;

    const response = await fetch('/api/extract-seo-knowledge', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        content
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    
    // 如果API返回了知识点数组，直接返回
    if (data.knowledge && Array.isArray(data.knowledge)) {
      return data.knowledge.filter((item: any) => 
        typeof item === 'string' && 
        item.trim().length > 0
      );
    }

    // 否则使用本地备用方法
    console.warn('API未返回有效知识点，使用本地提取方法');
    return extractKnowledgePointsLocal(content);
    
  } catch (error) {
    console.error('知识点提取失败，使用本地方法:', error);
    return extractKnowledgePointsLocal(content);
  }
}

/**
 * 本地备用方法：基础关键词提取
 * @param content 内容文本
 * @returns 关键词数组
 */
function extractKnowledgePointsLocal(content: string): string[] {
  const keywords = new Set<string>();
  
  // 分割文本为单词
  const words = content.toLowerCase()
    .split(/[\s\n\r\t,，。！？.!?；：;:()（）\[\]【】]+/)
    .filter(word => 
      word.length > 2 && 
      word.length < 30 &&
      !['the', 'and', 'for', 'with', 'that', 'this', 'from', 'they', 'have', 'been', 'will', 'can', 'should', 'would', 'could', 'may', 'might', 'must'].includes(word)
    );

  // 添加单词
  words.forEach(word => {
    if (word.match(/^[a-zA-Z\u4e00-\u9fa5]+$/)) { // 只包含字母或中文
      keywords.add(word);
    }
  });

  // 提取短语（2-3个词的组合）
  const sentences = content.split(/[.!?。！？\n]/);
  sentences.forEach(sentence => {
    const sentenceWords = sentence.trim().split(/\s+/);
    if (sentenceWords.length >= 2 && sentenceWords.length <= 3) {
      const phrase = sentenceWords.join(' ').toLowerCase();
      if (phrase.length > 5 && phrase.length < 40) {
        keywords.add(phrase);
      }
    }
  });

  return Array.from(keywords).slice(0, 10);
}

/**
 * 从搜索结果中提取知识点（兼容旧版本）
 * @param searchResults 搜索结果
 * @param keyword 主关键词
 * @returns 知识点数组
 */
export async function extractKnowledgeFromSearchResults(searchResults: any[], keyword: string): Promise<string[]> {
  // 合并所有搜索结果的文本内容
  const combinedContent = searchResults.map(result => 
    `${result.title || ''} ${result.snippet || ''} ${result.description || ''}`
  ).join(' ');
  
  // 使用改进的知识点提取
  return await extractKnowledgePoints(`${keyword} ${combinedContent}`);
}

/**
 * 批量Gemini AI相关性评分（优化版本 - 一次性批量处理）
 * @param results - 搜索结果数组
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @param searchQuery - 搜索查询
 * @returns 带有AI评分的结果数组
 */
async function batchCalculateGeminiScores(
  results: SearchResult[],
  keyword: string,
  blogIdea: string,
  searchQuery: string
): Promise<SearchResult[]> {
  try {
    console.log(`开始Gemini AI批量评分，共${results.length}个结果`);
    
    // 限制批量处理数量，避免输入过长
    const maxBatchSize = 10;
    const processResults = results.slice(0, maxBatchSize);
    
    // 构建批量评分的输入数据
    const batchInput = processResults.map((result, index) => ({
      index: index + 1,
      title: result.title,
      snippet: result.snippet,
      url: result.url
    }));
    
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    const prompt = `
作为一个专业的内容相关性分析专家，请批量评估以下搜索结果与博客创意的相关性程度。

博客创意：${blogIdea}
主关键词：${keyword}
搜索查询：${searchQuery}

搜索结果列表：
${batchInput.map(item => `
结果${item.index}：
标题：${item.title}
摘要：${item.snippet}
URL：${item.url}
`).join('\n')}

请从以下维度对每个结果进行综合评分（总分100分）：

1. **主题相关性** (30分)
   - 内容主题与博客创意的匹配程度
   - 关键词的自然出现和上下文相关性

2. **内容价值** (25分)
   - 信息的深度、准确性和实用性
   - 是否提供独特见解或有价值的信息

3. **目标受众匹配** (20分)
   - 内容复杂度和表达方式是否适合目标受众
   - 语言风格和专业程度的匹配

4. **参考价值** (15分)
   - 作为博客写作参考的适用性
   - 结构、观点或数据的借鉴价值

5. **权威性和可信度** (10分)
   - 来源的专业性和可信度
   - 内容的准确性和时效性

评分标准：
- 90-100分：高度相关，优质参考资料
- 80-89分：相关性强，有价值的参考
- 70-79分：中等相关，部分有用
- 60-69分：相关性一般，参考价值有限
- 50-59分：相关性较低，不太适合
- 0-49分：不相关或质量差

请用以下JSON格式回复：
{
  "batch_scores": [
    {
      "index": 1,
      "score": 85,
      "reason": "内容与博客创意高度相关，提供了深入的分析和实用建议"
    },
    {
      "index": 2,
      "score": 72,
      "reason": "相关性中等，有一定参考价值但深度不够"
    }
  ],
  "summary": {
    "total_evaluated": ${processResults.length},
    "average_score": 0,
    "highest_score": 0,
    "lowest_score": 0
  }
}

注意：
- 每个结果都必须给出0-100的整数评分
- 评分要客观公正，严格按照标准执行
- 简要说明评分理由
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('Gemini AI批量评分原始响应:', text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.batch_scores && Array.isArray(aiResponse.batch_scores)) {
        const scoredResults: SearchResult[] = [];
        
        // 处理AI评分的结果
        aiResponse.batch_scores.forEach((scoreItem: any) => {
          const index = scoreItem.index - 1;
          if (index >= 0 && index < processResults.length) {
            const originalResult = processResults[index];
            scoredResults.push({
              ...originalResult,
              aiRelevanceScore: scoreItem.score,
              finalScore: scoreItem.score,
              aiReason: scoreItem.reason
            });
          }
        });
        
        // 对剩余未评分的结果使用简化评分
        const remainingResults = results.slice(maxBatchSize).map(result => ({
          ...result,
          finalScore: calculateSimpleRelevanceScore(result, keyword, blogIdea)
        }));
        
        // 合并结果并按评分排序
        const allResults = [...scoredResults, ...remainingResults];
        const sortedResults = allResults.sort((a, b) => 
          ((b as any).finalScore || 0) - ((a as any).finalScore || 0)
        );
        
        console.log('AI批量评分摘要:', aiResponse.summary);
        console.log(`Gemini AI批量评分完成，最高分: ${(sortedResults[0] as any).finalScore}`);
        
        return sortedResults;
      }
    } catch (parseError) {
      console.warn('解析AI批量评分响应JSON失败:', parseError);
      
      // 尝试从文本中提取评分信息
      return extractBatchScoresFromText(text, results, keyword, blogIdea);
    }
    
    // 如果AI批量评分失败，使用简化评分
    console.warn('AI批量评分失败，使用简化评分方法');
    return results.map(result => ({
      ...result,
      finalScore: calculateSimpleRelevanceScore(result, keyword, blogIdea)
    })).sort((a, b) => ((b as any).finalScore || 0) - ((a as any).finalScore || 0));
    
  } catch (error) {
    console.error('Gemini AI批量评分失败:', error);
    // 如果批量评分失败，使用简化评分
    return results.map(result => ({
      ...result,
      finalScore: calculateSimpleRelevanceScore(result, keyword, blogIdea)
    })).sort((a, b) => ((b as any).finalScore || 0) - ((a as any).finalScore || 0));
  }
}

/**
 * 从SERPs分析中提取LSI术语（潜在语义索引术语）
 * @param filteredResults - 过滤后的搜索结果
 * @param keyword - 主关键词
 * @returns LSI术语数组
 */
export async function extractLSITerms(
  filteredResults: SearchResult[],
  keyword: string
): Promise<string[]> {
  if (!filteredResults || filteredResults.length === 0) {
    console.warn('没有搜索结果可供LSI术语提取');
    return [];
  }

  try {
    console.log(`开始从${filteredResults.length}个搜索结果中提取LSI术语`);
    
    // 构建分析内容
    const serpsContent = filteredResults.map(result => ({
      title: result.title,
      snippet: result.snippet,
      url: result.url
    }));

    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    const prompt = `作为SEO专家，请分析以下Google搜索结果页面(SERPs)，为主关键词"${keyword}"提取LSI术语(潜在语义索引术语)。

主关键词: ${keyword}

搜索结果页面内容:
${serpsContent.map((result, index) => 
  `结果${index + 1}:
  标题: ${result.title}
  摘要: ${result.snippet}
  URL: ${result.url}`
).join('\n\n')}

请根据以上SERP内容，执行以下LSI术语提取任务:

1. **共现分析**: 分析在这些高排名页面中，与"${keyword}"经常一起出现的词语和短语
2. **语义相关分析**: 识别与主题概念相关但不是直接同义词的术语
3. **主题聚类**: 找出构成完整主题覆盖的相关术语
4. **长尾关键词**: 提取用户可能搜索的相关长尾词组

提取规则:
- 专注于与"${keyword}"语义相关的专业术语、概念、工具、方法
- 避免通用词汇（如"的"、"是"、"最好"等）
- 包含相关的行业术语、技术名词、品牌名称
- 包含相关的动作词、形容词、名词短语
- 优先选择在多个结果中重复出现的术语

请以JSON格式返回结果:
{
  "lsi_terms": [
    "术语1",
    "术语2", 
    "术语3"
  ],
  "categories": {
    "核心概念": ["相关核心概念"],
    "技术术语": ["技术相关术语"],
    "应用场景": ["使用场景术语"],
    "相关工具": ["工具和方法术语"]
  },
  "explanation": "LSI术语提取的简要说明"
}

请确保提取15-25个高质量的LSI术语。`;

    console.log('正在调用Gemini API进行LSI术语提取...');
    const result = await model.generateContent(prompt);
    const response = result.response;
    
    console.log('Gemini LSI术语提取原始响应:', JSON.stringify(response, null, 2));
    
    // 从response中提取文本内容
    let text = '';
    if (response.candidates && response.candidates.length > 0) {
      const candidate = response.candidates[0];
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        const partText = candidate.content.parts[0].text;
        if (partText) {
          text = partText;
        }
      }
    }
    
    if (!text) {
      console.error('无法从Gemini响应中提取文本内容');
      return [];
    }
    
    console.log('提取的文本内容:', text);

    // 清理文本，移除markdown代码块标记
    const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    console.log('清理后的文本:', cleanedText);

    // 尝试解析JSON响应
    const jsonMatch = cleanedText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.error('无法找到JSON格式的响应');
      return [];
    }
    
    const aiResponse = JSON.parse(jsonMatch[0]);
    
    if (aiResponse.lsi_terms && Array.isArray(aiResponse.lsi_terms)) {
      console.log(`成功提取${aiResponse.lsi_terms.length}个LSI术语:`, aiResponse.lsi_terms);
      console.log('LSI术语分类:', aiResponse.categories);
      console.log('提取说明:', aiResponse.explanation);
      
      return aiResponse.lsi_terms;
    } else {
      console.error('AI响应中没有有效的LSI术语数组');
      return [];
    }
    
  } catch (error) {
    console.error('LSI术语提取失败:', error);
    return [];
  }
} 
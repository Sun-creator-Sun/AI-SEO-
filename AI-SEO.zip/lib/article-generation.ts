import { BlogOutline } from '@/lib/google-search'
import { searchKeyword } from '@/lib/search-api'
import { SearchResult as GoogleSearchResult } from '@/lib/types'

/**
 * 通过API路由调用Gemini
 * @param prompt - 提示词
 * @param generationConfig - 生成配置
 * @returns Promise<{success: boolean, data?: string, error?: string}>
 */
async function callGeminiViaAPI(
  prompt: string,
  generationConfig?: any
): Promise<{success: boolean, data?: string, error?: string}> {
  try {
    const response = await fetch('/api/gemini-generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        generationConfig
      })
    })

    const result = await response.json()
    
    if (result.success) {
      return {
        success: true,
        data: result.data
      }
    } else {
      return {
        success: false,
        error: result.error || 'API调用失败'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : '网络请求失败'
    }
  }
}

// 证据类型枚举
export enum EvidenceType {
  STATISTICAL_EVIDENCE = 'statistical_evidence',           // 统计证据/数据 - 具体数字、百分比、统计报告
  PREDICTIVE_EVIDENCE = 'predictive_evidence',             // 预测性证据
  DESCRIPTIVE_EVIDENCE = 'descriptive_evidence',           // 描述性证据
  EXPLANATORY_EVIDENCE = 'explanatory_evidence',           // 解释性证据 - 原理解释、机制说明
  COMPARATIVE_DATA = 'comparative_data',                    // 对比数据
  USER_EXPERIENCE = 'user_experience',                     // 用户体验
  SURVEY_RESULTS = 'survey_results',                       // 调查结果
  STATISTICS_USER_SURVEYS = 'statistics_user_surveys',     // 统计和用户调查
  PROS_AND_CONS = 'pros_and_cons',                        // 优缺点分析
  PERFORMANCE_METRICS = 'performance_metrics',             // 性能指标
  FEATURE_ANALYSIS = 'feature_analysis',                  // 功能分析
  ADVANTAGES_DISADVANTAGES = 'advantages_disadvantages',   // 优势与劣势
  FEATURE_DESCRIPTION = 'feature_description',            // 功能描述
  COMPARATIVE_NUMERICAL_REVIEW = 'comparative_numerical_review', // 数值对比评测
  USER_FEEDBACK_STATISTICS = 'user_feedback_statistics',   // 用户反馈统计
  EXPERT_PREDICTIONS = 'expert_predictions',               // 专家预测
  RESEARCH_FINDINGS = 'research_findings',                 // 研究发现
  FEATURES_CAPABILITIES = 'features_capabilities',         // 功能和能力
  MARKET_DATA = 'market_data',                            // 市场数据
  USER_PERFORMANCE_METRICS = 'user_performance_metrics',   // 用户性能指标
  COMPARATIVE_ANALYSIS = 'comparative_analysis'            // 对比分析
}

// 证据项接口
export interface Evidence {
  type: EvidenceType
  content: string
  source: string
  url: string
  credibility: number  // 可信度评分 1-10
  relevance: number    // 相关性评分 1-10
  publishDate?: string
  sectionInfo?: {
    h2Title: string    // H2章节标题
    h2Index: number    // H2章节序号
    h3Title?: string   // H3子章节标题（如果有）
    h3Index?: number   // H3子章节序号（如果有）
  }
}

// 章节证据需求接口
export interface SectionEvidenceRequirement {
  sectionTitle: string
  sectionContent: string
  requiredEvidenceTypes: EvidenceType[]
  priority: number  // 优先级 1-10
  searchQueries: string[]
  sectionIndex: number  // 章节序号
  subSections?: Array<{
    title: string
    index: number
  }>
}

// 本地搜索结果接口（扩展了全局SearchResult接口）
export interface ExtendedSearchResult extends GoogleSearchResult {
  domain: string
  publishDate?: string
}

// 抓取内容接口
export interface ExtractedContent {
  url: string
  title: string
  content: string
  publishDate?: string
  author?: string
  domain: string
}

/**
 * 步骤1：确定并匹配合适的证据类型
 * @param outline - 文章大纲
 * @param keyword - 主关键词
 * @returns Promise<SectionEvidenceRequirement[]>
 */
export async function matchEvidenceTypes(
  outline: BlogOutline,
  keyword: string
): Promise<SectionEvidenceRequirement[]> {
  try {
    console.log('🔍 步骤1：开始分析大纲并匹配证据类型...')
    
    const prompt = `
作为SEO内容策略专家，请分析以下文章大纲，为每个章节匹配最适合的证据类型。

主关键词：${keyword}
文章标题：${outline.title}

文章大纲：
${outline.sections.map((section, index) => `
${index + 1}. ${section.heading}
   内容概述：${section.keyPoints.join('; ')}
   ${section.subheadings?.length ? `子章节：\n${section.subheadings.map((sub, subIndex) => 
     `      ${index + 1}.${subIndex + 1}. ${sub}`).join('\n')}` : ''}`
).join('\n\n')}

请为每个章节和子章节分析：
1. 该章节的核心论点是什么？
2. 最适合支撑该论点的证据类型（从以下选择2-4个最相关的）：

**数据类证据**：
   - statistical_evidence（统计证据/数据）- 具体数字、百分比、统计报告
   - predictive_evidence（预测性证据）- 趋势预测、未来数据、市场前景
   - market_data（市场数据）- 市场规模、增长率、行业数据
   - survey_results（调查结果）- 问卷调查、用户调研、行为统计
   - statistics_user_surveys（统计和用户调查）- 综合统计与调查数据

**功能与性能类证据**：
   - performance_metrics（性能指标）- 速度、效率、准确率等量化指标
   - feature_analysis（功能分析）- 功能细节、技术特性分析
   - feature_description（功能描述）- 产品/服务功能详细说明
   - features_capabilities（功能和能力）- 完整功能体系、能力范围
   - user_performance_metrics（用户性能指标）- 用户使用后的性能表现

**对比类证据**：
   - comparative_data（对比数据）- 数据层面的直接对比
   - comparative_analysis（对比分析）- 深度对比分析
   - comparative_numerical_review（数值对比评测）- 量化的产品/服务对比
   - pros_and_cons（优缺点分析）- 优势劣势对比
   - advantages_disadvantages（优势与劣势）- 详细利弊分析

**体验与反馈类证据**：
   - user_experience（用户体验）- 用户使用感受、体验案例
   - user_feedback_statistics（用户反馈统计）- 用户评价的统计分析
   - descriptive_evidence（描述性证据）- 详细的场景描述、使用案例

**专业与研究类证据**：
   - expert_predictions（专家预测）- 行业专家的预测和观点
   - research_findings（研究发现）- 学术研究、实验结果
   - explanatory_evidence（解释性证据）- 原理解释、机制说明

3. 建议的Google搜索查询词（3-5个，针对选择的证据类型）
4. 优先级评分（1-10，10为最重要）

请按以下JSON格式输出：
{
  "sections": [
    {
      "sectionTitle": "章节标题",
      "sectionContent": "章节内容概述",
      "requiredEvidenceTypes": ["statistical_evidence", "performance_metrics", "comparative_data"],
      "priority": 8,
      "sectionIndex": 0,
      "searchQueries": [
        "${keyword} statistics data 2025",
        "${keyword} performance benchmarks",
        "${keyword} vs alternatives comparison",
        "${keyword} market research report",
        "${keyword} user satisfaction survey"
      ],
      "subSections": [
        {
          "title": "子章节标题",
          "index": 0
        }
      ]
    }
  ]
}

注意：
1. 每个章节选择2-4个最相关的证据类型
2. 搜索查询要针对选择的证据类型设计
3. 优先考虑客观、可量化的证据类型
4. 根据章节内容的性质选择最合适的证据组合
5. 确保包含章节索引和子章节信息
`

    // 配置生成参数
    const generationConfig = {
      temperature: 0.7,
      topK: 20,
      topP: 0.95,
      responseMimeType: "application/json"
    }

    const result = await callGeminiViaAPI(prompt, generationConfig)
    
    if (!result.success) {
      throw new Error(result.error || 'Gemini API调用失败')
    }
    
    if (!result.data) {
      throw new Error('Gemini API返回空数据')
    }
    
    console.log('🤖 Gemini分析结果:', result.data.substring(0, 500))
    
    // 解析JSON结果
    const parsed = JSON.parse(result.data)
    
    // 手动添加章节索引和子章节信息
    const requirements: SectionEvidenceRequirement[] = outline.sections.map((section, index) => {
      const matchedSection = parsed.sections.find(
        (s: any) => s.sectionTitle.toLowerCase() === section.heading.toLowerCase()
      )
      
      if (!matchedSection) {
        console.warn(`⚠️ 未找到章节匹配: ${section.heading}`)
        return {
          sectionTitle: section.heading,
          sectionContent: section.keyPoints.join('; '),
          requiredEvidenceTypes: [EvidenceType.DESCRIPTIVE_EVIDENCE],
          priority: 5,
          searchQueries: [`${keyword} ${section.heading}`],
          sectionIndex: index,
          subSections: section.subheadings?.map((sub, subIndex) => ({
            title: sub,
            index: subIndex
          }))
        }
      }
      
      return {
        ...matchedSection,
        sectionIndex: index,
        subSections: section.subheadings?.map((sub, subIndex) => ({
          title: sub,
          index: subIndex
        }))
      }
    })
    
    // 打印章节信息
    requirements.forEach((req, index) => {
      console.log(`📑 章节 ${index + 1}: ${req.sectionTitle}`)
      console.log(`   优先级: ${req.priority}`)
      console.log(`   证据类型: ${req.requiredEvidenceTypes.join(', ')}`)
      if (req.subSections?.length) {
        console.log(`   子章节:`)
        req.subSections.forEach(sub => {
          console.log(`      ${req.sectionIndex + 1}.${sub.index + 1}. ${sub.title}`)
        })
      }
      console.log('---')
    })
    
    console.log(`✅ 步骤1完成：为${requirements.length}个章节匹配了证据类型`)
    return requirements
    
  } catch (error) {
    console.error('❌ 步骤1失败:', error)
    throw new Error(`证据类型匹配失败: ${error instanceof Error ? error.message : '未知错误'}`)
  }
}

/**
 * 步骤2：智能搜索目标证据
 * @param requirements - 章节证据需求
 * @param targetLanguage - 目标语言
 * @param targetMarket - 目标市场
 * @returns Promise<ExtendedSearchResult[]>
 */
export async function searchTargetEvidence(
  requirements: SectionEvidenceRequirement[],
  targetLanguage: string = '英语',
  targetMarket: string = '美国'
): Promise<ExtendedSearchResult[]> {
  try {
    console.log('🔍 步骤2：开始搜索目标证据...')
    
    // 按优先级排序章节
    const sortedRequirements = requirements.sort((a, b) => b.priority - a.priority)
    
    // 打印所有章节的搜索查询
    console.log('=== 所有章节的搜索查询列表 ===')
    sortedRequirements.forEach((requirement, index) => {
      console.log(`章节 ${index + 1}: ${requirement.sectionTitle}`)
      console.log(`优先级: ${requirement.priority}`)
      console.log(`搜索查询:`, requirement.searchQueries)
      console.log('---')
    })
    
    // 收集所有搜索查询
    const allQueries: string[] = []
    sortedRequirements.forEach(requirement => {
      allQueries.push(...requirement.searchQueries)
    })
    
    console.log(`📝 总计收集到 ${allQueries.length} 个搜索查询`)
    console.log(`🎯 即将进行 ${allQueries.length} 次搜索请求`)
    
    // 使用新的批量搜索函数
    const { searchEvidenceQueries } = await import('@/lib/search-api')
    const googleSearchResults = await searchEvidenceQueries(
      allQueries,
      targetMarket,
      targetLanguage,
      '过去一周'
    )
    
    // 转换为ExtendedSearchResult格式，添加domain字段
    const searchResults: ExtendedSearchResult[] = googleSearchResults.map(result => ({
      ...result,
      domain: extractDomain(result.url)
    }))
    
    console.log(`✅ 步骤2完成：找到${searchResults.length}个潜在证据来源`)
    return searchResults.slice(0, 20) // 限制最多20个结果，避免抓取过多
    
  } catch (error) {
    console.error('❌ 步骤2失败:', error)
    throw new Error(`证据搜索失败: ${error instanceof Error ? error.message : '未知错误'}`)
  }
}

/**
 * 步骤3：抓取相关网站内容获取目标证据
 * @param searchResults - 搜索结果
 * @returns Promise<ExtractedContent[]>
 */
export async function extractWebsiteContent(
  searchResults: ExtendedSearchResult[]
): Promise<ExtractedContent[]> {
  try {
    console.log('🕷️ 步骤3：开始抓取网站内容...')
    
    if (searchResults.length === 0) {
      console.warn('⚠️ 没有搜索结果可供抓取')
      return []
    }
    
    // 提取URL列表
    const urls = searchResults.map(result => result.url)
    console.log(`🎯 准备抓取 ${urls.length} 个网站`)
    
    // 获取基础URL，兼容客户端和服务器端
    const baseUrl = typeof window !== 'undefined' 
      ? window.location.origin 
      : process.env.NEXTAUTH_URL || 'http://localhost:3000'
    
    // 调用抓取API路由
    console.log('📡 调用抓取API路由...')
    const response = await fetch(`${baseUrl}/api/scrape`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        urls: urls,
        maxConcurrency: 3 // 控制并发数，避免过载
      })
    })
    
    if (!response.ok) {
      throw new Error(`抓取API调用失败: ${response.status} ${response.statusText}`)
    }
    
    const result = await response.json()
    
    if (!result.success) {
      throw new Error(`抓取API返回错误: ${result.error || '未知错误'}`)
    }
    
    console.log(`📊 抓取API统计:`)
    console.log(`   - 总数: ${result.summary.total}`)
    console.log(`   - 成功: ${result.summary.successful}`)
    console.log(`   - 失败: ${result.summary.failed}`)
    
    // 处理抓取结果，转换为ExtractedContent格式
    const extractedContents: ExtractedContent[] = []
    
    for (let i = 0; i < result.results.length; i++) {
      const apiResult = result.results[i]
      const originalSearchResult = searchResults[i]
      
      // 只处理成功抓取的内容
      if (apiResult.content && apiResult.content.length > 200) {
        // 提取发布日期和作者信息
        const publishDate = extractPublishDate(apiResult.content)
        const author = extractAuthor(apiResult.content)
        
        const extracted: ExtractedContent = {
          url: apiResult.url,
          title: originalSearchResult.title,
          content: apiResult.content,
          publishDate: publishDate,
          author: author,
          domain: extractDomain(apiResult.url)
        }
        
        extractedContents.push(extracted)
        console.log(`✅ 成功处理: ${originalSearchResult.title} (${apiResult.content.length}字符)`)
      } else if (apiResult.error) {
        console.warn(`⚠️ 抓取失败: ${apiResult.url} - ${apiResult.error}`)
      } else {
        console.warn(`⚠️ 内容过短: ${apiResult.url} - 内容长度: ${apiResult.content?.length || 0}`)
      }
    }
    
    console.log(`✅ 步骤3完成：成功抓取${extractedContents.length}篇文章内容`)
    return extractedContents
    
  } catch (error) {
    console.error('❌ 步骤3失败:', error)
    throw new Error(`网站内容抓取失败: ${error instanceof Error ? error.message : '未知错误'}`)
  }
}

/**
 * 验证提取的证据是否有效且正确分配
 */
function validateEvidence(evidence: Evidence[], requirements: SectionEvidenceRequirement[]): Evidence[] {
  return evidence.filter(item => {
    // 基本验证
    if (!item.content || item.content.length < 10) {
      console.warn('⚠️ 证据内容过短或为空');
      return false;
    }
    
    if (!item.sectionInfo) {
      console.warn('⚠️ 缺少章节信息');
      return false;
    }

    const h2Idx = item.sectionInfo.h2Index;
    const h3Idx = item.sectionInfo.h3Index; // Might be undefined or null

    // 验证 h2Index
    if (h2Idx === undefined || h2Idx === null || h2Idx < 0 || h2Idx >= requirements.length) {
      console.warn(`⚠️ 证据 h2Index 无效或缺失: ${h2Idx}, 内容: "${item.content.substring(0, 50)}..."`);
      return false;
    }
    
    const matchedSection = requirements[h2Idx];
    
    // 使用来自 requirements 的官方标题填充/覆盖 evidence.sectionInfo 中的标题
    // 这是为了确保后续模块（如 content-generation.ts）使用一致的标题
    if (item.sectionInfo.h2Title && item.sectionInfo.h2Title.toLowerCase() !== matchedSection.sectionTitle.toLowerCase()) {
      console.warn(`⚠️ Gemini提供的h2Title ("${item.sectionInfo.h2Title}") 与 requirements中的标题 ("${matchedSection.sectionTitle}") 不符 (h2Index: ${h2Idx}). 将使用requirements中的标题.`);
    }
    item.sectionInfo.h2Title = matchedSection.sectionTitle;
    item.sectionInfo.h2Index = matchedSection.sectionIndex; // 确保索引也与 requirement 一致

    // 验证 h3Index 和填充 h3Title (如果存在)
    if (h3Idx !== undefined && h3Idx !== null) {
      if (!matchedSection.subSections || h3Idx < 0 || h3Idx >= matchedSection.subSections.length) {
        console.warn(`⚠️ 证据 h3Index 无效: ${h3Idx} (H2: ${matchedSection.sectionTitle}), 内容: "${item.content.substring(0, 50)}..."`);
        // 决定是否将其视为致命错误，或仅忽略H3并分配给H2
        // 为了更严格的匹配，这里返回false
        return false; 
      }
      const matchedSubSection = matchedSection.subSections[h3Idx];
      if (item.sectionInfo.h3Title && item.sectionInfo.h3Title.toLowerCase() !== matchedSubSection.title.toLowerCase()) {
        console.warn(`⚠️ Gemini提供的h3Title ("${item.sectionInfo.h3Title}") 与 requirements中的子标题 ("${matchedSubSection.title}") 不符 (h2Index: ${h2Idx}, h3Index: ${h3Idx}). 将使用requirements中的子标题.`);
      }
      item.sectionInfo.h3Title = matchedSubSection.title;
      item.sectionInfo.h3Index = matchedSubSection.index; // 确保索引也与 requirement 一致
    } else {
      // 如果证据中没有h3Index，确保相关的h3字段被清除
      item.sectionInfo.h3Title = undefined;
      item.sectionInfo.h3Index = undefined;
    }
    
    // 验证证据类型
    if (!matchedSection.requiredEvidenceTypes.includes(item.type)) {
      console.warn(`⚠️ 证据类型 (${item.type}) 与章节 "${matchedSection.sectionTitle}" 的要求不符. 内容: "${item.content.substring(0, 50)}..."`);
      return false;
    }
    
    return true;
  });
}

/**
 * 步骤4：分析并提取网站内容中的目标证据
 * @param extractedContents - 抓取的网站内容
 * @param requirements - 章节证据需求
 * @param keyword - 主关键词
 * @returns Promise<Evidence[]>
 */
export async function analyzeAndExtractEvidence(
  extractedContents: ExtractedContent[],
  requirements: SectionEvidenceRequirement[],
  keyword: string
): Promise<Evidence[]> {
  try {
    console.log('🔬 步骤4：开始分析并提取目标证据...');
    
    const allEvidence: Evidence[] = [];

    // 为Gemini prompt准备文章结构信息
    const articleStructureForPrompt = requirements.map(req => ({
      h2Index: req.sectionIndex,
      h2Title: req.sectionTitle,
      requiredEvidenceTypes: req.requiredEvidenceTypes,
      subSections: req.subSections?.map(sub => ({
        h3Index: sub.index,
        h3Title: sub.title
      })) || []
    }));
    
    for (const content of extractedContents) {
      try {
        console.log(`🔬 分析内容: ${content.title} (URL: ${content.url})`);
        
        const prompt = `
As an evidence analysis expert, analyze the provided content and extract relevant evidence for an article about "${keyword}".

Article Structure (Pay close attention to h2Index and h3Index for assignment):
${JSON.stringify(articleStructureForPrompt, null, 2)}

Available Evidence Types (ONLY use these exact values):
enum requiredEvidenceTypes {
  STATISTICAL_EVIDENCE = 'statistical_evidence',           // 统计证据/数据 - 具体数字、百分比、统计报告
  PREDICTIVE_EVIDENCE = 'predictive_evidence',            // 预测性证据 - 趋势预测、未来数据、市场前景
  MARKET_DATA = 'market_data',                            // 市场数据 - 市场规模、增长率、行业数据
  SURVEY_RESULTS = 'survey_results',                      // 调查结果 - 问卷调查、用户调研、行为统计
  STATISTICS_USER_SURVEYS = 'statistics_user_surveys',     // 统计和用户调查 - 综合统计与调查数据
  PERFORMANCE_METRICS = 'performance_metrics',             // 性能指标 - 速度、效率、准确率等量化指标
  FEATURE_ANALYSIS = 'feature_analysis',                  // 功能分析 - 功能细节、技术特性分析
  FEATURE_DESCRIPTION = 'feature_description',            // 功能描述 - 产品/服务功能详细说明
  FEATURES_CAPABILITIES = 'features_capabilities',         // 功能和能力 - 完整功能体系、能力范围
  USER_PERFORMANCE_METRICS = 'user_performance_metrics',   // 用户性能指标 - 用户使用后的性能表现
  COMPARATIVE_DATA = 'comparative_data',                   // 对比数据 - 数据层面的直接对比
  COMPARATIVE_ANALYSIS = 'comparative_analysis',           // 对比分析 - 深度对比分析
  COMPARATIVE_NUMERICAL_REVIEW = 'comparative_numerical_review', // 数值对比评测 - 量化的产品/服务对比
  PROS_AND_CONS = 'pros_and_cons',                        // 优缺点分析 - 优势劣势对比
  ADVANTAGES_DISADVANTAGES = 'advantages_disadvantages',   // 优势与劣势 - 详细利弊分析
  USER_EXPERIENCE = 'user_experience',                     // 用户体验 - 用户使用感受、体验案例
  USER_FEEDBACK_STATISTICS = 'user_feedback_statistics',   // 用户反馈统计 - 用户评价的统计分析
  DESCRIPTIVE_EVIDENCE = 'descriptive_evidence',           // 描述性证据 - 详细的场景描述、使用案例
  EXPERT_PREDICTIONS = 'expert_predictions',               // 专家预测 - 行业专家的预测和观点
  RESEARCH_FINDINGS = 'research_findings',                 // 研究发现 - 学术研究、实验结果
  EXPLANATORY_EVIDENCE = 'explanatory_evidence'           // 解释性证据 - 原理解释、机制说明
}

IMPORTANT: Evidence Type Assignment Rules:
1. Each piece of evidence MUST be assigned EXACTLY ONE type from the above enum
2. You can extract MULTIPLE pieces of evidence from the same content
3. Different pieces of evidence can have different types
4. DO NOT create new types or modify the existing types
5. Each evidence should focus on ONE specific point or fact

Content Source:
Title: ${content.title}
URL: ${content.url}
Domain: ${content.domain}
Date: ${content.publishDate || 'Unknown'}

Content to Analyze:
"""
${content.content}
"""

Extraction Guidelines:
1. Focus on extracting evidence that directly supports the topics outlined in the Article Structure.
2. For each piece of evidence, identify the MOST RELEVANT H2 section and, if applicable, H3 subsection it belongs to, using their numerical indices (\`h2Index\`, \`h3Index\`).
3. Maintain original wording for the evidence - use exact quotes.
4. Preserve all numerical data, statistics, and metrics accurately.
5. Rate credibility and relevance (1-10, 10 is best) based on source quality and content match to the specific section/subsection.
6. Ensure the \`type\` field matches one of the \`requiredEvidenceTypes\` for the assigned section.

JSON Output Format (Return ONLY the JSON object below, nothing else):
{
  "evidence": [
    {
      "type": "evidence_type_from_list_for_the_section",
      "content": "exact_quote_of_the_evidence_found_in_the_content",
      "source": "${content.domain}",
      "url": "${content.url}",
      "credibility": "integer_rating_1_to_10",
      "relevance": "integer_rating_1_to_10",
      "publishDate": "${content.publishDate || ''}",
      "sectionInfo": {
        "h2Index": "numerical_h2Index_from_Article_Structure", 
        "h3Index": "numerical_h3Index_from_Article_Structure_if_applicable_else_null",
        "h2Title": "identified_h2_title_optional_but_helpful", 
        "h3Title": "identified_h3_title_if_applicable_optional_but_helpful" 
      }
    }
  ]
}

Key Requirements:
- Prioritize evidence that is specific, quantifiable, and directly supports a point in the article structure.
- If a piece of content could fit multiple sections, choose the MOST specific and relevant one.
- If no relevant evidence is found in the content for ANY section, return an empty "evidence" array: {"evidence": []}.
- Ensure \`h2Index\` is always a number. \`h3Index\` is a number or null.
- Make sure the "type" of evidence is appropriate for the section it's assigned to, based on \`requiredEvidenceTypes\` in the Article Structure.
`

        // 配置生成参数
        const generationConfig = {
          temperature: 0.3, // Lower temperature for more deterministic output
          topK: 20,
          topP: 0.95,
          responseMimeType: "application/json"
        };

        const result = await callGeminiViaAPI(prompt, generationConfig);
        
        if (!result.success) {
          console.warn(`⚠️ 证据分析API调用失败 for: ${content.title}`, result.error);
          continue;
        }
        
        if (!result.data) {
          console.warn(`⚠️ 证据分析API返回空数据 for: ${content.title}`);
          continue;
        }
        
        // 解析JSON结果
        try {
          const parsed = JSON.parse(result.data);
          if (parsed.evidence && Array.isArray(parsed.evidence)) {
            const extractedFromThisSource: Evidence[] = [];
            parsed.evidence.forEach((e: any) => {
              if (
                e.content && e.content.length > 10 &&
                e.sectionInfo && e.sectionInfo.h2Index !== undefined && e.sectionInfo.h2Index !== null 
                // Credibility and relevance can be further filtered in validateEvidence if needed
              ) {
                // Ensure indices are numbers
                const h2Index = parseInt(e.sectionInfo.h2Index, 10);
                const h3Index = (e.sectionInfo.h3Index !== undefined && e.sectionInfo.h3Index !== null) 
                                 ? parseInt(e.sectionInfo.h3Index, 10) 
                                 : undefined;

                if (isNaN(h2Index)) {
                    console.warn(`⚠️ Gemini返回的h2Index无效: ${e.sectionInfo.h2Index}, 内容: ${e.content.substring(0,50)}`);
                    return; // Skip this evidence item
                }
                
                extractedFromThisSource.push({
                  type: e.type as EvidenceType,
                  content: e.content,
                  source: e.source || content.domain,
                  url: e.url || content.url,
                  credibility: parseInt(e.credibility, 10) || 5,
                  relevance: parseInt(e.relevance, 10) || 5,
                  publishDate: e.publishDate || content.publishDate,
                  sectionInfo: {
                    h2Index: h2Index,
                    h3Index: isNaN(h3Index as number) ? undefined : h3Index, // Store as number or undefined
                    h2Title: e.sectionInfo.h2Title, // Keep title from Gemini for now, validateEvidence will finalize
                    h3Title: e.sectionInfo.h3Title  // Keep title from Gemini for now
                  }
                });
              }
            });
            allEvidence.push(...extractedFromThisSource);
            console.log(`✅ 从 ${content.title} (URL: ${content.url}) 提取 ${extractedFromThisSource.length} 条原始证据`);
          }
        } catch (parseError) {
          console.warn(`⚠️ 解析来自 ${content.title} 的证据失败`, parseError, 'Raw data:', result.data.substring(0, 500));
        }
        
        // 避免过于频繁的API调用
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.warn(`⚠️ 分析内容失败 for: ${content.title}`, error);
        continue;
      }
    }
    
    console.log(`\n📊 验证前总共提取到 ${allEvidence.length} 条证据`);
    
    // 在返回结果前添加验证 - 这一步会使用索引来匹配并填充正确的标题
    const validatedEvidence = validateEvidence(allEvidence, requirements);
    console.log(`📊 验证和标题校正后的证据数量: ${validatedEvidence.length}`);

    // 可选：在验证后再次去重和排序
    const finalUniqueEvidence = removeDuplicateEvidence(validatedEvidence);
    const finalSortedEvidence = finalUniqueEvidence.sort((a, b) => {
      // 优先排序 h2Index, 然后 h3Index, 然后是可信度和相关性
      if ((a.sectionInfo?.h2Index ?? -1) !== (b.sectionInfo?.h2Index ?? -1)) {
        return (a.sectionInfo?.h2Index ?? -1) - (b.sectionInfo?.h2Index ?? -1);
      }
      if ((a.sectionInfo?.h3Index ?? -1) !== (b.sectionInfo?.h3Index ?? -1)) {
        return (a.sectionInfo?.h3Index ?? -1) - (b.sectionInfo?.h3Index ?? -1);
      }
      return (b.credibility * b.relevance) - (a.credibility * a.relevance);
    });

    console.log(`✅ 步骤4完成：最终筛选出 ${finalSortedEvidence.length} 条高质量证据`);
    return finalSortedEvidence;
    
  } catch (error) {
    console.error('❌ 步骤4失败:', error)
    throw new Error(`证据提取分析失败: ${error instanceof Error ? error.message : '未知错误'}`)
  }
}

// 辅助函数

/**
 * 从URL中提取域名
 */
function extractDomain(url: string): string {
  try {
    const domain = new URL(url).hostname
    return domain.replace('www.', '')
  } catch {
    return 'unknown'
  }
}

/**
 * 去重证据
 */
function removeDuplicateEvidence(evidence: Evidence[]): Evidence[] {
  const seen = new Set<string>()
  return evidence.filter(item => {
    const key = `${item.content.substring(0, 100)}-${item.source}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

/**
 * 提取发布日期
 */
function extractPublishDate(content: string): string | undefined {
  // 多种日期格式的正则表达式
  const dateRegexes = [
    /(\d{4}[-\/]\d{1,2}[-\/]\d{1,2})/,
    /(\d{1,2}[-\/]\d{1,2}[-\/]\d{4})/,
    /(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}/i,
    /(\d{1,2}\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})/i
  ]
  
  for (const regex of dateRegexes) {
    const match = content.match(regex)
    if (match) {
      return match[1] || match[0]
    }
  }
  
  return undefined
}

/**
 * 提取作者信息
 */
function extractAuthor(content: string): string | undefined {
  const authorRegexes = [
    /作者[：:]\s*([^\n\r]+)/i,
    /Author[：:]\s*([^\n\r]+)/i,
    /By\s+([A-Za-z\s]+)/i,
    /Written by\s+([A-Za-z\s]+)/i
  ]
  
  for (const regex of authorRegexes) {
    const match = content.match(regex)
    if (match) {
      return match[1].trim()
    }
  }
  
  return undefined
}

/**
 * 综合文章生成函数 - 执行完整的4步流程
 */
export async function generateArticleWithEvidence(
  outline: BlogOutline,
  keyword: string,
  targetLanguage: string = '英语',
  targetMarket: string = '美国',
  onProgress?: (step: number, message: string) => void
): Promise<{
  requirements: SectionEvidenceRequirement[]
  searchResults: ExtendedSearchResult[]
  extractedContents: ExtractedContent[]
  evidence: Evidence[]
}> {
  try {
    console.log('🚀 开始执行文章生成流程...')
    
    // 步骤1：匹配证据类型
    onProgress?.(1, '正在分析大纲并匹配证据类型...')
    const requirements = await matchEvidenceTypes(outline, keyword)
    
    // 步骤2：搜索目标证据
    onProgress?.(2, '正在搜索相关证据来源...')
    const searchResults = await searchTargetEvidence(requirements, targetLanguage, targetMarket)
    
    // 步骤3：抓取网站内容
    onProgress?.(3, '正在抓取网站内容...')
    const extractedContents = await extractWebsiteContent(searchResults)
    
    // 步骤4：分析提取证据
    onProgress?.(4, '正在分析并提取目标证据...')
    const evidence = await analyzeAndExtractEvidence(extractedContents, requirements, keyword)
    
    console.log('🎉 文章生成流程完成！')
    
    return {
      requirements,
      searchResults,
      extractedContents,
      evidence
    }
    
  } catch (error) {
    console.error('❌ 文章生成流程失败:', error)
    throw error
  }
}
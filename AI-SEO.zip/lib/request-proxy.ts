/**
 * 智能网络代理调度器
 * 提供统一的外部API请求接口，支持代理自动切换和详细错误处理
 */

import { HttpsProxyAgent } from 'https-proxy-agent';
import { HttpProxyAgent } from 'http-proxy-agent';

// 自定义错误类型
export class NetworkError extends Error {
  public readonly attemptedMethods: string[];
  public readonly originalErrors: Error[];
  public readonly userSuggestion: string;

  constructor(
    message: string,
    attemptedMethods: string[],
    originalErrors: Error[],
    userSuggestion: string
  ) {
    super(message);
    this.name = 'NetworkError';
    this.attemptedMethods = attemptedMethods;
    this.originalErrors = originalErrors;
    this.userSuggestion = userSuggestion;
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message,
      attemptedMethods: this.attemptedMethods,
      originalErrors: this.originalErrors.map(e => ({
        name: e.name,
        message: e.message
      })),
      userSuggestion: this.userSuggestion
    };
  }
}

// 网络配置接口
interface NetworkConfig {
  proxyUrl?: string;
  timeout?: number;
  retries?: number;
  directFallback?: boolean;
}

// 请求尝试结果接口
interface RequestAttempt {
  method: string;
  success: boolean;
  error?: Error;
  responseTime?: number;
}

/**
 * 获取代理配置
 */
function getProxyConfig(): NetworkConfig {
  const httpsProxy = process.env.HTTPS_PROXY || process.env.https_proxy;
  const httpProxy = process.env.HTTP_PROXY || process.env.http_proxy;
  
  // 优先使用 HTTPS_PROXY，回退到 HTTP_PROXY
  const proxyUrl = httpsProxy || httpProxy;
  
  console.log('INFO: Proxy configuration detected:', {
    httpsProxy: httpsProxy ? '[REDACTED]' : 'not set',
    httpProxy: httpProxy ? '[REDACTED]' : 'not set',
    finalProxy: proxyUrl ? '[REDACTED]' : 'not set'
  });

  return {
    proxyUrl,
    timeout: 45000, // 增加到45秒超时
    retries: 2, // 增加重试次数
    directFallback: true
  };
}

/**
 * 创建代理Agent
 */
function createProxyAgent(proxyUrl: string, targetUrl: string): any {
  const isHttps = targetUrl.startsWith('https://');
  
  if (isHttps) {
    return new HttpsProxyAgent(proxyUrl);
  } else {
    return new HttpProxyAgent(proxyUrl);
  }
}

/**
 * 执行单次请求尝试
 */
async function attemptRequest(
  url: string, 
  options: RequestInit & { agent?: any } = {},
  method: string
): Promise<{ response: Response; responseTime: number }> {
  const startTime = Date.now();
  
  try {
    console.log(`INFO: Attempting request via ${method} to ${new URL(url).hostname}`);
    
    const requestOptions: RequestInit & { agent?: any } = {
      ...options,
      signal: AbortSignal.timeout(45000) // 45秒超时
    };

    const response = await fetch(url, requestOptions);
    const responseTime = Date.now() - startTime;
    
    console.log(`SUCCESS: Request via ${method} completed (${response.status}) in ${responseTime}ms`);
    
    return { response, responseTime };
  } catch (error) {
    const responseTime = Date.now() - startTime;
    console.log(`FAILED: Request via ${method} failed after ${responseTime}ms:`, error);
    throw error;
  }
}

/**
 * 智能代理 fetch 函数
 * 自动尝试代理和直连，并提供详细的错误信息
 */
export async function proxiedFetch(
  url: string, 
  options: RequestInit = {}
): Promise<Response> {
  const config = getProxyConfig();
  const attempts: RequestAttempt[] = [];
  let lastError: Error | null = null;

  console.log(`INFO: Starting proxied fetch for ${new URL(url).hostname}`);

  // 策略1: 如果有代理配置，优先尝试代理
  if (config.proxyUrl && config.directFallback) {
    try {
      const agent = createProxyAgent(config.proxyUrl, url);
      const requestOptions = {
        ...options,
        agent
      };

      const { response, responseTime } = await attemptRequest(url, requestOptions, 'proxy');
      
      attempts.push({
        method: `proxy (${config.proxyUrl})`,
        success: true,
        responseTime
      });

      console.log(`SUCCESS: Proxy request succeeded on first attempt`);
      return response;
    } catch (error) {
      lastError = error as Error;
      attempts.push({
        method: `proxy (${config.proxyUrl})`,
        success: false,
        error: lastError
      });

      console.log(`WARN: Proxy request failed, attempting direct connection...`);
    }
  }

  // 策略2: 直连尝试
  try {
    const requestOptions = { ...options };
    // 确保不使用代理
    delete (requestOptions as any).agent;

    const { response, responseTime } = await attemptRequest(url, requestOptions, 'direct');
    
    attempts.push({
      method: 'direct connection',
      success: true,
      responseTime
    });

    console.log(`SUCCESS: Direct connection succeeded`);
    return response;
  } catch (error) {
    lastError = error as Error;
    attempts.push({
      method: 'direct connection',
      success: false,
      error: lastError
    });

    console.log(`FAILED: Direct connection also failed`);
  }

  // 所有方法都失败了，抛出详细错误
  const attemptedMethods = attempts.map(a => a.method);
  const originalErrors = attempts.map(a => a.error).filter(Boolean) as Error[];
  
  let userSuggestion = '';
  if (config.proxyUrl) {
    userSuggestion = '请检查您的代理设置是否正确，或尝试关闭代理。如果问题持续，请检查网络连接。';
  } else {
    userSuggestion = '请检查您的网络连接是否正常。如果您在使用代理，请确保代理配置正确。';
  }

  const networkError = new NetworkError(
    `所有网络请求方法均失败。尝试过的方法: ${attemptedMethods.join(', ')}`,
    attemptedMethods,
    originalErrors,
    userSuggestion
  );

  console.error('ERROR: All network methods failed:', {
    url: new URL(url).hostname,
    attempts: attempts.map(a => ({
      method: a.method,
      success: a.success,
      error: a.error?.message,
      responseTime: a.responseTime
    }))
  });

  throw networkError;
}

/**
 * 为OpenAI SDK创建自定义的fetch函数
 */
export function createOpenAIFetch() {
  return async (url: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    return proxiedFetch(url.toString(), init);
  };
}

/**
 * 为Anthropic SDK创建自定义的fetch函数
 */
export function createAnthropicFetch() {
  return async (url: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    return proxiedFetch(url.toString(), init);
  };
}

/**
 * 检查网络连接状态
 */
export async function checkNetworkStatus(): Promise<{
  direct: boolean;
  proxy: boolean;
  proxyUrl?: string;
}> {
  const config = getProxyConfig();
  const testUrl = 'https://api.openai.com/v1/models'; // 使用OpenAI API作为测试端点
  
  const result = {
    direct: false,
    proxy: false,
    proxyUrl: config.proxyUrl
  };

  // 测试直连
  try {
    await attemptRequest(testUrl, { method: 'HEAD' }, 'direct-test');
    result.direct = true;
    console.log('INFO: Direct connection test passed');
  } catch (error) {
    console.log('INFO: Direct connection test failed');
  }

  // 测试代理（如果配置了）
  if (config.proxyUrl) {
    try {
      const agent = createProxyAgent(config.proxyUrl, testUrl);
      await attemptRequest(testUrl, { method: 'HEAD', agent }, 'proxy-test');
      result.proxy = true;
      console.log('INFO: Proxy connection test passed');
    } catch (error) {
      console.log('INFO: Proxy connection test failed');
    }
  }

  return result;
}

/**
 * 获取当前网络配置信息（用于调试）
 */
export function getNetworkInfo() {
  const config = getProxyConfig();
  return {
    hasProxy: !!config.proxyUrl,
    proxyMasked: config.proxyUrl ? config.proxyUrl.replace(/\/\/.*@/, '//***:***@') : null,
    timeout: config.timeout,
    directFallback: config.directFallback
  };
} 
import { genAI, AI_MODEL } from './config';

/**
 * 从AI知识库生成与关键词相关的知识点
 * @param keyword - 主关键词
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @param selectedIdea - 选中的博客创意
 * @param customIdea - 自定义创意
 * @param knowledgeSource - 用户提供的知识来源内容
 * @returns AI生成的知识点数组
 */
export async function generateAIKnowledge(
  keyword: string,
  targetMarket: string = '美国',
  targetLanguage: string = '英语',
  selectedIdea?: string,
  customIdea?: string,
  knowledgeSource?: string
): Promise<string[]> {
  try {
    console.log('开始从AI知识库生成相关知识点');
    
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建博客主题描述
    const blogTopic = selectedIdea || customIdea || `关于${keyword}的内容`;
    
    // 构建知识来源部分
    const knowledgeSourceSection = knowledgeSource && knowledgeSource.trim() 
      ? `\n**用户提供的知识来源：**\n${knowledgeSource.trim()}\n*请结合以上用户提供的知识来源内容，生成更准确和相关的知识点*\n`
      : '';
    
    const prompt = `
作为一个专业的内容专家和知识库，请针对以下信息生成相关的知识点：

**基本信息：**
- 主关键词：${keyword}
- 目标市场：${targetMarket}
- 目标语言：${targetLanguage}
- 博客主题：${blogTopic}
${knowledgeSourceSection}
请基于您的知识库${knowledgeSource ? '和用户提供的知识来源' : ''}，生成15-20个与该主题相关的实用知识点，包括：

1. **核心概念和定义**：
   - ${keyword}的基本定义和核心概念
   - 相关的重要术语和专业概念
   - 行业标准和最佳实践

2. **实际应用和技巧**：
   - 实施方法和具体步骤
   - 常见的使用技巧和策略
   - 工具和资源推荐

3. **市场趋势和数据**：
   - ${targetMarket}市场的相关趋势
   - 行业统计数据和研究发现
   - 未来发展预测

4. **常见问题和解决方案**：
   - 用户经常遇到的问题
   - 实用的解决方案和建议
   - 避免常见错误的方法

5. **案例和示例**：
   - 成功案例和实例
   - 具体的应用场景
   - 行业领先的做法

${knowledgeSource ? `
**特别要求：**
- 优先整合用户提供的知识来源中的专业信息
- 确保生成的知识点与用户知识来源保持一致
- 扩展和深化知识来源中提到的概念和方法
` : ''}

请用以下JSON格式返回：
{
  "knowledgePoints": [
    "具体的知识点1",
    "具体的知识点2",
    "具体的知识点3",
    ...
  ]
}

要求：
- 知识点要具体、实用、有价值
- 适合${targetLanguage}表达和${targetMarket}市场
- 与博客主题高度相关
- 包含可操作的建议和指导
- 涵盖不同层次的知识深度
${knowledgeSource ? '- 充分利用用户提供的知识来源内容' : ''}
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI知识库原始响应:', text);
    
    try {
      // 尝试解析JSON响应
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.knowledgePoints && Array.isArray(aiResponse.knowledgePoints)) {
        console.log('成功从AI知识库生成知识点，数量:', aiResponse.knowledgePoints.length);
        return aiResponse.knowledgePoints;
      }
    } catch (parseError) {
      console.warn('解析AI知识库JSON响应失败:', parseError);
    }
    
    // 如果解析失败，从文本中提取知识点
    const fallbackKnowledge = extractKnowledgeFromText(text, keyword);
    console.log('使用备用方法提取的AI知识点数量:', fallbackKnowledge.length);
    return fallbackKnowledge;
    
  } catch (error) {
    console.error('AI知识库生成失败:', error);
    
    // 返回基础的知识点作为备用
    const topic = selectedIdea || customIdea || `关于${keyword}的内容`;
    return generateBasicKnowledge(keyword, topic);
  }
}

/**
 * 从文本中提取知识点的备用方法
 * @param text - 文本内容
 * @param keyword - 关键词
 * @returns 提取的知识点
 */
function extractKnowledgeFromText(text: string, keyword: string): string[] {
  const knowledge: string[] = [];
  
  // 按句子分割
  const sentences = text.split(/[。！？.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 10 && s.length < 200);
  
  // 提取包含关键词或重要信息的句子
  sentences.forEach(sentence => {
    if (sentence.toLowerCase().includes(keyword.toLowerCase()) ||
        sentence.includes('重要') ||
        sentence.includes('关键') ||
        sentence.includes('核心') ||
        sentence.includes('essential') ||
        sentence.includes('important') ||
        sentence.includes('key')) {
      knowledge.push(sentence);
    }
  });
  
  // 限制数量并去重
  return Array.from(new Set(knowledge)).slice(0, 15);
}

/**
 * 生成基础知识点的备用方法
 * @param keyword - 关键词
 * @param topic - 主题
 * @returns 基础知识点数组
 */
function generateBasicKnowledge(keyword: string, topic: string): string[] {
  return [
    `${keyword}的基本定义和核心概念`,
    `${keyword}的主要应用场景和用途`,
    `${keyword}的关键特性和优势`,
    `实施${keyword}的基本步骤和方法`,
    `${keyword}的最佳实践和行业标准`,
    `使用${keyword}时需要注意的关键事项`,
    `${keyword}的常见问题和解决方案`,
    `${keyword}与相关技术的集成方法`,
    `${keyword}的性能优化技巧`,
    `${keyword}的未来发展趋势`,
    `${keyword}在不同行业中的应用案例`,
    `选择合适的${keyword}工具和平台`,
    `${keyword}的成本效益分析`,
    `${keyword}的安全性和可靠性考虑`,
    `${keyword}团队和技能要求`
  ];
} 
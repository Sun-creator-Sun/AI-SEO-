/**
 * HTML转换工具 - 将Markdown内容转换为WordPress友好的HTML格式
 */

/**
 * 将Markdown内容转换为WordPress友好的HTML
 * @param markdownContent Markdown内容
 * @param customAnchorLinks 自定义锚文本链接
 * @returns HTML字符串
 */
export function convertMarkdownToWordPressHTML(
  markdownContent: string, 
  customAnchorLinks?: Array<{url: string; anchor: string}>
): string {
  // 清理内容
  let content = cleanMarkdownContent(markdownContent);
  
  // 应用自定义锚文本链接
  content = applyCustomAnchorLinks(content, customAnchorLinks);
  
  // 转换为HTML
  let html = content;
  
  // 处理标题
  html = html
    .replace(/^### (.*$)/gim, '<h3 class="wp-block-heading">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="wp-block-heading">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="wp-block-heading">$1</h1>');
  
  // 处理段落
  html = html.replace(/^(?!<[h|u|o|b|t|p])(.+)$/gim, '<p class="has-medium-font-size">$1</p>');
  
  // 处理列表
  html = html
    .replace(/^\* (.*$)/gim, '<li>$1</li>')
    .replace(/^- (.*$)/gim, '<li>$1</li>')
    .replace(/^\d+\. (.*$)/gim, '<li>$1</li>');
  
  // 包装列表
  html = wrapListItems(html);
  
  // 处理强调
  html = html
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/__(.*?)__/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/_(.*?)_/g, '<em>$1</em>');
  
  // 处理代码
  html = html
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/```([\s\S]*?)```/g, '<pre class="wp-block-code"><code>$1</code></pre>');
  
  // 处理链接
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="wp-block-button__link">$1</a>');
  
  // 处理图片
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="aligncenter size-full wp-image-1" />');
  
  // 处理引用
  html = html.replace(/^> (.*$)/gim, '<blockquote class="wp-block-quote">$1</blockquote>');
  
  // 处理分隔线
  html = html.replace(/^---$/gim, '<hr />');
  
  // 处理表格（简单实现）
  html = processTables(html);
  
  // 清理多余的空白和换行
  html = cleanHTML(html);
  
  return html;
}

/**
 * 包装列表项为完整的列表结构
 */
function wrapListItems(html: string): string {
  // 检测连续的li元素并包装为ul或ol
  const lines = html.split('\n');
  const result: string[] = [];
  let inList = false;
  let listType = 'ul';
  let listItems: string[] = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    if (line.trim().startsWith('<li>')) {
      if (!inList) {
        inList = true;
        listItems = [];
      }
      listItems.push(line.trim());
    } else {
      if (inList) {
        // 结束当前列表
        const listTag = listType === 'ol' ? 'ol' : 'ul';
        result.push(`<${listTag} class="wp-block-list">`);
        result.push(...listItems);
        result.push(`</${listTag}>`);
        inList = false;
        listItems = [];
      }
      result.push(line);
    }
  }
  
  // 处理最后的列表
  if (inList && listItems.length > 0) {
    const listTag = listType === 'ol' ? 'ol' : 'ul';
    result.push(`<${listTag} class="wp-block-list">`);
    result.push(...listItems);
    result.push(`</${listTag}>`);
  }
  
  return result.join('\n');
}

/**
 * 处理Markdown表格
 */
function processTables(html: string): string {
  const tableRegex = /\|(.+)\|\n\|[\s\-:|]+\|\n((?:\|.+\|\n?)+)/g;
  
  return html.replace(tableRegex, (match, header, body) => {
    const headerCells = header.split('|').map((cell: string) => cell.trim()).filter(Boolean);
    const bodyRows = body.trim().split('\n').map((row: string) => 
      row.split('|').map((cell: string) => cell.trim()).filter(Boolean)
    );
    
    let tableHTML = '<table class="wp-block-table">\n<thead>\n<tr>\n';
    headerCells.forEach((cell: string) => {
      tableHTML += `<th>${cell}</th>\n`;
    });
    tableHTML += '</tr>\n</thead>\n<tbody>\n';
    
    bodyRows.forEach((row: string[]) => {
      tableHTML += '<tr>\n';
      row.forEach((cell: string) => {
        tableHTML += `<td>${cell}</td>\n`;
      });
      tableHTML += '</tr>\n';
    });
    
    tableHTML += '</tbody>\n</table>';
    return tableHTML;
  });
}

/**
 * 清理Markdown内容
 */
function cleanMarkdownContent(content: string): string {
  return content
    // 移除多余的换行符
    .replace(/\n{3,}/g, '\n\n')
    // 移除行首行尾空白
    .trim();
}

/**
 * 应用自定义锚文本链接
 */
function applyCustomAnchorLinks(
  text: string,
  customAnchorLinks: Array<{ url: string; anchor: string }> | undefined
): string {
  if (!customAnchorLinks || customAnchorLinks.length === 0) {
    return text;
  }

  let result = text;
  
  customAnchorLinks.forEach(({ url, anchor }) => {
    if (anchor && url) {
      // 转义正则表达式特殊字符
      const escapedAnchor = anchor.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`(${escapedAnchor})`, 'gi');
      result = result.replace(regex, `[$1](${url})`);
    }
  });

  return result;
}

/**
 * 清理HTML，移除多余的空白和换行
 */
function cleanHTML(html: string): string {
  return html
    // 移除空段落
    .replace(/<p class="has-medium-font-size"><\/p>/g, '')
    // 移除多余的空白
    .replace(/\s+/g, ' ')
    // 移除段落标签之间的空白
    .replace(/<\/p>\s*<p class="has-medium-font-size">/g, '</p>\n<p class="has-medium-font-size">')
    // 移除列表项之间的空白
    .replace(/<\/li>\s*<li>/g, '</li>\n<li>')
    // 移除标题前后的空白
    .replace(/>\s*</g, '>\n<')
    .trim();
}

/**
 * 生成WordPress友好的HTML文档
 */
export function generateWordPressHTMLDocument(
  title: string,
  content: string,
  customAnchorLinks?: Array<{url: string; anchor: string}>
): string {
  const htmlContent = convertMarkdownToWordPressHTML(content, customAnchorLinks);
  
  return `<!-- WordPress HTML Document -->
<!-- 标题: ${title} -->
<!-- 生成时间: ${new Date().toLocaleString('zh-CN')} -->
<!-- 来源: Vertu SEO AI写作工具 -->

${htmlContent}

<!-- 文档结束 -->`;
}

/**
 * 生成纯HTML内容（不包含WordPress特定类）
 */
export function generatePureHTML(
  content: string,
  customAnchorLinks?: Array<{url: string; anchor: string}>
): string {
  let html = convertMarkdownToWordPressHTML(content, customAnchorLinks);
  
  // 移除WordPress特定类
  html = html
    .replace(/class="wp-block-heading"/g, '')
    .replace(/class="has-medium-font-size"/g, '')
    .replace(/class="wp-block-list"/g, '')
    .replace(/class="wp-block-quote"/g, '')
    .replace(/class="wp-block-code"/g, '')
    .replace(/class="wp-block-table"/g, '')
    .replace(/class="wp-block-button__link"/g, '')
    .replace(/class="aligncenter size-full wp-image-1"/g, '');
  
  return html;
} 
import { SearchResult } from './types';
import { SEARCH_API_KEY, SEARCH_ENGINE_ID, convertTimeRangeToDateRestrict } from './config';
import { optimizeSearchQuery, analyzeQueryType } from './search-query-optimizer';

/**
 * 使用Google搜索获取关键词相关的搜索结果
 * @param keyword - 搜索关键词
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @param timeRange - 时间范围
 * @returns 搜索结果数组
 */
export async function searchKeyword(
  keyword: string,
  targetMarket: string = '美国',
  targetLanguage: string = '英语',
  timeRange: string = '任何时候'
): Promise<SearchResult[]> {
  try {
    // 优化搜索查询
    const optimizedQuery = optimizeSearchQuery(keyword, targetLanguage);
    let searchQuery = optimizedQuery.optimized;
    
    console.log(`🔍 查询类型分析:`, {
      original: optimizedQuery.original,
      optimized: optimizedQuery.optimized,
      type: optimizedQuery.type.type,
      confidence: optimizedQuery.type.confidence,
      description: optimizedQuery.type.description
    });
    
    // 根据目标语言调整搜索查询
    if (targetLanguage === '中文') {
      searchQuery = `${searchQuery} 中文`;
    }
    
    // 根据目标市场调整搜索区域
    let gl = 'us'; // 默认美国
    if (targetMarket === '中国') {
      gl = 'cn';
    } else if (targetMarket === '英国') {
      gl = 'uk';
    } else if (targetMarket === '日本') {
      gl = 'jp';
    }

    // 直接调用Google Custom Search API（需要先设置API密钥的referrer）
    const searchUrl = new URL('https://www.googleapis.com/customsearch/v1');
    searchUrl.searchParams.append('key', SEARCH_API_KEY);
    searchUrl.searchParams.append('cx', SEARCH_ENGINE_ID);
    searchUrl.searchParams.append('q', searchQuery);
    searchUrl.searchParams.append('num', '10');
    searchUrl.searchParams.append('gl', gl);
    if (targetLanguage === '中文') {
      searchUrl.searchParams.append('lr', 'lang_zh');
    } else {
      searchUrl.searchParams.append('lr', 'lang_en');
    }

    // 添加时间范围过滤
    const dateRestrict = convertTimeRangeToDateRestrict(timeRange);
    if (dateRestrict) {
      searchUrl.searchParams.append('dateRestrict', dateRestrict);
    }

    // 调用Google Custom Search API
    console.log('正在调用Google Search API:', searchUrl.toString());
    const response = await fetch(searchUrl.toString());
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Google Search API错误详情:', errorText);
      throw new Error(`Google Search API错误: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const items = data.items || [];
    const searchResults: SearchResult[] = [];

    // 转换搜索结果格式
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.title && item.link && item.snippet) {
        searchResults.push({
          title: item.title,
          url: item.link,
          snippet: item.snippet,
          originalIndex: i + 1 // 从1开始编号
        });
      }
    }

    // 如果结果不足20个，进行第二次搜索
    if (searchResults.length < 20) {
      try {
        const secondSearchUrl = new URL('https://www.googleapis.com/customsearch/v1');
        secondSearchUrl.searchParams.append('key', SEARCH_API_KEY);
        secondSearchUrl.searchParams.append('cx', SEARCH_ENGINE_ID);
        secondSearchUrl.searchParams.append('q', `${searchQuery} tools software`);
        secondSearchUrl.searchParams.append('num', '10');
        secondSearchUrl.searchParams.append('start', '11');
        secondSearchUrl.searchParams.append('gl', gl);
        if (targetLanguage === '中文') {
          secondSearchUrl.searchParams.append('lr', 'lang_zh');
        } else {
          secondSearchUrl.searchParams.append('lr', 'lang_en');
        }

        // 添加时间范围过滤
        if (dateRestrict) {
          secondSearchUrl.searchParams.append('dateRestrict', dateRestrict);
        }

        const secondResponse = await fetch(secondSearchUrl.toString());
        
        if (secondResponse.ok) {
          const secondData = await secondResponse.json();
          const secondItems = secondData.items || [];
          
          for (let j = 0; j < secondItems.length; j++) {
            const item = secondItems[j];
            if (item.title && item.link && item.snippet && searchResults.length < 20) {
              searchResults.push({
                title: item.title,
                url: item.link,
                snippet: item.snippet,
                originalIndex: items.length + j + 1 // 继续之前的编号
              });
            }
          }
        }
      } catch (secondError) {
        console.warn('第二次搜索失败:', secondError);
      }
    }

    // 如果API搜索失败或结果不足，使用备用结果
    if (searchResults.length === 0) {
      console.warn('Google搜索API无结果，使用备用数据');
      return getFallbackResults(keyword);
    }

    console.log(`成功获取 ${searchResults.length} 个搜索结果`);
    return searchResults;
    
  } catch (error) {
    console.error('Google搜索API调用失败:', error);
    
    // 检查是否是403错误（权限问题）
    if (error instanceof Error && error.message.includes('403')) {
      console.warn('API权限问题，可能需要：\n1. 启用Custom Search API\n2. 检查API密钥权限\n3. 确认搜索引擎ID正确');
    }
    
    // 如果API调用失败，返回备用结果
    console.log('使用备用搜索结果');
    return getFallbackResults(keyword);
  }
}

/**
 * 获取备用搜索结果（当API调用失败时使用）
 * @param keyword - 搜索关键词
 * @returns 备用搜索结果
 */
function getFallbackResults(keyword: string): SearchResult[] {
  const results = [
      {
        title: `I've Tried 13 AI SEO Tools (Paid & Free) - Here's What I Found`,
        url: `https://neilpatel.com/blog/ai-seo-tools-review`,
        snippet: `Honestly, not every AI SEO optimization tool delivers on its promise. Most tools provide useless advice and AI-generated content that lacks depth and originality.`
      },
      {
        title: `SEO AI: The #1 AI toolkit for SEO teams`,
        url: `https://seoai.com`,
        snippet: `Stop wasting time on manual work or generic AI tools that lack SEO data. Our AI Content Detector, AI Paraphrasing Tool, AI Content Generator, and more.`
      }
    ];
    
    // 为备用结果添加原始索引
    return results.map((result, index) => ({
      ...result,
      originalIndex: index + 1
    }));
}

/**
 * 专门用于文章生成证据搜索的函数
 * 一次性处理多个搜索查询，避免重复搜索
 * @param queries - 搜索查询数组
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @param timeRange - 时间范围
 * @returns 所有搜索结果的合集
 */
export async function searchEvidenceQueries(
  queries: string[],
  targetMarket: string = '美国',
  targetLanguage: string = '英语',
  timeRange: string = '过去一年'
): Promise<SearchResult[]> {
  try {
    console.log(`🔍 开始批量搜索 ${queries.length} 个证据查询...`)
    
    const allResults: SearchResult[] = []
    let totalSearchCount = 0
    
    // 根据目标市场调整搜索区域
    let gl = 'us'; // 默认美国
    if (targetMarket === '中国') {
      gl = 'cn';
    } else if (targetMarket === '英国') {
      gl = 'uk';
    } else if (targetMarket === '日本') {
      gl = 'jp';
    }

    // 设置语言参数
    const lr = targetLanguage === '中文' ? 'lang_zh' : 'lang_en';
    
    // 添加时间范围过滤
    const dateRestrict = convertTimeRangeToDateRestrict(timeRange);
    
    // 逐个处理搜索查询，避免并发过多导致限制
    for (let i = 0; i < queries.length; i++) {
      const query = queries[i];
      
      try {
        console.log(`🔍 正在搜索 (${i + 1}/${queries.length}): ${query}`)
        
        // 构建搜索URL
        const searchUrl = new URL('https://www.googleapis.com/customsearch/v1');
        searchUrl.searchParams.append('key', SEARCH_API_KEY);
        searchUrl.searchParams.append('cx', SEARCH_ENGINE_ID);
        searchUrl.searchParams.append('q', query);
        searchUrl.searchParams.append('num', '10'); // 每个查询获取10个结果
        searchUrl.searchParams.append('gl', gl);
        searchUrl.searchParams.append('lr', lr);
        
        if (dateRestrict) {
          searchUrl.searchParams.append('dateRestrict', dateRestrict);
        }

        // 调用Google Custom Search API
        const response = await fetch(searchUrl.toString());
        totalSearchCount++;
        
        if (!response.ok) {
          console.warn(`搜索查询失败: ${query} - ${response.status} ${response.statusText}`);
          continue;
        }

        const data = await response.json();
        const items = data.items || [];
        
        // 转换搜索结果格式并添加查询来源信息
        for (let j = 0; j < items.length; j++) {
          const item = items[j];
          if (item.title && item.link && item.snippet) {
            allResults.push({
              title: item.title,
              url: item.link,
              snippet: item.snippet,
              originalIndex: allResults.length + 1, // 全局索引
              sourceQuery: query // 记录来源查询
            });
          }
        }
        
        console.log(`✅ 查询 "${query}" 获得 ${items.length} 个结果`);
        
        // 避免请求过于频繁，每次搜索后暂停1秒
        if (i < queries.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
      } catch (error) {
        console.warn(`⚠️ 搜索查询失败: ${query}`, error);
        continue;
      }
    }
    
    // 去重：相同URL的结果只保留第一个
    const uniqueResults = removeDuplicateByUrl(allResults);
    
    console.log(`🎉 批量搜索完成！`)
    console.log(`📊 搜索统计:`)
    console.log(`   - 总查询数: ${queries.length}`)
    console.log(`   - 实际搜索次数: ${totalSearchCount}`)
    console.log(`   - 原始结果数: ${allResults.length}`)
    console.log(`   - 去重后结果数: ${uniqueResults.length}`)
    
    return uniqueResults;
    
  } catch (error) {
    console.error('批量搜索失败:', error);
    
    // 如果API调用失败，返回空数组
    console.log('批量搜索失败，返回空结果');
    return [];
  }
}

/**
 * 根据URL去重搜索结果
 * @param results - 搜索结果数组
 * @returns 去重后的结果数组
 */
function removeDuplicateByUrl(results: SearchResult[]): SearchResult[] {
  const seen = new Set<string>();
  return results.filter(result => {
    if (seen.has(result.url)) {
      return false;
    }
    seen.add(result.url);
    return true;
  });
} 
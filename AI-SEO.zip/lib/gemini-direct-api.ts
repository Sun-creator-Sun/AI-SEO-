import https from 'https';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { getProxyConfig, tryMultipleProxies } from './proxy-helper';

/**
 * Google Generative AI API 响应接口
 */
interface GenerateContentResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
    index: number;
  }>;
  promptFeedback?: {
    safetyRatings: Array<{
      category: string;
      probability: string;
    }>;
  };
}

/**
 * 直接调用Google Generative AI API的函数
 * 使用原生Node.js https模块，先尝试直连，失败后使用代理
 * @param apiKey Google API密钥
 * @param model 模型名称
 * @param prompt 提示词
 * @param generationConfig 可选的生成配置，包括responseSchema等
 * @param maxRetries 最大重试次数
 * @returns Promise<{success: boolean, data?: any, error?: string, proxyUsed?: string}>
 */
export async function callGeminiDirectly(
  apiKey: string, 
  model: string, 
  prompt: string,
  generationConfig?: any,
  maxRetries: number = 2
): Promise<{success: boolean, data?: any, error?: string, proxyUsed?: string}> {
  
  console.log('🚀 直接调用Google Generative AI API...');
  console.log('🤖 模型:', model);
  console.log('📝 提示词长度:', prompt.length);
  
  // 构建API URL和请求体
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  
  const defaultGenerationConfig = {
    temperature: 0.3,
    topK: 20,
    topP: 0.8,
    maxOutputTokens: 2048,
  };
  
  const requestBody = {
    contents: [{
      parts: [{
        text: prompt
      }]
    }],
    generationConfig: generationConfig || defaultGenerationConfig,
    safetySettings: [
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_ONLY_HIGH'
      },
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_ONLY_HIGH'
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_ONLY_HIGH'
      },
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_ONLY_HIGH'
      }
    ]
  };
  
  const postData = JSON.stringify(requestBody);
  
  // 先尝试直连
  console.log('🌐 首先尝试直连...');
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    console.log(`🔄 直连尝试第 ${attempt}/${maxRetries} 次...`);
    
    try {
      const directResult = await makeHttpsRequest(apiUrl, postData, undefined);
      
      if (directResult.success) {
        console.log('✅ 直连API调用成功');
        
        const response = directResult.data as GenerateContentResponse;
        
        if (response.candidates && response.candidates.length > 0) {
          const text = response.candidates[0].content.parts[0].text;
          console.log('📄 响应文本长度:', text.length);
          
          return {
            success: true,
            data: text,
            proxyUsed: undefined
          };
        } else {
          console.log('⚠️ 直连API返回空结果');
          // 继续重试直连
        }
      } else {
        console.log(`⚠️ 直连第${attempt}次调用失败:`, directResult.error);
      }
    } catch (error) {
      console.log(`⚠️ 直连第${attempt}次调用异常:`, error);
    }
    
    // 直连重试间隔
    if (attempt < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
  
  // 直连失败，尝试使用代理
  const proxyConfig = getProxyConfig();
  
  if (proxyConfig.detected) {
    console.log(`🔧 直连失败，尝试使用环境变量代理 (${proxyConfig.source}):`, proxyConfig.proxy);
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      console.log(`🔄 环境变量代理尝试第 ${attempt}/${maxRetries} 次...`);
      
      try {
        const proxyResult = await makeHttpsRequest(apiUrl, postData, proxyConfig.proxy);
        
        if (proxyResult.success) {
          console.log('✅ 环境变量代理API调用成功');
          
          const response = proxyResult.data as GenerateContentResponse;
          
          if (response.candidates && response.candidates.length > 0) {
            const text = response.candidates[0].content.parts[0].text;
            console.log('📄 响应文本长度:', text.length);
            
          return {
              success: true,
              data: text,
            proxyUsed: proxyConfig.proxy
          };
          } else {
            console.log('⚠️ 环境变量代理API返回空结果');
          }
        } else {
          console.log(`⚠️ 环境变量代理第${attempt}次调用失败:`, proxyResult.error);
        }
      } catch (error) {
        console.log(`⚠️ 环境变量代理第${attempt}次调用异常:`, error);
        }
        
      // 环境变量代理重试间隔
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
  }
  
  // 尝试常见代理
  console.log('🔧 尝试常见代理配置...');
  
  try {
    // 使用 tryMultipleProxies 但需要适配返回格式
    const commonProxies = ['http://127.0.0.1:7890', 'http://127.0.0.1:1087', 'http://127.0.0.1:8080', 'http://127.0.0.1:10808'];
    
    for (const proxy of commonProxies) {
      console.log(`🔄 尝试常见代理: ${proxy}`);
      
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        console.log(`🔄 常见代理 ${proxy} 尝试第 ${attempt}/${maxRetries} 次...`);
        
        try {
          const proxyResult = await makeHttpsRequest(apiUrl, postData, proxy);
      
          if (proxyResult.success) {
            console.log(`✅ 常见代理 ${proxy} API调用成功`);
            
            const response = proxyResult.data as GenerateContentResponse;
            
            if (response.candidates && response.candidates.length > 0) {
              const text = response.candidates[0].content.parts[0].text;
              console.log('📄 响应文本长度:', text.length);
              
        return {
                success: true,
                data: text,
                proxyUsed: proxy
              };
            } else {
              console.log(`⚠️ 常见代理 ${proxy} API返回空结果`);
              break; // 跳出重试循环，尝试下一个代理
            }
          } else {
            console.log(`⚠️ 常见代理 ${proxy} 第${attempt}次调用失败:`, proxyResult.error);
          }
        } catch (error) {
          console.log(`⚠️ 常见代理 ${proxy} 第${attempt}次调用异常:`, error);
      }
      
        // 常见代理重试间隔
        if (attempt < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
    }
  } catch (error) {
    console.log('❌ 常见代理调用异常:', error);
  }
  
  // 所有方法都失败了
  console.error('❌ 直连和所有代理都失败了');
  
  return {
    success: false,
    error: '直连和所有代理都失败了，建议: 1.检查网络连接 2.设置环境变量 HTTPS_PROXY="http://127.0.0.1:10808" 3.确认代理软件正在运行',
    proxyUsed: undefined
  };
}

/**
 * 使用原生Node.js https模块发送请求
 * @param url 请求URL
 * @param postData 请求体数据
 * @param proxyUrl 代理URL（可选）
 * @returns Promise<{success: boolean, data?: any, error?: string}>
 */
function makeHttpsRequest(
  url: string, 
  postData: string, 
  proxyUrl?: string
): Promise<{success: boolean, data?: any, error?: string}> {
  
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options: any = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname + urlObj.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
        'User-Agent': 'vertu-seo-direct-api/1.0'
      },
      timeout: 30000, // 30秒超时
    };

    // 如果有代理，使用ClashX代理
    if (proxyUrl) {
      console.log('🔧 使用ClashX代理:', proxyUrl);
      options.agent = new HttpsProxyAgent(proxyUrl);
    } else {
      console.log('🌐 直接连接（无代理）');
    }

    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            const jsonData = JSON.parse(data);
            resolve({
              success: true,
              data: jsonData
            });
          } else {
            console.log('❌ HTTP错误状态:', res.statusCode, res.statusMessage);
            console.log('📄 错误响应:', data.substring(0, 500));
            resolve({
              success: false,
              error: `HTTP ${res.statusCode}: ${res.statusMessage}`
            });
          }
        } catch (parseError) {
          console.log('❌ 响应解析失败:', parseError);
          resolve({
            success: false,
            error: '响应解析失败: ' + data.substring(0, 200)
          });
        }
      });
    });

    req.on('error', (error) => {
      console.log('❌ 请求错误:', error.message);
      resolve({
        success: false,
        error: error.message
      });
    });

    req.on('timeout', () => {
      req.destroy();
      console.log('❌ 请求超时');
      resolve({
        success: false,
        error: '请求超时'
      });
    });

    // 发送请求体
    req.write(postData);
    req.end();
  });
}

/**
 * 使用示例：
 * 
 * // 1. 基本文本生成（不强制JSON）
 * const result1 = await callGeminiDirectly(apiKey, model, "写一首诗");
 * 
 * // 2. SEO分析（强制JSON输出）
 * const seoConfig = {
 *   temperature: 0.3,
 *   responseMimeType: "application/json",
 *   responseSchema: {
 *     type: "object",
 *     properties: {
 *       brand: { type: "string" },
 *       products: { type: "array", items: { type: "string" } }
 *     }
 *   }
 * };
 * const result2 = await callGeminiDirectly(apiKey, model, prompt, seoConfig);
 * 
 * // 3. 代码生成（不同温度设置）
 * const codeConfig = {
 *   temperature: 0.1,
 *   maxOutputTokens: 4096
 * };
 * const result3 = await callGeminiDirectly(apiKey, model, "生成一个React组件", codeConfig);
 */ 
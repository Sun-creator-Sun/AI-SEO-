/**
 * 内容验证工具函数测试示例
 * 用于验证工具类功能是否正常工作
 */

import { 
  validateContentQuality, 
  filterValidContentObjects, 
  isValidContent,
  getContentValidationError,
  validateContentBatch,
  type ContentObject 
} from './content-validation';

// 测试数据
const validContent = "这是一篇很长的有效文章内容，包含了足够的信息来进行分析。这篇文章讨论了SEO优化的各种技术和策略，包括关键词研究、内容优化、链接建设等多个方面。文章详细说明了如何通过科学的方法来提升网站在搜索引擎中的排名。";

const invalidContentShort = "太短";

const invalidContentWithError = "HTTP 404 - 页面未找到：这个页面不存在";

const testContentObjects: ContentObject[] = [
  {
    url: "https://example.com/article1",
    title: "有效文章1",
    content: validContent,
    aiRelevanceScore: 0.9
  },
  {
    url: "https://example.com/article2", 
    title: "无效文章 - 太短",
    content: invalidContentShort,
    aiRelevanceScore: 0.8
  },
  {
    url: "https://example.com/article3",
    title: "无效文章 - 404错误", 
    content: invalidContentWithError,
    aiRelevanceScore: 0.7
  },
  {
    url: "https://example.com/article4",
    title: "有效文章2",
    content: validContent + " 这是另一段补充内容，使文章更加完整和有价值。",
    aiRelevanceScore: 0.95
  }
];

/**
 * 运行内容验证测试
 */
export function runContentValidationTests() {
  console.log('=== 内容验证工具类测试 ===');
  
  // 测试 validateContentQuality
  console.log('\n1. 测试 validateContentQuality:');
  console.log('有效内容:', validateContentQuality(validContent));
  console.log('内容过短:', validateContentQuality(invalidContentShort));
  console.log('包含错误:', validateContentQuality(invalidContentWithError));
  
  // 测试 isValidContent  
  console.log('\n2. 测试 isValidContent:');
  console.log('有效内容:', isValidContent(validContent));
  console.log('内容过短:', isValidContent(invalidContentShort));
  console.log('包含错误:', isValidContent(invalidContentWithError));
  
  // 测试 getContentValidationError
  console.log('\n3. 测试 getContentValidationError:');
  console.log('有效内容错误信息:', getContentValidationError(validContent));
  console.log('内容过短错误信息:', getContentValidationError(invalidContentShort));
  console.log('包含错误的错误信息:', getContentValidationError(invalidContentWithError));
  
  // 测试 filterValidContentObjects
  console.log('\n4. 测试 filterValidContentObjects:');
  const validObjects = filterValidContentObjects(testContentObjects);
  console.log(`输入对象数量: ${testContentObjects.length}`);
  console.log(`有效对象数量: ${validObjects.length}`);
  console.log('有效对象:', validObjects.map(obj => ({ 
    title: obj.title, 
    score: obj.aiRelevanceScore 
  })));
  
  // 测试 validateContentBatch
  console.log('\n5. 测试 validateContentBatch:');
  const contentTexts = testContentObjects.map(obj => obj.content);
  const batchResults = validateContentBatch(contentTexts);
  console.log('批量验证结果:', batchResults);
  
  console.log('\n=== 测试完成 ===');
  
  return {
    validObjects,
    batchResults
  };
}

// 如果需要在浏览器控制台中运行测试，可以这样调用：
// runContentValidationTests(); 
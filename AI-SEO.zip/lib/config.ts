import { GoogleGenerativeAI } from '@google/generative-ai';
import { getCurrentAPIKey } from './api-key-manager';

// Google API配置
export const SEARCH_API_KEY = 'AIzaSyBBKCVGhg-H9eIgtbNGmMsghM2Sr1gHiwY';
// 使用用户新建的搜索引擎ID
export const SEARCH_ENGINE_ID = 'b12e1712f42cb4eb3';

// 动态获取API Key
export function getGENERATIVE_AI_KEY(): string {
  const currentKey = getCurrentAPIKey('gemini');
  if (!currentKey) {
    throw new Error('No available Gemini API key found');
  }
  return currentKey;
}

// Gemini AI实例（动态创建）
export function createGenAI(): GoogleGenerativeAI {
  return new GoogleGenerativeAI(getGENERATIVE_AI_KEY());
}

// AI模型配置
export const AI_MODEL = "gemini-2.5-flash-preview-05-20";

// 注意：genAI 实例已移除，请使用 REST API 方式调用 Gemini
// 如需使用 GoogleGenerativeAI 库，请先安装 @google/generative-ai 包

/**
 * 将时间范围转换为Google API的dateRestrict参数
 * @param timeRange - 时间范围
 * @returns dateRestrict参数值
 */
export function convertTimeRangeToDateRestrict(timeRange: string): string | undefined {
  switch (timeRange) {
    case '过去一小时':
      return 'h1';
    case '过去24小时':
      return 'd1';
    case '过去一周':
      return 'w1';
    case '上个月':
      return 'm1';
    case '过去一年':
      return 'y1';
    case '任何时候':
    default:
      return undefined; // 不添加dateRestrict参数
  }
}

/**
 * 黄金年份规则全局Prompt模块
 * 用于所有AI生成内容的年份强制指令
 */
export function getYearPolicyPrompt(currentYear: number): string {
  return `【系统指令：年份使用黄金规则】\n当前年份为：${currentYear}\n\n1.  **核心规则：** 在你的任何回答中，【严禁】使用除 ${currentYear} 之外的任何其他年份。\n2.  **例外情况：** 除非用户的原始关键词【明确包含】了另一个年份（例如，用户输入“2022年财报分析”），否则必须遵守核心规则。\n3.  **强制应用：** 对于任何关于“趋势”、“预测”、“指南”、“计划”等前瞻性内容，你【必须】将其限定在 ${currentYear} 年的框架内进行阐述。\n4.  **正确示例：** "${currentYear}年十大趋势"、"终极${currentYear}年指南"。\n5.  **错误示例：** "${currentYear + 1}年趋势预测"、"回顾${currentYear - 1}年"。\n\n违反以上规则将导致内容生成失败。现在，请基于以上规则，开始执行以下任务：`;
}

// 导出当前年份常量，供全局使用
export const CURRENT_YEAR = new Date().getFullYear(); 
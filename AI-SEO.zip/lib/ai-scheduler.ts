import { AIModel, AIModelConfig, AICallResult } from './types';

/**
 * AI模型优先级配置
 * 按照成本效益和性能排序：首选 -> 备用
 */
const AI_MODEL_PRIORITY: AIModelConfig[] = [
  {
    name: 'gemini-1.5-flash',
    priority: 1,
    maxTokens: 8192,
    temperature: 0.7
  },
  {
    name: 'gpt-4o',
    priority: 2,
    maxTokens: 4096,
    temperature: 0.7
  },
  {
    name: 'claude-3-sonnet',
    priority: 3,
    maxTokens: 4096,
    temperature: 0.7
  },
  {
    name: 'deepseek-chat',
    priority: 4,
    maxTokens: 4096,
    temperature: 0.7
  }
];

/**
 * 调用单个AI模型（带重试机制）
 * @param model - AI模型配置
 * @param prompt - 输入提示词
 * @param generationConfig - 生成配置
 * @returns AI调用结果
 */
async function callSingleModel(
  model: AIModelConfig,
  prompt: string,
  generationConfig?: any
): Promise<AICallResult> {
  const maxRetries = 2; // 最大重试次数
  let lastError: Error | null = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await attemptSingleModelCall(model, prompt, generationConfig, attempt);
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxRetries) {
        console.log(`WARN: Attempt ${attempt} failed for ${model.name}, retrying... (${lastError.message})`);
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // 递增延迟
      }
    }
  }
  
  // 所有重试都失败了
  const responseTime = Date.now() - Date.now(); // 简化计算
  console.warn(`WARN: Model ${model.name} failed after ${maxRetries} attempts: ${lastError?.message}`);
  
  return {
    success: false,
    model: model.name,
    error: lastError?.message || 'Unknown error after retries',
    responseTime
  };
}

/**
 * 执行单次模型调用
 */
async function attemptSingleModelCall(
  model: AIModelConfig,
  prompt: string,
  generationConfig?: any,
  attemptNumber: number = 1
): Promise<AICallResult> {
  const startTime = Date.now();
  
  try {
    console.log(`INFO: Attempting to use model: ${model.name}...`);
    
    let response;
    const config = {
      temperature: generationConfig?.temperature || model.temperature || 0.7,
      maxOutputTokens: generationConfig?.maxOutputTokens || model.maxTokens || 4096,
      ...generationConfig
    };

    // 根据模型类型调用不同的API
    switch (model.name) {
      case 'gemini-1.5-flash':
        response = await fetch('/api/gemini-generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            generationConfig: config
          })
        });
        break;
        
      case 'gpt-4o':
        response = await fetch('/api/openai-generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            model: 'gpt-4o',
            generationConfig: config
          })
        });
        break;
        
      case 'claude-3-sonnet':
        response = await fetch('/api/claude-generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            model: 'claude-3-sonnet-20240229',
            generationConfig: config
          })
        });
        break;
        
      case 'deepseek-chat':
        response = await fetch('/api/deepseek-generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            model: 'deepseek-chat',
            generationConfig: config
          })
        });
        break;
        
      default:
        throw new Error(`Unsupported model: ${model.name}`);
    }

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    const responseTime = Date.now() - startTime;

    if (result.success && result.data && result.data.trim()) {
      console.log(`SUCCESS: Content generated using ${model.name} (${responseTime}ms)`);
      return {
        success: true,
        content: result.data.trim(),
        model: model.name,
        responseTime
      };
    } else {
      throw new Error(result.error || 'Empty response from API');
    }

  } catch (error) {
    const responseTime = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    console.warn(`WARN: Model ${model.name} failed: ${errorMessage} (${responseTime}ms). Trying next...`);
    
    return {
      success: false,
      model: model.name,
      error: errorMessage,
      responseTime
    };
  }
}

/**
 * 智能AI调度引擎 - 自动故障转移
 * @param prompt - 输入提示词
 * @param generationConfig - 生成配置（可选）
 * @returns 生成的内容
 */
export async function generateWithFailover(
  prompt: string,
  generationConfig?: any
): Promise<string> {
  console.log(`INFO: Starting AI generation with failover for prompt length: ${prompt.length}`);
  
  const sortedModels = AI_MODEL_PRIORITY.sort((a, b) => a.priority - b.priority);
  const attemptResults: AICallResult[] = [];
  
  for (const model of sortedModels) {
    const result = await callSingleModel(model, prompt, generationConfig);
    attemptResults.push(result);
    
    if (result.success && result.content) {
      // 成功生成内容，记录统计信息并返回
      const totalTime = attemptResults.reduce((sum, r) => sum + (r.responseTime || 0), 0);
      console.log(`SUCCESS: Generation completed with ${result.model} after ${attemptResults.length} attempts (total: ${totalTime}ms)`);
      return result.content;
    }
  }
  
  // 所有模型都失败了
  const totalTime = attemptResults.reduce((sum, r) => sum + (r.responseTime || 0), 0);
  const errorSummary = attemptResults.map(r => `${r.model}: ${r.error}`).join('; ');
  
  console.error(`ERROR: All AI models failed after ${attemptResults.length} attempts (total: ${totalTime}ms)`);
  console.error(`ERROR: Failure summary: ${errorSummary}`);
  
  throw new Error(
    `所有可用的AI模型均调用失败。尝试了 ${attemptResults.length} 个模型，总耗时 ${totalTime}ms。` +
    `详细错误：${errorSummary}`
  );
}

/**
 * 获取当前AI模型优先级配置
 * @returns AI模型配置列表
 */
export function getModelPriorityConfig(): AIModelConfig[] {
  return [...AI_MODEL_PRIORITY];
}

/**
 * 更新AI模型优先级
 * @param newConfig - 新的模型配置
 */
export function updateModelPriority(newConfig: AIModelConfig[]): void {
  AI_MODEL_PRIORITY.length = 0;
  AI_MODEL_PRIORITY.push(...newConfig.sort((a, b) => a.priority - b.priority));
  console.log(`INFO: AI model priority updated. New order: ${AI_MODEL_PRIORITY.map(m => m.name).join(' -> ')}`);
}

/**
 * 测试AI模型可用性
 * @param model - 要测试的模型
 * @returns 测试结果
 */
export async function testModelAvailability(model: AIModel): Promise<AICallResult> {
  const testPrompt = "请简单回复：测试成功";
  const modelConfig = AI_MODEL_PRIORITY.find(m => m.name === model);
  
  if (!modelConfig) {
    return {
      success: false,
      model,
      error: 'Model not found in configuration'
    };
  }
  
  return await callSingleModel(modelConfig, testPrompt);
} 
import { SearchResult, SearchIntent, BlogIdea } from './types';
import { genAI, AI_MODEL, getYearPolicyPrompt } from './config';

/**
 * 分析用户搜索意图
 * @param keyword - 关键词
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @returns 搜索意图分析结果
 */
export async function analyzeSearchIntent(
  keyword: string,
  targetMarket: string = '美国',
  targetLanguage: string = '英语'
): Promise<SearchIntent> {
  try {
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    const prompt = `
    分析关键词"${keyword}"的搜索意图，考虑以下因素：
    - 目标市场：${targetMarket}
    - 目标语言：${targetLanguage}
    
    请分析用户搜索这个关键词的主要意图，并给出置信度评分（0-100）。
    
    可能的搜索意图类型包括：
    - 信息型（Informational）：寻找信息、学习、了解
    - 导航型（Navigational）：寻找特定网站或品牌
    - 交易型（Transactional）：购买、下载、注册
    - 商业调研型（Commercial Investigation）：比较、评测、选择
    
    请用中文回答。
    `;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    // 基于关键词特征进行意图分析（实际应用中会解析AI响应）
    let intent = '信息型';
    let confidence = 85;
    let description = '';
    let intentList: string[] = [];
    
    if (keyword.toLowerCase().includes('tool') || keyword.toLowerCase().includes('software')) {
      intent = '商业调研型';
      confidence = 90;
      description = '用户正在寻找和比较不同的工具或软件解决方案，希望了解功能特点和选择建议。';
      intentList = [
        '寻找最佳的AI SEO工具',
        '比较不同工具的功能和价格',
        '了解工具的使用方法和效果',
        '查看用户评价和推荐',
        '寻找免费或付费的解决方案',
        '了解工具的技术特性'
      ];
    } else if (keyword.toLowerCase().includes('how to') || keyword.toLowerCase().includes('guide')) {
      intent = '信息型';
      confidence = 95;
      description = '用户希望学习具体的操作方法或获取详细的指导信息。';
      intentList = [
        '学习具体的操作步骤',
        '获取详细的教程指南',
        '了解最佳实践方法',
        '解决具体问题',
        '掌握相关技能'
      ];
    } else if (keyword.toLowerCase().includes('buy') || keyword.toLowerCase().includes('price')) {
      intent = '交易型';
      confidence = 88;
      description = '用户有明确的购买意向，正在寻找购买渠道或价格信息。';
      intentList = [
        '查找购买渠道',
        '比较价格信息',
        '了解产品规格',
        '查看优惠活动',
        '寻找可靠的供应商'
      ];
    } else {
      intent = '信息型';
      confidence = 85;
      description = '用户主要是想了解相关信息，获取知识或解决问题。';
      intentList = [
        '了解基础概念和定义',
        '获取相关知识和信息',
        '解决遇到的问题',
        '学习新的技能或方法',
        '跟上行业趋势和发展'
      ];
    }
    
    return {
      intent,
      confidence,
      description,
      intentList
    };
  } catch (error) {
    console.error('搜索意图分析失败:', error);
    // 返回默认意图分析
    return {
      intent: '信息型',
      confidence: 75,
      description: '用户主要是想了解相关信息，获取知识或解决问题。',
      intentList: [
        '了解基础概念和定义',
        '获取相关知识和信息',
        '解决遇到的问题',
        '学习新的技能或方法',
        '跟上行业趋势和发展'
      ]
    };
  }
}

/**
 * 基于搜索结果和搜索意图生成博客灵感
 * @param keyword - 关键词
 * @param searchResults - 搜索结果
 * @param pageCount - 页面数量
 * @param timeRange - 时间范围
 * @param searchIntent - 搜索意图（可选）
 * @returns 博客灵感数组
 */
export async function generateBlogIdeas(
  keyword: string,
  searchResults: SearchResult[],
  pageCount: number = 2,
  timeRange: string = '任何时候',
  searchIntent?: SearchIntent
): Promise<BlogIdea[]> {
  try {
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建搜索结果摘要
    const searchResultsSummary = searchResults.slice(0, 10).map((result, index) => 
      `${index + 1}. ${result.title}\n   ${result.snippet}`
    ).join('\n\n');
    
    // 构建搜索意图信息
    const intentInfo = searchIntent ? 
      `搜索意图分析：
      - 主要意图：${searchIntent.intent}
      - 置信度：${searchIntent.confidence}%
      - 描述：${searchIntent.description}
      - 具体意图：${searchIntent.intentList.join('、')}` : '';
    
    // 获取当前年份并应用全局年份策略
    const currentYear = new Date().getFullYear();
    const yearPolicyPrompt = getYearPolicyPrompt(currentYear);
    
    const prompt = `
${yearPolicyPrompt}

作为一个专业的内容策略师，请基于以下信息为关键词"${keyword}"生成15个高质量的博客文章创意：

${intentInfo}

Google搜索结果分析：
${searchResultsSummary}

请生成15个不同类型的博客文章创意，每个创意必须是**完整、可执行的博客主题**，而不仅仅是短语。

**重要要求：**
1. 每个创意都必须是具体的、可立即执行的博客主题
2. 创意要基于真实的搜索结果和用户意图
3. 具有吸引力和实用性，能够解决用户的实际问题
4. 符合SEO最佳实践，包含相关关键词
5. **年份使用强制规则：**
   - 如果创意中包含年份，必须使用${currentYear}年
   - 优先使用"in ${currentYear}"、"this year"等动态表达
   - 或者使用"latest"、"current"、"modern"等时间中性词汇
   - 绝对禁止使用${currentYear + 1}年或更早的年份

**要求的15种文章类型（确保多样性）：**
1. **Listicle** - 列表型文章（如"Top 10..."、"Best 15..."、"Essential 20..."）
2. **How-to-Guide** - 深度教程/指南（如"How to from zero to..."、"Complete step-by-step guide to..."）
3. **Comparison** - 对比型文章（如"A vs B"、"Comparing..."、"Which is better..."）
4. **Why** - 解释型文章（如"Why..."、"The truth about..."、"Understanding..."）
5. **Tips** - 技巧型文章（如"Pro tips for..."、"Expert strategies for..."、"Advanced techniques..."）
6. **Case-Study** - 案例研究（如"How we helped client..."、"Real-world case study of..."、"Success story:"）
7. **FAQ** - 常见问题解答（如"Everything you need to know about..."、"Frequently asked questions about..."）
8. **Trends** - 趋势分析/预测（如"Future of... in [Current Year]"、"Emerging trends in..."、"What to expect in..."）
9. **Review** - 产品/工具评测（如"We tested 5 [tools], here's what we found"、"In-depth review of..."）
10. **Myth-Busting** - 错误/迷思纠正（如"5 common myths about..."、"Debunking misconceptions about..."）
11. **Infographic** - 信息图/数据可视化文章（如"Understanding [topic] in one chart"、"Visual guide to..."）
12. **Expert-Interview** - 专家访谈（如"Expert insights on..."、"Interview with industry leader about..."）
13. **Resource-Roundup** - 资源汇总（如"Best resources for learning..."、"Ultimate toolkit for..."）
14. **Personal-Story** - 个人故事/经验分享（如"What I learned from..."、"My journey with..."、"Lessons from..."）
15. **Template-Checklist** - 模板/清单下载（如"Free download: Ultimate [task] checklist"、"Ready-to-use templates for..."）

**创意质量要求：**
- 每个创意都要有明确的目标受众
- 包含具体的价值主张和用户收益
- 基于搜索结果中的真实需求和痛点
- 考虑不同用户搜索意图（信息型、交易型、导航型）

请用以下JSON格式回复，每个创意都要用英文标题：
{
  "ideas": [
    {
      "title": "Write a 'Listicle' blog post on 'Top 10 AI SEO tools in [Current Year]'",
      "type": "Listicle",
      "description": "基于搜索结果的详细描述，说明文章将如何帮助读者选择最适合的AI SEO工具",
      "keywords": ["关键词1", "关键词2", "关键词3"]
    }
  ]
}

**注意：**
- 标题必须用英文，格式为：Write a '[类型]' blog post on '[具体标题]'
- 描述用中文，要具体说明文章内容和价值，以及如何解决用户问题
- 关键词要包含主关键词和相关长尾词
- 确保每个创意都独特且有价值
- **重点：每个创意都必须是完整、可执行的博客主题，而不是简单的短语**
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI生成的博客创意原始响应:', text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.ideas && Array.isArray(aiResponse.ideas)) {
        return aiResponse.ideas.map((idea: any) => ({
          title: idea.title || `Write a '${idea.type}' blog post on '${keyword}'`,
          type: idea.type || 'Guide',
          description: idea.description || `关于${keyword}的${idea.type}类型文章`,
          keywords: Array.isArray(idea.keywords) ? idea.keywords : [keyword]
        }));
      }
    } catch (parseError) {
      console.warn('解析AI响应JSON失败，使用备用解析方法:', parseError);
    }
    
    // 如果JSON解析失败，使用基于搜索结果的智能生成
    return generateFallbackIdeas(keyword, searchResults, searchIntent);
    
  } catch (error) {
    console.error('生成博客灵感失败:', error);
    // 返回基于搜索结果的备用创意
    return generateFallbackIdeas(keyword, searchResults, searchIntent);
  }
}

/**
 * 生成备用博客创意（当AI生成失败时使用）
 * @param keyword - 关键词
 * @param searchResults - 搜索结果
 * @param searchIntent - 搜索意图
 * @returns 博客创意数组
 */
function generateFallbackIdeas(
  keyword: string, 
  searchResults: SearchResult[], 
  searchIntent?: SearchIntent
): BlogIdea[] {
  // 分析搜索结果中的常见主题
  const resultTitles = searchResults.map(r => r.title.toLowerCase());
  const hasTools = resultTitles.some(title => title.includes('tool') || title.includes('software'));
  const hasGuide = resultTitles.some(title => title.includes('guide') || title.includes('how'));
  const hasComparison = resultTitles.some(title => title.includes('vs') || title.includes('compare') || title.includes('best'));
  const hasReview = resultTitles.some(title => title.includes('review') || title.includes('test'));
  
  const currentYear = new Date().getFullYear();
  
  const ideas: BlogIdea[] = [
    {
      title: `Write a 'Listicle' blog post on 'Top 10 ${keyword} for ${currentYear}'`,
      type: 'Listicle',
      description: `基于搜索结果分析，列出${currentYear}年最受欢迎的${keyword}选项，包括功能对比和使用建议。`,
      keywords: [keyword, `top 10`, `${currentYear}`, 'best']
    },
    {
      title: `Write a 'How-to-Guide' blog post on 'How to master ${keyword} from zero to expert'`,
      type: 'How-to-Guide',
      description: `详细指导读者从零开始学习和掌握${keyword}，包括基础概念、实践步骤和进阶技巧。`,
      keywords: [keyword, 'how to master', 'beginner guide', 'tutorial']
    },
    {
      title: `Write a 'Comparison' blog post on '${keyword}: Which option is right for you?'`,
      type: 'Comparison',
      description: `深入对比不同${keyword}选项的优缺点，帮助读者根据具体需求做出最佳选择。`,
      keywords: [keyword, 'comparison', 'vs', 'which is better']
    },
    {
      title: `Write a 'Why' blog post on 'Why ${keyword} is essential in ${currentYear}'`,
      type: 'Why',
      description: `解释${keyword}的重要性和价值，分析为什么在${currentYear}年它变得不可或缺。`,
      keywords: [keyword, 'why important', 'essential', `${currentYear}`]
    },
    {
      title: `Write a 'Tips' blog post on 'Expert tips for maximizing ${keyword} performance'`,
      type: 'Tips',
      description: `分享专家级的${keyword}优化技巧和策略，帮助读者提升效果和性能。`,
      keywords: [keyword, 'expert tips', 'optimization', 'performance']
    },
    {
      title: `Write a 'Case-Study' blog post on 'How companies succeed with ${keyword}: Real case study'`,
      type: 'Case-Study',
      description: `通过真实案例展示企业如何成功应用${keyword}，分析成功因素和可复制的策略。`,
      keywords: [keyword, 'case study', 'success story', 'real example']
    },
    {
      title: `Write a 'FAQ' blog post on 'Everything you need to know about ${keyword}: Complete FAQ'`,
      type: 'FAQ',
      description: `回答关于${keyword}的所有常见问题，为读者提供全面的知识参考。`,
      keywords: [keyword, 'FAQ', 'questions and answers', 'complete guide']
    },
    {
      title: `Write a 'Trends' blog post on 'Future of ${keyword}: Trends to watch in ${currentYear}'`,
      type: 'Trends',
      description: `分析${keyword}领域的最新趋势和未来发展方向，帮助读者把握行业动态。`,
      keywords: [keyword, 'trends', 'future', `${currentYear}`, 'predictions']
    }
  ];
  
  return ideas;
} 
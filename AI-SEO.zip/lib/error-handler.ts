/**
 * 前端错误处理工具
 * 提供统一的错误处理和用户友好的提示
 */

import { toast } from 'sonner'

// 网络错误类型接口
export interface NetworkErrorResponse {
  success: false
  error: string
  errorType: 'NetworkError'
  attemptedMethods: string[]
  userSuggestion: string
  networkDetails: {
    name: string
    message: string
    attemptedMethods: string[]
    originalErrors: Array<{
      name: string
      message: string
    }>
    userSuggestion: string
  }
}

// 重试函数类型
export type RetryFunction = () => Promise<void>

/**
 * 检查是否为网络错误响应
 */
export function isNetworkError(error: any): error is NetworkErrorResponse {
  return error && 
         error.errorType === 'NetworkError' && 
         error.attemptedMethods && 
         error.userSuggestion
}

/**
 * 格式化网络错误信息为用户友好的提示
 */
export function formatNetworkErrorMessage(error: NetworkErrorResponse): string {
  const methods = error.attemptedMethods.join('、')
  return `网络连接失败：尝试了${methods}均无法连接。${error.userSuggestion}`
}

/**
 * 显示网络错误Toast通知
 */
export function showNetworkErrorToast(
  error: NetworkErrorResponse, 
  onRetry?: RetryFunction,
  customTitle?: string
) {
  const title = customTitle || 'AI服务连接失败'
  const message = formatNetworkErrorMessage(error)
  
  toast.error(title, {
    description: message,
    duration: 8000, // 8秒显示时间
    action: onRetry ? {
      label: '重试',
      onClick: async () => {
        try {
          await onRetry()
        } catch (err) {
          console.error('重试失败:', err)
        }
      }
    } : undefined,
  })

  // 输出详细错误信息到控制台，便于调试
  console.group('🔴 网络错误详情')
  console.log('错误类型:', error.errorType)
  console.log('尝试的方法:', error.attemptedMethods)
  console.log('用户建议:', error.userSuggestion)
  console.log('原始错误:', error.networkDetails.originalErrors)
  console.groupEnd()
}

/**
 * 显示通用错误Toast通知
 */
export function showGenericErrorToast(
  error: string | Error,
  onRetry?: RetryFunction,
  customTitle?: string
) {
  const title = customTitle || '操作失败'
  const message = error instanceof Error ? error.message : error
  
  toast.error(title, {
    description: message,
    duration: 6000,
    action: onRetry ? {
      label: '重试',
      onClick: async () => {
        try {
          await onRetry()
        } catch (err) {
          console.error('重试失败:', err)
        }
      }
    } : undefined,
  })
}

/**
 * 显示成功Toast通知
 */
export function showSuccessToast(
  message: string,
  customTitle?: string
) {
  const title = customTitle || '操作成功'
  
  toast.success(title, {
    description: message,
    duration: 4000,
  })
}

/**
 * 显示加载Toast通知
 */
export function showLoadingToast(
  message: string,
  customTitle?: string
): string | number {
  const title = customTitle || '处理中'
  
  return toast.loading(title, {
    description: message,
  })
}

/**
 * 关闭指定的Toast通知
 */
export function dismissToast(toastId: string | number) {
  toast.dismiss(toastId)
}

/**
 * 统一的API错误处理函数
 * 自动判断错误类型并显示合适的提示
 */
export function handleApiError(
  error: any,
  onRetry?: RetryFunction,
  customTitle?: string
) {
  if (isNetworkError(error)) {
    showNetworkErrorToast(error, onRetry, customTitle)
  } else {
    showGenericErrorToast(
      error?.error || error?.message || error || '未知错误',
      onRetry,
      customTitle
    )
  }
}

/**
 * 为API调用创建统一的错误处理器
 */
export function createApiErrorHandler(
  customTitle?: string,
  onRetry?: RetryFunction
) {
  return (error: any) => {
    handleApiError(error, onRetry, customTitle)
  }
}

/**
 * 包装API调用，自动处理错误和加载状态
 */
export async function withErrorHandling<T>(
  apiCall: () => Promise<T>,
  options: {
    loadingMessage?: string
    successMessage?: string
    errorTitle?: string
    onRetry?: RetryFunction
    showLoadingToast?: boolean
  } = {}
): Promise<T | null> {
  let loadingToastId: string | number | undefined

  try {
    // 显示加载提示
    if (options.showLoadingToast !== false && options.loadingMessage) {
      loadingToastId = showLoadingToast(options.loadingMessage)
    }

    // 执行API调用
    const result = await apiCall()

    // 关闭加载提示
    if (loadingToastId) {
      dismissToast(loadingToastId)
    }

    // 显示成功提示
    if (options.successMessage) {
      showSuccessToast(options.successMessage)
    }

    return result
  } catch (error) {
    // 关闭加载提示
    if (loadingToastId) {
      dismissToast(loadingToastId)
    }

    // 处理错误
    handleApiError(error, options.onRetry, options.errorTitle)
    
    return null
  }
}

/**
 * 网络诊断信息收集
 */
export async function collectNetworkDiagnostics(): Promise<{
  userAgent: string
  timestamp: string
  language: string
  online: boolean
  effectiveType?: string
}> {
  const nav = navigator as any
  
  return {
    userAgent: nav.userAgent,
    timestamp: new Date().toISOString(),
    language: nav.language,
    online: nav.onLine,
    effectiveType: nav.connection?.effectiveType || 'unknown'
  }
}

/**
 * 生成错误报告
 */
export function generateErrorReport(
  error: NetworkErrorResponse,
  context: string
): string {
  const diagnostics = collectNetworkDiagnostics()
  
  return `
=== 网络错误报告 ===
时间: ${new Date().toLocaleString('zh-CN')}
上下文: ${context}
错误类型: ${error.errorType}
尝试的方法: ${error.attemptedMethods.join(', ')}
用户建议: ${error.userSuggestion}

原始错误:
${error.networkDetails.originalErrors.map(e => `- ${e.name}: ${e.message}`).join('\n')}

浏览器信息:
- 用户代理: ${navigator.userAgent}
- 在线状态: ${navigator.onLine ? '在线' : '离线'}
- 语言: ${navigator.language}
  `.trim()
} 
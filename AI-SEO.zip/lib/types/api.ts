/**
 * Google Custom Search API 响应类型
 */
export interface GoogleSearchResponse {
  kind: string
  url: {
    type: string
    template: string
  }
  queries: {
    request: Array<{
      title: string
      totalResults: string
      searchTerms: string
      count: number
      startIndex: number
      inputEncoding: string
      outputEncoding: string
      safe: string
      cx: string
    }>
  }
  context: {
    title: string
  }
  searchInformation: {
    searchTime: number
    formattedSearchTime: string
    totalResults: string
    formattedTotalResults: string
  }
  items: GoogleSearchItem[]
}

export interface GoogleSearchItem {
  kind: string
  title: string
  htmlTitle: string
  link: string
  displayLink: string
  snippet: string
  htmlSnippet: string
  cacheId?: string
  formattedUrl: string
  htmlFormattedUrl: string
  pagemap?: {
    metatags?: Array<{
      [key: string]: string
    }>
    cse_thumbnail?: Array<{
      src: string
      width: string
      height: string
    }>
    cse_image?: Array<{
      src: string
    }>
  }
}

/**
 * Google Generative AI API 响应类型
 */
export interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string
      }>
      role: string
    }
    finishReason: string
    index: number
    safetyRatings: Array<{
      category: string
      probability: string
    }>
  }>
  promptFeedback?: {
    safetyRatings: Array<{
      category: string
      probability: string
    }>
  }
}

/**
 * 博客创意类型
 */
export interface BlogIdea {
  title: string
  type: 'Listicle' | 'How' | 'Comparison' | 'Why' | 'Tips' | 'Guide' | 'Trends' | 'Review'
  description: string
  keywords: string[]
  estimatedWords?: number
  targetAudience?: string
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced'
}

/**
 * SEO 标题类型
 */
export interface SeoTitle {
  title: string
  seoScore: number
  readabilityScore: number
  keywords: string[]
  estimatedClicks?: number
  competition?: 'Low' | 'Medium' | 'High'
  searchVolume?: number
}

/**
 * 文章大纲类型
 */
export interface ArticleOutline {
  title: string
  introduction: string
  sections: OutlineSection[]
  conclusion: string
  wordCount: string
  readabilityLevel: string
  toneStyle: string
  perspective: string
  seoKeywords: string[]
  estimatedReadingTime?: number
  targetAudience?: string
}

export interface OutlineSection {
  heading: string
  subheadings: string[]
  keyPoints: string[]
  estimatedWords: number
  seoKeywords?: string[]
  contentType?: 'text' | 'list' | 'table' | 'image'
}

/**
 * 搜索意图分析类型
 */
export interface SearchIntent {
  intent: string
  confidence: number
  description: string
  intentList: string[]
  userJourney?: 'awareness' | 'consideration' | 'decision'
  searchType?: 'informational' | 'navigational' | 'transactional'
}

/**
 * 内容分析类型
 */
export interface ContentAnalysis {
  url: string
  title: string
  outline: string[]
  style: string
  tone: string
  structure: string
  keyPoints: string[]
  wordCount?: number
  readabilityScore?: number
  seoScore?: number
  contentQuality?: 'Low' | 'Medium' | 'High'
}

/**
 * 证据/引用类型
 */
export interface Evidence {
  content: string
  source: string
  url: string
  type: 'statistic' | 'quote' | 'example' | 'case_study' | 'research'
  relevance: number
  credibility: 'High' | 'Medium' | 'Low'
  sectionInfo?: {
    h2Index: number
    h3Index?: number
    h2Title: string
    h3Title?: string
  }
}

/**
 * Pexels API 响应类型
 */
export interface PexelsResponse {
  page: number
  per_page: number
  photos: PexelsPhoto[]
  total_results: number
  next_page?: string
  prev_page?: string
}

export interface PexelsPhoto {
  id: number
  width: number
  height: number
  url: string
  photographer: string
  photographer_url: string
  photographer_id: number
  avg_color: string
  src: {
    original: string
    large2x: string
    large: string
    medium: string
    small: string
    portrait: string
    landscape: string
    tiny: string
  }
  liked: boolean
  alt: string
}

/**
 * 知识库类型
 */
export interface KnowledgeBase {
  _id: string
  name: string
  type: string
  intro?: string
  avatar?: string
  permission: 'read' | 'write' | 'admin'
  isPublic: boolean
  isOwner: boolean
  vectorModel: {
    model: string
    name: string
  }
  tags: string[]
  createTime: string
  updateTime: string
}

export interface KnowledgeBaseDetail extends KnowledgeBase {
  dataCount: number
  isOwner: boolean
  canWrite: boolean
  canRead: boolean
  canManage: boolean
}

/**
 * 知识提取响应类型
 */
export interface KnowledgeExtractionResponse {
  choices: Array<{
    message: {
      content: string
      role: string
    }
    finish_reason: string
  }>
  usage: {
    prompt_tokens: number
    completion_tokens: number
    total_tokens: number
  }
}

/**
 * 通用 API 响应包装类型
 */
export interface ApiResponse<T = unknown> {
  code: number
  message: string
  data: T
  error?: string
}

/**
 * 错误响应类型
 */
export interface ErrorResponse {
  error: string
  message: string
  status: number
  timestamp: string
  path: string
}

/**
 * 分页响应类型
 */
export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
  totalPages: number
  hasNext: boolean
  hasPrev: boolean
} 
import { GeneratedArticle } from './types';

const HISTORY_STORAGE_KEY = 'vertu_seo_article_history';
const MAX_HISTORY_SIZE = 50; // 最大保存50篇文章

/**
 * 获取所有历史记录
 */
export function getArticleHistory(): GeneratedArticle[] {
  try {
    const stored = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!stored) return [];
    
    const history = JSON.parse(stored);
    return Array.isArray(history) ? history : [];
  } catch (error) {
    console.error('Failed to get article history:', error);
    return [];
  }
}

/**
 * 保存文章到历史记录
 */
export function saveArticleToHistory(article: Omit<GeneratedArticle, 'id' | 'createdAt'>): void {
  try {
    const history = getArticleHistory();
    
    // 创建新的文章记录
    const newArticle: GeneratedArticle = {
      ...article,
      id: generateArticleId(),
      createdAt: new Date().toISOString()
    };
    
    // 添加到数组头部
    history.unshift(newArticle);
    
    // 限制历史记录大小
    if (history.length > MAX_HISTORY_SIZE) {
      history.splice(MAX_HISTORY_SIZE);
    }
    
    // 保存到localStorage
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
    
    console.log('Article saved to history:', newArticle.id);
  } catch (error) {
    console.error('Failed to save article to history:', error);
  }
}

/**
 * 删除文章历史记录
 */
export function deleteArticleFromHistory(articleId: string): boolean {
  try {
    const history = getArticleHistory();
    const filteredHistory = history.filter(article => article.id !== articleId);
    
    if (filteredHistory.length !== history.length) {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(filteredHistory));
      console.log('Article deleted from history:', articleId);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Failed to delete article from history:', error);
    return false;
  }
}

/**
 * 清空所有历史记录
 */
export function clearArticleHistory(): void {
  try {
    localStorage.removeItem(HISTORY_STORAGE_KEY);
    console.log('Article history cleared');
  } catch (error) {
    console.error('Failed to clear article history:', error);
  }
}

/**
 * 获取单个文章记录
 */
export function getArticleById(articleId: string): GeneratedArticle | null {
  try {
    const history = getArticleHistory();
    return history.find(article => article.id === articleId) || null;
  } catch (error) {
    console.error('Failed to get article by ID:', error);
    return null;
  }
}

/**
 * 生成文章ID
 */
function generateArticleId(): string {
  return `article_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * 格式化创建时间
 */
export function formatCreatedAt(createdAt: string): string {
  try {
    const date = new Date(createdAt);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInHours * 60);
      return `${diffInMinutes} 分钟前`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)} 小时前`;
    } else if (diffInHours < 24 * 7) {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} 天前`;
    } else {
      return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }
  } catch (error) {
    return '未知时间';
  }
}

/**
 * 计算文章字数
 */
export function calculateWordCount(content: string): number {
  // 移除Markdown标记，只计算实际文本
  const cleanContent = content
    .replace(/#{1,6}\s+/g, '') // 移除标题标记
    .replace(/\*\*(.*?)\*\*/g, '$1') // 移除粗体标记
    .replace(/\*(.*?)\*/g, '$1') // 移除斜体标记
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // 移除链接标记
    .replace(/`([^`]+)`/g, '$1') // 移除代码标记
    .replace(/\n+/g, ' ') // 将换行替换为空格
    .trim();
  
  // 按空格分割并计算单词数
  const words = cleanContent.split(/\s+/).filter(word => word.length > 0);
  return words.length;
} 
import { BlogTitle } from './types';
import { createGenAI, AI_MODEL, getYearPolicyPrompt } from './config';
import { recordAPIResult } from './api-key-manager';

/**
 * 生成博客标题
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @param knowledgePoints - 知识点
 * @param additionalRequirements - 附加要求
 * @param referenceTitles - 参考标题
 * @param lsiTerms - LSI术语（可选）
 * @returns 生成的博客标题数组
 */
export async function generateBlogTitles(
  keyword: string,
  blogIdea: string,
  knowledgePoints: string[],
  additionalRequirements: string = '',
  referenceTitles: string[] = [],
  lsiTerms: string[] = []
): Promise<BlogTitle[]> {
  try {
    console.log('=== generateBlogTitles 函数调用 ===');
    console.log('keyword:', keyword);
    console.log('blogIdea:', blogIdea);
    console.log('knowledgePoints.length:', knowledgePoints.length);
    console.log('additionalRequirements.length:', additionalRequirements.length);
    console.log('referenceTitles.length:', referenceTitles.length);
    console.log('lsiTerms参数类型:', typeof lsiTerms);
    console.log('lsiTerms是否为数组:', Array.isArray(lsiTerms));
    console.log('lsiTerms.length:', lsiTerms ? lsiTerms.length : 'undefined');
    console.log('lsiTerms内容:', lsiTerms);
    
    const genAI = createGenAI();
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    // 构建知识点文本
    const knowledgeText = knowledgePoints.length > 0 
      ? knowledgePoints.slice(0, 15).join('、') 
      : '暂无特定知识点';
    
    // 构建参考标题文本
    const referenceTitlesText = referenceTitles.length > 0
      ? referenceTitles.slice(0, 10).map((title, index) => `${index + 1}. ${title}`).join('\n')
      : '暂无参考标题';
    
    // 构建LSI术语文本
    const lsiTermsText = lsiTerms.length > 0
      ? lsiTerms.slice(0, 20).join('、')
      : '暂无LSI术语';
    
    console.log('=== LSI术语文本构建 ===');
    console.log('lsiTerms.length:', lsiTerms.length);
    console.log('构建的lsiTermsText:', lsiTermsText);
    
    // 获取当前年份并应用全局年份策略
    const currentYear = new Date().getFullYear();
    const yearPolicyPrompt = getYearPolicyPrompt(currentYear);
    
    const prompt = `
${yearPolicyPrompt}

作为一个专业的SEO内容策略师，请基于以下信息生成10个高质量的博客标题：

主关键词：${keyword}
博客创意：${blogIdea}

提取的知识点：
${knowledgeText}

SERPs分析提取的LSI术语：
${lsiTermsText}

参考文章标题：
${referenceTitlesText}

${additionalRequirements ? `附加要求：\n${additionalRequirements}` : ''}

请生成10个不同风格的博客标题，每个标题都要：

1. **SEO优化**：
   - 包含主关键词"${keyword}"
   - **生成的每个标题都应力求简洁，总长度最好控制在60个字符以内，以获得最佳的搜索引擎结果页（SERP）显示效果**
   - 使用吸引点击的词汇
   - 包含数字或年份（如2025）
   ${lsiTerms.length > 0 ? `- 智能融入LSI术语（如：${lsiTerms.slice(0, 5).join('、')}等），提升语义相关性` : ''}

2. **可读性优化**：
   - 语言简洁明了
   - 避免过于复杂的词汇
   - 结构清晰，易于理解
   - 符合目标受众的阅读习惯

3. **内容价值**：
   - 明确传达文章价值
   - 激发读者的好奇心
   - 承诺解决具体问题
   - 体现专业性和权威性

4. **年份使用要求**：
   - **强制要求：如果标题中需要包含年份，必须使用${currentYear}年**
   - 可以使用"latest"、"current"、"modern"等时间中性词汇
   - **绝对禁止使用${currentYear + 1}年或更早的年份**
   - 优先使用"in ${currentYear}"、"for ${currentYear}"等表达
   - **重要：任何包含年份的标题都必须使用${currentYear}，不得使用任何其他年份**

**标题长度优化要求：**
- 每个标题必须控制在60个字符以内
- 优先使用简洁有力的词汇
- 避免冗余和重复表达
- 确保在SERP中完整显示，不被截断

标题类型要求（生成多种类型）：
- 数字列表型：如"10 Best..."、"Top 15..."
- 问题解答型：如"How to..."、"Why..."
- 对比分析型：如"A vs B"、"比较..."
- 指南教程型：如"Complete Guide..."、"Ultimate..."
- 趋势预测型：如"${currentYear} Trends..."、"Future of... in ${currentYear}"

请用以下JSON格式回复：
{
  "titles": [
    {
      "title": "具体的博客标题",
      "seoScore": 85,
      "readabilityScore": 90,
      "keywords": ["主关键词", "相关关键词1", "相关关键词2"]
    }
  ]
}

评分标准：
- SEO评分 (0-100)：关键词密度、长度、吸引力
- 可读性评分 (0-100)：语言简洁度、理解难度、结构清晰度
- 关键词数组：包含主关键词和2-3个相关长尾关键词

**重要注意：**
- 标题要用英文
- 确保每个标题都独特且有价值
- 考虑不同的用户搜索意图
- 平衡SEO优化和用户体验
- **严格控制标题长度在60个字符以内，确保SERP最佳显示效果**
- **年份使用最终警告：所有标题中的年份必须是${currentYear}，绝对禁止使用${currentYear + 1}年**
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('AI生成的博客标题原始响应:', text);
    
    try {
      // 尝试解析AI响应的JSON
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const aiResponse = JSON.parse(cleanedText);
      
      if (aiResponse.titles && Array.isArray(aiResponse.titles)) {
        return aiResponse.titles.map((title: any) => {
          // 修复年份问题：将任何2026年替换为2025年
          let fixedTitle = title.title || `${keyword} Guide ${currentYear}`;
          if (fixedTitle.includes('2026')) {
            fixedTitle = fixedTitle.replace(/2026/g, currentYear.toString());
            console.warn('检测到AI生成了2026年，已自动修复为当前年份');
          }
          
          return {
            title: fixedTitle,
            seoScore: title.seoScore || 75,
            readabilityScore: title.readabilityScore || 80,
            keywords: Array.isArray(title.keywords) ? title.keywords : [keyword]
          };
        });
      }
    } catch (parseError) {
      console.warn('解析AI标题响应JSON失败，使用备用生成方法:', parseError);
    }
    
    // 如果JSON解析失败，使用基于知识点的智能生成
    return generateFallbackTitles(keyword, blogIdea, knowledgePoints);
    
  } catch (error) {
    console.error('生成博客标题失败:', error);
    // 返回基于关键词的备用标题
    return generateFallbackTitles(keyword, blogIdea, knowledgePoints);
  }
}

/**
 * 生成备用博客标题（当AI生成失败时使用）
 * @param keyword - 关键词
 * @param blogIdea - 博客创意
 * @param knowledgePoints - 知识点
 * @returns 博客标题数组
 */
function generateFallbackTitles(
  keyword: string, 
  blogIdea: string, 
  knowledgePoints: string[]
): BlogTitle[] {
  const currentYear = new Date().getFullYear();
  
  // 分析博客创意类型
  const ideaLower = blogIdea.toLowerCase();
  const isListicle = ideaLower.includes('listicle') || ideaLower.includes('top') || ideaLower.includes('best');
  const isHowTo = ideaLower.includes('how') || ideaLower.includes('guide');
  const isComparison = ideaLower.includes('comparison') || ideaLower.includes('vs');
  const isReview = ideaLower.includes('review') || ideaLower.includes('evaluation');
  
  const titles: BlogTitle[] = [];
  
  // 基于博客创意类型生成相应标题
  if (isListicle) {
    titles.push(
      {
        title: `Top 10 ${keyword} Tools for ${currentYear}`,
        seoScore: 85,
        readabilityScore: 90,
        keywords: [keyword, 'top 10', 'tools', currentYear.toString()]
      },
      {
        title: `Best ${keyword} Solutions: Complete List for ${currentYear}`,
        seoScore: 80,
        readabilityScore: 85,
        keywords: [keyword, 'best', 'solutions', 'list']
      }
    );
  }
  
  if (isHowTo) {
    titles.push(
      {
        title: `How to Choose the Best ${keyword} in ${currentYear}`,
        seoScore: 88,
        readabilityScore: 92,
        keywords: [keyword, 'how to choose', 'best', currentYear.toString()]
      },
      {
        title: `Complete ${keyword} Guide: Everything You Need to Know`,
        seoScore: 82,
        readabilityScore: 88,
        keywords: [keyword, 'complete guide', 'everything']
      }
    );
  }
  
  if (isComparison) {
    titles.push(
      {
        title: `${keyword} Comparison: Which One is Right for You?`,
        seoScore: 83,
        readabilityScore: 87,
        keywords: [keyword, 'comparison', 'which one', 'right for you']
      }
    );
  }
  
  if (isReview) {
    titles.push(
      {
        title: `${keyword} Review: Pros, Cons, and Everything Between`,
        seoScore: 81,
        readabilityScore: 86,
        keywords: [keyword, 'review', 'pros cons', 'everything']
      }
    );
  }
  
  // 添加通用标题
  titles.push(
    {
      title: `Ultimate ${keyword} Guide for Beginners in ${currentYear}`,
      seoScore: 84,
      readabilityScore: 89,
      keywords: [keyword, 'ultimate guide', 'beginners', currentYear.toString()]
    },
    {
      title: `${keyword} Trends and Predictions for ${currentYear}`,
      seoScore: 79,
      readabilityScore: 85,
      keywords: [keyword, 'trends', 'predictions', currentYear.toString()]
    },
    {
      title: `Why ${keyword} is Essential for Your Business Success`,
      seoScore: 77,
      readabilityScore: 88,
      keywords: [keyword, 'why essential', 'business success']
    },
    {
      title: `${keyword} Tips and Tricks from Industry Experts`,
      seoScore: 76,
      readabilityScore: 87,
      keywords: [keyword, 'tips tricks', 'industry experts']
    }
  );
  
  // 基于知识点生成个性化标题
  if (knowledgePoints.length > 0) {
    const firstKnowledge = knowledgePoints[0];
    if (firstKnowledge && firstKnowledge.length > 3) {
      titles.push({
        title: `${keyword} and ${firstKnowledge}: A Comprehensive Analysis`,
        seoScore: 78,
        readabilityScore: 84,
        keywords: [keyword, firstKnowledge.toLowerCase(), 'comprehensive analysis']
      });
    }
  }
  
  // 确保返回10个标题，如果不足则补充
  while (titles.length < 10) {
    titles.push({
      title: `${keyword} Essentials: What You Need to Know in ${currentYear}`,
      seoScore: 75,
      readabilityScore: 83,
      keywords: [keyword, 'essentials', 'need to know', currentYear.toString()]
    });
  }
  
  return titles.slice(0, 10);
} 
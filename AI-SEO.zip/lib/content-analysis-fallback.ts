import { SearchResult } from './types';

/**
 * 简化的相关性评分（备用方法）
 * @param result - 搜索结果
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @returns 简化评分 (0-100)
 */
export function calculateSimpleRelevanceScore(
  result: SearchResult,
  keyword: string,
  blogIdea: string
): number {
  const text = (result.title + ' ' + result.snippet).toLowerCase();
  const keywordLower = keyword.toLowerCase();
  const titleLower = result.title.toLowerCase();
  
  let score = 0;
  
  // 关键词匹配 (40分)
  if (titleLower.includes(keywordLower)) {
    score += 25; // 标题包含关键词
  }
  const keywordCount = (text.match(new RegExp(keywordLower, 'g')) || []).length;
  score += Math.min(keywordCount * 5, 15); // 关键词出现频率
  
  // 内容质量指标 (30分)
  const qualityWords = [
    'guide', 'tutorial', 'complete', 'comprehensive', 'detailed', 'step-by-step',
    'best', 'top', 'ultimate', 'expert', 'professional', 'advanced',
    'tips', 'strategies', 'methods', 'techniques', 'how to', 'review'
  ];
  const qualityMatches = qualityWords.filter(word => text.includes(word)).length;
  score += Math.min(qualityMatches * 3, 30);
  
  // 权威性指标 (20分)
  const url = result.url.toLowerCase();
  if (url.includes('blog') || url.includes('article') || url.includes('guide')) {
    score += 10;
  }
  const authorityDomains = [
    'medium.com', 'hubspot.com', 'moz.com', 'searchengineland.com',
    'contentmarketinginstitute.com', 'neilpatel.com', 'backlinko.com'
  ];
  if (authorityDomains.some(domain => url.includes(domain))) {
    score += 10;
  }
  
  // 时效性 (10分)
  const currentYear = new Date().getFullYear();
  if (text.includes(currentYear.toString()) || text.includes((currentYear + 1).toString())) {
    score += 10;
  }
  
  return Math.min(score, 100);
}

/**
 * 从AI响应文本中提取搜索查询（备用解析方法）
 * @param text - AI响应文本
 * @param keyword - 主关键词
 * @returns 提取的查询数组
 */
export function extractQueriesFromText(text: string, keyword: string): string[] {
  const queries: string[] = [];
  
  // 尝试匹配引号中的查询
  const quotedMatches = text.match(/"([^"]+)"/g);
  if (quotedMatches) {
    quotedMatches.forEach(match => {
      const query = match.replace(/"/g, '').trim();
      if (query.length > 5 && query.toLowerCase().includes(keyword.toLowerCase())) {
        queries.push(query);
      }
    });
  }
  
  // 尝试匹配以关键词开头的行
  const lines = text.split('\n');
  lines.forEach(line => {
    const trimmed = line.trim();
    if (trimmed.toLowerCase().includes(keyword.toLowerCase()) && 
        trimmed.length > 10 && trimmed.length < 100 &&
        !trimmed.includes('：') && !trimmed.includes(':')) {
      queries.push(trimmed);
    }
  });
  
  return queries.slice(0, 4);
}

/**
 * 从AI响应文本中提取博客内容（备用解析方法）
 * @param text - AI响应文本
 * @param searchResults - 原始搜索结果
 * @returns 提取的博客内容
 */
export function extractBlogContentFromText(text: string, searchResults: SearchResult[]): SearchResult[] {
  const blogResults: SearchResult[] = [];
  
  // 查找文本中提到的结果索引
  const indexMatches = text.match(/结果(\d+)/g);
  if (indexMatches) {
    const mentionedIndices = indexMatches.map(match => {
      const num = match.match(/\d+/);
      return num ? parseInt(num[0]) - 1 : -1;
    }).filter(index => index >= 0 && index < searchResults.length);
    
    // 去重并添加到结果中
    const uniqueIndices = Array.from(new Set(mentionedIndices));
    uniqueIndices.forEach(index => {
      blogResults.push(searchResults[index]);
    });
  }
  
  // 如果没有找到明确的索引，使用快速过滤
  if (blogResults.length === 0) {
    return quickFilterBlogContent(searchResults);
  }
  
  return blogResults;
}

/**
 * 从AI响应文本中提取批量评分（备用解析方法）
 * @param text - AI响应文本
 * @param results - 原始搜索结果
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @returns 带评分的结果数组
 */
export function extractBatchScoresFromText(
  text: string, 
  results: SearchResult[], 
  keyword: string, 
  blogIdea: string
): SearchResult[] {
  const scoredResults: SearchResult[] = [];
  
  // 尝试匹配 "结果X: 评分Y" 的模式
  const scoreMatches = text.match(/结果(\d+)[：:]\s*评分[：:]?\s*(\d+)/g);
  if (scoreMatches) {
    scoreMatches.forEach(match => {
      const indexMatch = match.match(/结果(\d+)/);
      const scoreMatch = match.match(/评分[：:]?\s*(\d+)/);
      
      if (indexMatch && scoreMatch) {
        const index = parseInt(indexMatch[1]) - 1;
        const score = parseInt(scoreMatch[1]);
        
        if (index >= 0 && index < results.length && score >= 0 && score <= 100) {
          scoredResults.push({
            ...results[index],
            aiRelevanceScore: score,
            finalScore: score
          });
        }
      }
    });
  }
  
  // 如果没有找到评分，尝试其他模式
  if (scoredResults.length === 0) {
    const altScoreMatches = text.match(/(\d+)\s*分/g);
    if (altScoreMatches) {
      altScoreMatches.forEach((match, index) => {
        const score = parseInt(match.match(/(\d+)/)?.[1] || '0');
        if (index < results.length && score >= 0 && score <= 100) {
          scoredResults.push({
            ...results[index],
            aiRelevanceScore: score,
            finalScore: score
          });
        }
      });
    }
  }
  
  // 对未评分的结果使用简化评分
  const unscored = results.filter((_, index) => 
    !scoredResults.some(scored => scored.url === results[index].url)
  );
  
  const unscoredWithSimpleScore = unscored.map(result => ({
    ...result,
    finalScore: calculateSimpleRelevanceScore(result, keyword, blogIdea)
  }));
  
  // 合并并排序
  const allResults = [...scoredResults, ...unscoredWithSimpleScore];
  return allResults.sort((a, b) => 
    ((b as any).finalScore || 0) - ((a as any).finalScore || 0)
  );
}

/**
 * 快速规则过滤（预处理）
 * @param searchResults - 搜索结果
 * @returns 快速过滤后的结果
 */
export function quickFilterBlogContent(searchResults: SearchResult[]): SearchResult[] {
  // 通用SEO博客内容关键词（按类型分组）
  const blogKeywords = [
    // 内容类型标识词
    'blog', 'article', 'post', 'content', 'story', 'piece',
    
    // 教程和指南类
    'guide', 'tutorial', 'how to', 'how-to', 'step by step', 'walkthrough', 
    'instructions', 'manual', 'handbook', 'course', 'lesson', 'training',
    
    // 列表和排名类
    'top', 'best', 'worst', 'list', 'ranking', 'comparison', 'vs', 'versus',
    'alternatives', 'options', 'choices', 'selection',
    
    // 评测和分析类
    'review', 'analysis', 'evaluation', 'assessment', 'breakdown', 'deep dive',
    'case study', 'research', 'study', 'report', 'findings',
    
    // 技巧和建议类
    'tips', 'tricks', 'hacks', 'secrets', 'strategies', 'methods', 'techniques',
    'advice', 'suggestions', 'recommendations', 'insights', 'wisdom',
    
    // 问题解决类
    'solution', 'solve', 'fix', 'troubleshoot', 'problem', 'issue', 'challenge',
    'mistake', 'error', 'avoid', 'prevent', 'overcome',
    
    // 趋势和预测类
    'trends', 'future', 'prediction', 'forecast', 'outlook', 'emerging',
    'latest', 'new', 'upcoming', 'evolution', 'development',
    
    // 深度内容标识
    'complete', 'comprehensive', 'ultimate', 'definitive', 'detailed', 'in-depth',
    'thorough', 'extensive', 'full', 'everything', 'all about',
    
    // 受众定位词
    'beginner', 'advanced', 'expert', 'professional', 'starter', 'intermediate',
    'for beginners', 'for experts', 'for professionals',
    
    // 时间相关词
    '2025', 'updated', 'latest', 'current', 'modern', 'today',
    
    // 价值主张词
    'free', 'essential', 'important', 'must-know', 'crucial', 'key',
    'proven', 'effective', 'successful', 'powerful',
    
    // === 奢侈品与高端生活类关键词 ===
    // 奢侈品核心词汇
    'luxury', 'premium', 'high-end', 'exclusive', 'elite', 'prestige', 'sophisticated',
    'upscale', 'deluxe', 'lavish', 'opulent', 'extravagant', 'refined', 'elegant',
    
    // 品质与工艺
    'craftsmanship', 'artisan', 'handcrafted', 'bespoke', 'custom', 'tailored',
    'quality', 'excellence', 'superior', 'finest', 'masterpiece', 'heritage',
    'authentic', 'genuine', 'original', 'signature', 'iconic',
    
    // 时尚与设计
    'fashion', 'style', 'design', 'designer', 'couture', 'haute couture',
    'runway', 'collection', 'seasonal', 'trendsetting', 'chic', 'glamorous',
    'sophisticated style', 'fashion forward', 'statement piece',
    
    // === 科技与创新类关键词 ===
    // 智能设备
    'smart', 'intelligent', 'connected', 'iot', 'wearable', 'device',
    'gadget', 'tech', 'technology', 'innovation', 'cutting-edge', 'advanced',
    'next-gen', 'futuristic', 'revolutionary', 'breakthrough',
    
    // 移动设备与配件
    'smartphone', 'mobile', 'phone', 'tablet', 'wearable tech', 'smartwatch',
    'fitness tracker', 'earbuds', 'wireless', 'bluetooth', 'accessories',
    'foldable', 'flexible display', 'screen technology',
    
    // 智能珠宝与配饰
    'smart ring', 'smart jewelry', 'wearable jewelry', 'tech accessories',
    'connected accessories', 'digital jewelry', 'smart wearables',
    
    // === 健康与生活方式类关键词 ===
    // 健康与健身
    'health', 'wellness', 'fitness', 'lifestyle', 'wellbeing', 'self-care',
    'mindfulness', 'meditation', 'nutrition', 'exercise', 'workout',
    'healthy living', 'life balance', 'personal care',
    
    // 品质生活
    'quality of life', 'life enhancement', 'personal development', 'self-improvement',
    'productivity', 'efficiency', 'optimization', 'performance', 'achievement',
    'success', 'goals', 'habits', 'routine', 'discipline',
    
    // === 定制与个性化服务类关键词 ===
    // 定制服务
    'customization', 'personalization', 'tailored', 'made-to-order', 'bespoke',
    'custom-made', 'personalized', 'individual', 'unique', 'one-of-a-kind',
    'exclusive service', 'concierge', 'vip', 'private', 'personal',
    
    // 服务体验
    'experience', 'service', 'consultation', 'advisory', 'expertise',
    'professional service', 'customer experience', 'user experience',
    'satisfaction', 'support', 'assistance', 'guidance',
    
    // === 投资与收藏类关键词 ===
    // 投资价值
    'investment', 'value', 'appreciation', 'collectible', 'limited edition',
    'rare', 'vintage', 'antique', 'classic', 'timeless', 'enduring',
    'resale value', 'market value', 'worth', 'price', 'cost',
    
    // === 品牌与声誉类关键词 ===
    // 品牌相关
    'brand', 'reputation', 'prestige brand', 'luxury brand', 'heritage brand',
    'established', 'renowned', 'famous', 'celebrated', 'award-winning',
    'industry leader', 'market leader', 'pioneer', 'innovator'
  ];
  
  // 排除的低质量内容关键词
  const excludeKeywords = [
    // 明显的商业推广（但保留合理的购买指南）
    'buy now', 'order now', 'click here', 'limited time', 'act fast',
    'free shipping', 'no shipping cost', 'instant delivery',
    'flash sale', 'clearance', 'discount code', 'promo code',
    
    // 低质量新闻类内容
    'breaking news', 'just announced', 'just in', 'urgent update',
    'press release', 'according to sources', 'rumor has it',
    'leaked', 'insider info', 'exclusive scoop',
    
    // 论坛和问答片段
    'forum', 'discussion board', 'thread', 'reply to', 'comment below',
    'ask question', 'need help with', 'can someone help', 'please help',
    'anyone know', 'does anyone', 'quick question',
    
    // 纯技术文档
    'api documentation', 'technical specification', 'system requirements',
    'installation guide', 'configuration file', 'code repository',
    'developer docs', 'sdk', 'api reference',
    
    // 低质量社交媒体内容
    'follow us on', 'like and subscribe', 'share this post', 'tag a friend',
    'dm us', 'slide into dms', 'check our bio', 'link in bio',
    'swipe up', 'story highlight', 'instagram story',
    
    // 低质量比较和争议内容
    'vs battle', 'who wins', 'fight', 'drama', 'controversy',
    'exposed', 'truth revealed', 'shocking', 'you won\'t believe',
    
    // 过度营销内容
    'affiliate link', 'sponsored post', 'paid promotion', 'ad content',
    'marketing material', 'sales pitch', 'promotional content'
  ];
  
  const filteredResults = searchResults.filter(result => {
    const text = (result.title + ' ' + result.snippet).toLowerCase();
    
    // 检查是否包含博客关键词
    const hasBlogKeywords = blogKeywords.some(keyword => text.includes(keyword.toLowerCase()));
    
    // 检查是否包含排除关键词
    const hasExcludeKeywords = excludeKeywords.some(keyword => text.includes(keyword.toLowerCase()));
    
    // 额外的质量检查
    const hasGoodLength = result.snippet.length > 50; // 摘要长度足够
    const hasReasonableTitle = result.title.length > 10 && result.title.length < 200; // 标题长度合理
    
    // 检查URL是否来自可信的内容平台
    const url = result.url.toLowerCase();
    const isFromContentPlatform = 
      url.includes('blog') || 
      url.includes('article') || 
      url.includes('guide') || 
      url.includes('tutorial') ||
      url.includes('medium.com') ||
      url.includes('wordpress') ||
      url.includes('substack') ||
      url.includes('hashnode') ||
      url.includes('dev.to') ||
      url.includes('hackernoon') ||
      url.includes('towards') ||
      url.includes('freecodecamp') ||
      url.includes('smashingmagazine') ||
      url.includes('css-tricks') ||
      url.includes('alistapart') ||
      url.includes('moz.com') ||
      url.includes('searchengineland') ||
      url.includes('contentmarketinginstitute') ||
      url.includes('hubspot.com/blog') ||
      url.includes('blog.') ||
      url.includes('/blog/') ||
      url.includes('/article/') ||
      url.includes('/post/') ||
      url.includes('/guide/') ||
      url.includes('/tutorial/') ||
      // 高端生活方式和科技媒体平台
      url.includes('vogue') ||
      url.includes('gq') ||
      url.includes('esquire') ||
      url.includes('robb report') ||
      url.includes('luxurydaily') ||
      url.includes('hypebeast') ||
      url.includes('techcrunch') ||
      url.includes('theverge') ||
      url.includes('wired') ||
      url.includes('engadget') ||
      url.includes('ars-technica') ||
      url.includes('cnet') ||
      url.includes('zdnet') ||
      url.includes('forbes') ||
      url.includes('bloomberg') ||
      url.includes('wsj') ||
      url.includes('ft.com') ||
      url.includes('luxury') ||
      url.includes('lifestyle') ||
      url.includes('fashion') ||
      url.includes('wellness') ||
      url.includes('health');
    
    // 综合判断：包含博客关键词，不包含排除关键词，质量检查通过
    return hasBlogKeywords && 
           !hasExcludeKeywords && 
           hasGoodLength && 
           hasReasonableTitle && 
           (isFromContentPlatform || hasBlogKeywords);
  });
  
  // 过滤后重新分配连续的originalIndex，确保页面显示的排序编号正确
  return filteredResults.map((result, index) => ({
    ...result,
    originalIndex: index + 1
  }));
}

/**
 * 备用搜索方法（当AI方法失败时使用）
 * @param keyword - 主关键词
 * @param blogIdea - 博客创意
 * @param targetMarket - 目标市场
 * @param targetLanguage - 目标语言
 * @param timeRange - 时间范围
 * @param searchKeyword - 搜索关键词函数
 * @returns 搜索结果
 */
export async function fallbackSearch(
  keyword: string,
  blogIdea: string,
  targetMarket: string,
  targetLanguage: string,
  timeRange: string,
  searchKeyword: (query: string, market: string, language: string, time: string) => Promise<SearchResult[]>
): Promise<SearchResult[]> {
  console.log('使用备用搜索方法');
  
  // 简单的备用查询
  const fallbackQueries = [
    `${keyword} guide tutorial blog`,
    `${keyword} tips best practices`,
    `${keyword} complete guide 2025`
  ];
  
  const allResults: SearchResult[] = [];
  let globalIndexCounter = 1; // 全局索引计数器，确保唯一性
  
  for (const query of fallbackQueries) {
    try {
      const results = await searchKeyword(query, targetMarket, targetLanguage, timeRange);
      
      // 重新分配唯一的originalIndex，避免重复
      const resultsWithUniqueIndex = results.map(result => ({
        ...result,
        originalIndex: globalIndexCounter++
      }));
      
      allResults.push(...resultsWithUniqueIndex);
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.warn(`备用查询"${query}"失败:`, error);
    }
  }
  
  // 去重并返回
  const uniqueResults = removeDuplicateResults(allResults);
  
  // 去重后重新分配连续的originalIndex，确保显示序号的一致性
  const reindexedResults = uniqueResults.map((result, index) => ({
    ...result,
    originalIndex: index + 1
  }));
  
  return reindexedResults.slice(0, 15);
}

/**
 * 移除重复的搜索结果
 * @param results - 搜索结果数组
 * @returns 去重后的结果
 */
export function removeDuplicateResults(results: SearchResult[]): SearchResult[] {
  const seen = new Set<string>();
  return results.filter(result => {
    const key = result.url.toLowerCase();
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
} 
/**
 * 搜索结果接口
 */
export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  originalIndex?: number; // 原始搜索结果中的索引位置
  aiRelevanceScore?: number; // AI相关性评分
  finalScore?: number; // 最终评分
  contentType?: string; // 内容类型
  qualityScore?: number; // 质量评分
  referenceValue?: string; // 参考价值
  aiReason?: string; // AI评分理由
  sourceQuery?: string; // 来源搜索查询
}

/**
 * 博客灵感接口
 */
export interface BlogIdea {
  title: string;
  type: 'Listicle' | 'How-to-Guide' | 'Comparison' | 'Why' | 'Tips' | 'Case-Study' | 'FAQ' | 'Trends' | 'Review' | 'Myth-Busting' | 'Infographic' | 'Expert-Interview' | 'Resource-Roundup' | 'Personal-Story' | 'Template-Checklist';
  description: string;
  keywords: string[];
}

/**
 * 搜索意图接口
 */
export interface SearchIntent {
  intent: string;
  confidence: number;
  description: string;
  intentList: string[];
}

/**
 * 博客标题接口
 */
export interface BlogTitle {
  title: string;
  seoScore: number;
  readabilityScore: number;
  keywords: string[];
}

/**
 * 文章大纲接口
 */
export interface BlogOutline {
  title: string;
  introduction: string;
  sections: OutlineSection[];
  conclusion: string;
  wordCount: string;
  readabilityLevel: string;
  toneStyle: string;
  perspective: string;
  seoKeywords: string[];
}

/**
 * 大纲章节接口
 */
export interface OutlineSection {
  heading: string;
  subheadings: string[];
  keyPoints: string[];
  estimatedWords: number;
}

/**
 * 文章内容分析结果接口
 */
export interface ArticleAnalysis {
  url: string;
  title: string;
  outline: string[];
  style: string;
  tone: string;
  structure: string;
  keyPoints: string[];
}

/**
 * 生成的文章历史记录接口
 */
export interface GeneratedArticle {
  id: string;
  title: string;
  content: string;
  keywords: string[];
  createdAt: string;
  wordCount?: number;
  outline?: BlogOutline;
  seoScore?: number;
  readabilityScore?: number;
}

/**
 * AI模型类型定义
 */
export type AIModel = 'gemini-1.5-flash' | 'gpt-4o' | 'claude-3-sonnet' | 'deepseek-chat';

/**
 * AI模型配置接口
 */
export interface AIModelConfig {
  name: AIModel;
  priority: number;
  apiKey?: string;
  baseUrl?: string;
  maxTokens?: number;
  temperature?: number;
}

/**
 * AI调用结果接口
 */
export interface AICallResult {
  success: boolean;
  content?: string;
  model: AIModel;
  error?: string;
  responseTime?: number;
} 
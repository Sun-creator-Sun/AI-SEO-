import { NextRequest, NextResponse } from 'next/server'
import { GoogleGenAI } from "@google/genai"
import { createNetworkDiagnosticError } from '@/lib/proxy-helper'

const GEMINI_API_KEY = 'AIzaSyB6dj7Pya87G-D0WmPsrP1TXfDaPeNzhXU'

/**
 * 测试Gemini grounding功能的API路由
 * 注意：此API使用@google/genai包，可能需要配置系统代理
 */
export async function POST(request: NextRequest) {
  try {
    const { prompt, useGrounding = true } = await request.json()

    if (!prompt) {
      return NextResponse.json(
        { error: '缺少prompt参数' },
        { status: 400 }
      )
    }

    console.log('初始化Gemini AI...')
    console.log('API Key前缀:', GEMINI_API_KEY.substring(0, 10) + '...')
    console.log('使用Grounding:', useGrounding)

    // 初始化Gemini AI - 严格按照示例
    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY })

    console.log('发送请求到Gemini API...')
    console.log('Prompt:', prompt)

    let response
    
    if (useGrounding) {
      // 严格按照用户示例实现grounding请求
      response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [prompt],
        config: {
          tools: [{googleSearch: {}}],
        },
      })
    } else {
      // 基本请求，不使用grounding
      response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [prompt],
      })
    }

    console.log('收到Gemini响应')
    console.log('Response type:', typeof response)
    console.log('Response keys:', Object.keys(response))

    // 获取响应文本 - 按照示例使用 response.text
    const text = response.text
    console.log('响应文本:', text)
    
    // 检查是否有grounding metadata - 严格按照示例
    let groundingMetadata = null
    let renderedContent = null
    
    if (response.candidates && response.candidates[0]) {
      const candidate = response.candidates[0]
      console.log('Candidate keys:', Object.keys(candidate))
      
      if (candidate.groundingMetadata) {
        groundingMetadata = candidate.groundingMetadata
        console.log('找到grounding metadata:', JSON.stringify(groundingMetadata, null, 2))
        
        // 按照示例获取搜索入口点渲染内容
        if (candidate.groundingMetadata.searchEntryPoint) {
          renderedContent = candidate.groundingMetadata.searchEntryPoint.renderedContent
          console.log('搜索入口点渲染内容:', renderedContent)
        }
      } else {
        console.log('没有找到grounding metadata')
        console.log('Candidate结构:', JSON.stringify(candidate, null, 2))
      }
    }

    return NextResponse.json({
      text,
      groundingMetadata: groundingMetadata ? JSON.stringify(groundingMetadata, null, 2) : null,
      renderedContent,
      hasGrounding: !!groundingMetadata,
      fullResponse: response,
      proxy: '使用@google/genai包'
    })

  } catch (error) {
    console.error('Gemini API详细错误:', error)
    console.error('错误类型:', typeof error)
    console.error('错误名称:', error?.constructor?.name)
    
    if (error instanceof Error) {
      console.error('错误消息:', error.message)
      console.error('错误堆栈:', error.stack)
    }

    // 检查是否是网络连接错误
    if (error instanceof Error && 
        (error.message.includes('fetch failed') || 
         error.message.includes('timeout') || 
         error.message.includes('ENOTFOUND') ||
         error.message.includes('ECONNREFUSED'))) {
      
      console.log('检测到网络连接错误，提供代理配置建议')
      const networkDiagnostic = createNetworkDiagnosticError(error, 'Gemini Grounding API');
      networkDiagnostic.suggestions.push('注意：此API使用@google/genai包，可能需要配置系统级代理')
      networkDiagnostic.suggestions.push('考虑使用其他API路径（如/api/extract-seo-knowledge）')
      
      return NextResponse.json(networkDiagnostic, { status: 502 });
    }
    
    return NextResponse.json(
      { 
        error: error instanceof Error ? error.message : '未知错误',
        errorType: error?.constructor?.name || 'Unknown',
        details: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    )
  }
} 
import { NextRequest, NextResponse } from 'next/server';

/**
 * 使用Jina.ai API抓取单个网页内容
 * @param url - 目标URL
 * @returns 抓取的纯文本内容
 */
async function scrapeWithJina(url: string): Promise<string> {
  try {
    console.log(`🔍 尝试使用Jina.ai抓取: ${url}`);
    
    const jinaUrl = `https://r.jina.ai/${url}`;
    
    const response = await fetch(jinaUrl, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer jina_5025f50722184017999eac2ce6f27831CuBCqqtl7tX8oKYECPZr7ueNHUSd',
        'User-Agent': 'Mozilla/5.0 (compatible; WebScraper/1.0)'
      }
    });
    
    if (!response.ok) {
      const statusCode = response.status;
      const statusText = response.statusText;
      
      if (statusCode === 402) {
        throw new Error(`HTTP 402 - Jina.ai API需要付费或配额已用完`);
      } else if (statusCode === 404) {
        throw new Error(`HTTP 404 - 页面未找到: ${url}`);
      } else if (statusCode >= 500 && statusCode < 600) {
        throw new Error(`HTTP ${statusCode} - 服务器错误: ${statusText}`);
      } else if (statusCode === 403) {
        throw new Error(`HTTP 403 - 访问被拒绝: ${url}`);
      } else if (statusCode === 401) {
        throw new Error(`HTTP 401 - 未授权访问: ${url}`);
      } else if (statusCode >= 400 && statusCode < 500) {
        throw new Error(`HTTP ${statusCode} - 客户端错误: ${statusText}`);
      } else {
        throw new Error(`HTTP ${statusCode} - 请求失败: ${statusText}`);
      }
    }
    
    const content = await response.text();
    
    if (!content || content.trim().length === 0) {
      throw new Error('HTTP 200 - 但抓取的内容为空');
    }
    
    const contentLower = content.toLowerCase();
    if (contentLower.includes('404 not found') || 
        contentLower.includes('page not found') ||
        contentLower.includes('404 error')) {
      throw new Error('HTTP 404 - 页面内容显示未找到');
    }
    
    if (contentLower.includes('500 internal server error') ||
        contentLower.includes('502 bad gateway') ||
        contentLower.includes('503 service unavailable') ||
        contentLower.includes('504 gateway timeout')) {
      throw new Error('HTTP 50x - 页面内容显示服务器错误');
    }
    
    if (content.trim().length < 50) {
      throw new Error('HTTP 200 - 但内容过短，可能是错误页面');
    }
    
    console.log(`✅ Jina.ai成功抓取，长度: ${content.length}字符`);
    return content;
    
  } catch (error) {
    console.error(`❌ Jina.ai抓取失败 ${url}:`, error);
    throw error;
  }
}

/**
 * 使用备用API抓取网页内容
 * @param url - 目标URL
 * @returns 抓取的纯文本内容
 */
async function scrapeWithBackupAPI(url: string): Promise<string> {
  const backupServices = [
    {
      name: 'AllOrigins',
      url: `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
      extract: (data: any) => data.contents
    },
    {
      name: 'CORS Anywhere',
      url: `https://cors-anywhere.herokuapp.com/${url}`,
      extract: (data: any) => data
    },
    {
      name: 'Archive.org',
      url: `https://web.archive.org/web/${url}`,
      extract: (data: any) => data
    }
  ];

  for (const service of backupServices) {
    try {
      console.log(`🔍 尝试使用${service.name}抓取: ${url}`);
      
      const response = await fetch(service.url, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; WebScraper/1.0)'
        }
      });
      
      if (!response.ok) {
        throw new Error(`${service.name}返回错误: ${response.status} ${response.statusText}`);
      }
      
      let data;
      if (service.name === 'Archive.org') {
        // Archive.org返回HTML，直接使用
        data = await response.text();
      } else {
        data = await response.json();
      }
      
      const htmlContent = service.extract(data);
      
      if (!htmlContent) {
        throw new Error(`${service.name}返回内容为空`);
      }
      
      // 简单的HTML到文本转换
      const textContent = htmlContent
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '') // 移除script标签
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '') // 移除style标签
        .replace(/<[^>]+>/g, ' ') // 移除所有HTML标签
        .replace(/\s+/g, ' ') // 合并多个空格
        .trim();
      
      if (textContent.length < 100) {
        throw new Error(`${service.name}抓取内容过短`);
      }
      
      console.log(`✅ ${service.name}成功抓取，长度: ${textContent.length}字符`);
      return textContent;
      
    } catch (error) {
      console.warn(`⚠️ ${service.name}抓取失败:`, error instanceof Error ? error.message : String(error));
      // 继续尝试下一个服务
    }
  }
  
  throw new Error('所有备用API服务都失败了');
}

/**
 * 使用直接fetch抓取网页内容（最后尝试）
 * @param url - 目标URL
 * @returns 抓取的纯文本内容
 */
async function scrapeWithDirectFetch(url: string): Promise<string> {
  try {
    console.log(`🔍 尝试直接fetch抓取: ${url}`);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      }
    });
    
    if (!response.ok) {
      throw new Error(`直接fetch返回错误: ${response.status} ${response.statusText}`);
    }
    
    const htmlContent = await response.text();
    
    if (!htmlContent || htmlContent.trim().length === 0) {
      throw new Error('直接fetch返回内容为空');
    }
    
    // 简单的HTML到文本转换
    const textContent = htmlContent
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    if (textContent.length < 100) {
      throw new Error('直接fetch抓取内容过短');
    }
    
    console.log(`✅ 直接fetch成功抓取，长度: ${textContent.length}字符`);
    return textContent;
    
  } catch (error) {
    console.error(`❌ 直接fetch抓取失败 ${url}:`, error);
    throw error;
  }
}

/**
 * 使用多种策略抓取单个网页内容
 * @param url - 目标URL
 * @returns 抓取的纯文本内容
 */
async function scrapeWebContent(url: string): Promise<string> {
  const strategies = [
    { name: 'Jina.ai', fn: scrapeWithJina },
    { name: '备用API', fn: scrapeWithBackupAPI },
    { name: '直接fetch', fn: scrapeWithDirectFetch }
  ];
  
  let lastError: Error | null = null;
  
  for (const strategy of strategies) {
    try {
      console.log(`🔄 尝试策略: ${strategy.name}`);
      const content = await strategy.fn(url);
      console.log(`✅ 策略 ${strategy.name} 成功`);
      return content;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.warn(`⚠️ 策略 ${strategy.name} 失败:`, lastError.message);
      
      // 在策略之间添加短暂延迟
      if (strategy !== strategies[strategies.length - 1]) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }
  
  // 所有策略都失败了
  throw new Error(`所有抓取策略都失败了。最后错误: ${lastError?.message || '未知错误'}`);
}

/**
 * 批量抓取多个网页内容
 * @param urls - URL数组
 * @param maxConcurrency - 最大并发数
 * @returns 抓取结果数组
 */
async function batchScrapeWebContent(
  urls: string[], 
  maxConcurrency: number = 3
): Promise<Array<{ url: string; content?: string; error?: string; retries?: number }>> {
  console.log(`开始批量抓取 ${urls.length} 个网页，最大并发数: ${maxConcurrency}`);
  
  const results: Array<{ url: string; content?: string; error?: string; retries?: number }> = [];
  
  // 分批处理URL，控制并发数
  for (let i = 0; i < urls.length; i += maxConcurrency) {
    const batch = urls.slice(i, i + maxConcurrency);
    console.log(`处理第 ${Math.floor(i / maxConcurrency) + 1} 批，包含 ${batch.length} 个URL`);
    
    const batchPromises = batch.map(async (url) => {
      let retries = 0;
      const maxRetries = 2;
      
      while (retries <= maxRetries) {
        try {
          if (retries > 0) {
            console.log(`🔄 重试第 ${retries} 次: ${url}`);
            // 重试时增加延迟
            await new Promise(resolve => setTimeout(resolve, 2000 * retries));
          }
          
          const content = await scrapeWebContent(url);
          return { url, content, retries };
        } catch (error) {
          retries++;
          const errorMessage = error instanceof Error ? error.message : '未知错误';
          
          // 如果是最后一次重试，记录失败
          if (retries > maxRetries) {
            console.warn(`❌ URL抓取最终失败: ${url} - ${errorMessage} (重试${retries-1}次)`);
            return { url, error: errorMessage, retries: retries - 1 };
          } else {
            console.warn(`⚠️ URL抓取失败，准备重试: ${url} - ${errorMessage}`);
          }
        }
      }
      
      // 确保总是返回一个结果
      return { url, error: '重试次数已用完', retries: maxRetries };
    });
    
    const batchResults = await Promise.all(batchPromises);
    results.push(...batchResults);
    
    // 避免请求过于频繁，批次之间添加延迟
    if (i + maxConcurrency < urls.length) {
      console.log('等待2秒后处理下一批...');
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }
  
  const successful = results.filter(r => r.content).length;
  const failed = results.filter(r => r.error).length;
  const totalRetries = results.reduce((sum, r) => sum + (r.retries || 0), 0);
  
  console.log(`批量抓取完成，成功: ${successful}，失败: ${failed}，总重试次数: ${totalRetries}`);
  
  // 分析失败原因并提供建议
  if (successful === 0 && failed > 0) {
    console.error('⚠️ 所有URL抓取都失败了，可能的原因：');
    console.error('1. 网络连接问题');
    console.error('2. 目标网站反爬虫机制');
    console.error('3. API服务限制或配额用完');
    console.error('4. 代理配置问题');
    console.error('5. 目标网站需要JavaScript渲染');
  } else if (failed > 0) {
    console.warn(`⚠️ 部分URL抓取失败 (${failed}/${results.length})`);
  }
  
  return results;
}

// POST请求处理器
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { urls, maxConcurrency = 3 } = body;
    
    // 验证输入参数
    if (!urls || !Array.isArray(urls) || urls.length === 0) {
      return NextResponse.json(
        { error: '无效的URL数组' },
        { status: 400 }
      );
    }
    
    // 限制URL数量，避免过载
    const limitedUrls = urls.slice(0, 10);
    
    // 执行批量抓取
    const results = await batchScrapeWebContent(limitedUrls, maxConcurrency);
    
    const successful = results.filter(r => r.content).length;
    const failed = results.filter(r => r.error).length;
    
    return NextResponse.json({
      success: successful > 0,
      results,
      summary: {
        total: results.length,
        successful,
        failed
      },
      recommendations: failed > 0 ? [
        '如果所有URL都失败，请检查网络连接',
        '某些网站可能有反爬虫机制',
        '可以尝试减少并发数或增加延迟',
        '考虑使用代理服务'
      ] : undefined
    });
    
  } catch (error) {
    console.error('抓取API错误:', error);
    return NextResponse.json(
      { 
        error: '抓取失败',
        details: error instanceof Error ? error.message : '未知错误'
      },
      { status: 500 }
    );
  }
} 
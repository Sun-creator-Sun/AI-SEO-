import { NextRequest, NextResponse } from 'next/server';
import { getGENERATIVE_AI_KEY, AI_MODEL } from '@/lib/config';
import { getProxyConfig } from '@/lib/proxy-helper';
import { callGeminiDirectly } from '@/lib/gemini-direct-api';

/**
 * 使用 Gemini 模型进行SEO关键词提取
 * 专门用于博客标题生成第三步的知识点提取
 * @param content 要分析的内容
 * @param prompt 自定义提示词
 * @returns Promise<{keywords: string[], usingProxy: boolean, proxyMode: string}> 关键词数组和代理使用信息
 */
async function extractSEOKeywords(content: string, prompt: string): Promise<{keywords: string[], usingProxy: boolean, proxyMode: string}> {
  console.log('🤖 使用Gemini直接API调用提取SEO知识点...');
  console.log('📝 内容长度:', content.length);
  
  // 限制内容长度，防止API调用失败
  const maxContentLength = 32000; // SEO知识点提取使用较短的内容
  let processedContent = content;
  
  if (content.length > maxContentLength) {
    console.log(`⚠️ 内容过长 (${content.length}字符)，截取前${maxContentLength}字符`);
    processedContent = content.substring(0, maxContentLength) + '...';
  }

  // 构建完整的提示词，包含内容
  const question = `${prompt}

Content to analyze:
${processedContent}`;

  // 使用配置中的原始模型名称
  const modelName = AI_MODEL || 'gemini-1.5-flash';
  console.log('🔑 使用模型:', modelName);
  console.log('📋 提取模式: SEO知识点提取');

  // SEO知识点提取专用的generationConfig
  const seoGenerationConfig = {
    temperature: 0.3,
    topK: 20,
    topP: 0.95,
    maxOutputTokens: 65536,
    // 强制JSON数组输出
    responseMimeType: "application/json",
    responseSchema: {
      type: "array",
      items: { 
        type: "string",
        description: "SEO关键词或知识点"
      },
      description: "SEO关键词数组，每个元素都是字符串类型的关键词或知识点"
    }
  };

  try {
    console.log('🚀 开始SEO知识点提取API调用...');
    
    const apiKey = getGENERATIVE_AI_KEY();
    const directResult = await callGeminiDirectly(apiKey, modelName, question, seoGenerationConfig);
    
    if (directResult.success && directResult.data) {
      console.log('✅ SEO知识点提取API调用成功');
      console.log('📄 响应长度:', directResult.data.length);
      
      const keywords = parseSEOKeywords(directResult.data);
      
      // 确定代理模式
      const proxyMode = directResult.proxyUsed ? 'ClashX代理 - 直接API调用' : '无代理 - 直接连接';
      
      return { 
        keywords, 
        usingProxy: !!directResult.proxyUsed, 
        proxyMode
      };
    } else {
      throw new Error(directResult.error || '直接API调用失败');
    }
  } catch (error) {
    console.error('❌ SEO知识点提取API调用失败:', error);
    throw error;
  }
}

/**
 * 解析SEO关键词响应
 * 专门用于解析SEO知识点提取的JSON数组响应
 * @param generatedText API返回的文本
 * @returns string[] 解析出的关键词
 */
function parseSEOKeywords(generatedText: string): string[] {
  console.log('🔍 开始解析SEO知识点响应...');
  console.log('📝 响应长度:', generatedText.length);
  
  try {
    // SEO知识点提取模式：期望直接返回字符串数组
    console.log('📋 使用SEO知识点提取解析模式');
    
    const keywordsArray = JSON.parse(generatedText);
    
    if (!Array.isArray(keywordsArray)) {
      throw new Error('SEO知识点提取模式期望返回数组，但得到的不是数组');
    }
    
    // 过滤和清理关键词
    const cleanedKeywords = keywordsArray
      .filter(item => typeof item === 'string' && item.trim().length > 0)
      .map(item => item.trim())
      .slice(0, 20); // 限制数量
    
    console.log('✅ SEO知识点提取成功，提取关键词:', cleanedKeywords.length, '个');
    return cleanedKeywords;
    
  } catch (error) {
    console.error('❌ JSON解析失败:', error);
    throw new Error(`JSON解析失败: ${error instanceof Error ? error.message : '未知错误'}`);
  }
}

/**
 * SEO知识点提取API路由
 */
export async function POST(request: NextRequest) {
  console.log('=== SEO知识点提取API请求开始 ===');
  
  try {
    const { prompt, content } = await request.json();

    if (!content) {
      throw new Error('缺少content参数');
    }

    if (!prompt) {
      throw new Error('缺少prompt参数');
    }

    const apiKey = getGENERATIVE_AI_KEY();
    if (!apiKey) {
      throw new Error('未配置Gemini API密钥');
    }

    console.log('✅ 收到SEO知识点提取请求');
    console.log('📝 内容长度:', content.length);
    console.log('📋 提示词长度:', prompt.length);
    console.log('🔑 API密钥已配置');

    // 提取SEO关键词
    const { keywords, usingProxy, proxyMode } = await extractSEOKeywords(content, prompt);
    
    console.log('✅ 成功提取SEO关键词:', keywords.length, '个');
    
    // 获取代理信息并返回成功响应
    const proxyConfig = getProxyConfig();
    const actualModel = AI_MODEL || 'gemini-1.5-flash';
    
    return NextResponse.json({ 
      knowledge: keywords,
      method: 'Direct API - SEO Knowledge Extraction',
      model: actualModel,
      note: '使用专门的SEO知识点提取API成功提取',
      usingProxy,
      proxy: proxyConfig.proxy || null,
      proxyMode
    });

  } catch (error) {
    console.error('❌ SEO知识点提取过程中出错:', error);
    
    // 获取代理信息并返回错误响应
    const proxyConfig = getProxyConfig();
    const actualModel = AI_MODEL || 'gemini-1.5-flash';
    const errorMessage = error instanceof Error ? error.message : '提取SEO知识点失败';
    
    return NextResponse.json(
      { 
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown',
        method: 'Direct API - SEO Knowledge Extraction (失败)',
        model: actualModel,
        usingProxy: proxyConfig.detected,
        proxy: proxyConfig.proxy || null,
        proxyMode: proxyConfig.detected ? 'ClashX检测到但API调用失败' : '无代理检测到'
      },
      { status: 500 }
    );
  } finally {
    console.log('=== SEO知识点提取API请求结束 ===');
  }
} 
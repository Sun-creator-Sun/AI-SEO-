import { NextRequest, NextResponse } from 'next/server';
import { apiKeyManager } from '@/lib/api-key-manager';

/**
 * 获取所有API Key状态
 */
export async function GET() {
  try {
    const keyStatus = apiKeyManager.getAllKeyStatus();
    const usageStats = apiKeyManager.getUsageStats();
    
    return NextResponse.json({
      success: true,
      data: {
        keys: keyStatus,
        stats: usageStats
      }
    });
  } catch (error) {
    console.error('Failed to get API key status:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get API key status' },
      { status: 500 }
    );
  }
}

/**
 * 添加新的API Key
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { key, name, provider, rateLimit, priority } = body;
    
    if (!key || !name || !provider) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields: key, name, provider' },
        { status: 400 }
      );
    }
    
    const keyConfig = {
      key,
      name,
      provider: provider as 'gemini' | 'openai' | 'claude' | 'deepseek',
      rateLimit: rateLimit || {
        requestsPerMinute: 60,
        requestsPerHour: 1000,
        requestsPerDay: 10000
      },
      priority: priority || 999,
      enabled: true,
      errorCount: 0,
      maxErrors: 5,
      cooldownMinutes: 10
    };
    
    apiKeyManager.addKey(keyConfig);
    
    return NextResponse.json({
      success: true,
      message: 'API key added successfully'
    });
  } catch (error) {
    console.error('Failed to add API key:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to add API key' },
      { status: 500 }
    );
  }
}

/**
 * 更新API Key状态
 */
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { key, enabled, resetErrors } = body;
    
    if (!key) {
      return NextResponse.json(
        { success: false, error: 'Missing key parameter' },
        { status: 400 }
      );
    }
    
    let success = false;
    
    if (resetErrors) {
      success = apiKeyManager.resetKeyErrors(key);
    } else if (enabled !== undefined) {
      success = apiKeyManager.setKeyEnabled(key, enabled);
    }
    
    if (success) {
      return NextResponse.json({
        success: true,
        message: resetErrors ? 'Error count reset successfully' : 'Key status updated successfully'
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Key not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Failed to update API key:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update API key' },
      { status: 500 }
    );
  }
}

/**
 * 删除API Key
 */
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');
    
    if (!key) {
      return NextResponse.json(
        { success: false, error: 'Missing key parameter' },
        { status: 400 }
      );
    }
    
    const success = apiKeyManager.removeKey(key);
    
    if (success) {
      return NextResponse.json({
        success: true,
        message: 'API key removed successfully'
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Key not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Failed to remove API key:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to remove API key' },
      { status: 500 }
    );
  }
} 
import { NextRequest, NextResponse } from 'next/server'

const PEXELS_API_KEY = '85BZ9pDaOGiR6uEaQUG5o25Zd1SDP1h4S1ctYXuyWoAP8sG1M4qL4QaC'

/**
 * Pexels图片搜索接口
 */
export interface PexelsPhoto {
  id: number
  url: string
  photographer: string
  photographer_url: string
  src: {
    original: string
    large2x: string
    large: string
    medium: string
    small: string
    portrait: string
    landscape: string
    tiny: string
  }
  alt: string
  width: number
  height: number
}

/**
 * Pexels搜索响应接口
 */
export interface PexelsSearchResponse {
  photos: PexelsPhoto[]
  total_results: number
  page: number
  per_page: number
  next_page?: string
}

/**
 * 搜索Pexels图片
 * @param query - 搜索关键词
 * @param per_page - 每页数量，默认10
 * @param page - 页码，默认1
 */
export async function POST(request: NextRequest) {
  try {
    const { query, per_page = 10, page = 1 } = await request.json()

    if (!query) {
      return NextResponse.json(
        { success: false, error: '搜索关键词不能为空' },
        { status: 400 }
      )
    }

    console.log(`🖼️ 搜索Pexels图片: "${query}"`)

    // 调用Pexels API
    const response = await fetch(
      `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=${per_page}&page=${page}`,
      {
        method: 'GET',
        headers: {
          'Authorization': PEXELS_API_KEY,
          'Content-Type': 'application/json'
        }
      }
    )

    if (!response.ok) {
      throw new Error(`Pexels API错误: ${response.status} ${response.statusText}`)
    }

    const data: PexelsSearchResponse = await response.json()

    console.log(`✅ 找到${data.photos.length}张图片`)

    return NextResponse.json({
      success: true,
      data: {
        photos: data.photos,
        total_results: data.total_results,
        page: data.page,
        per_page: data.per_page,
        next_page: data.next_page
      }
    })

  } catch (error) {
    console.error('❌ Pexels搜索失败:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : '图片搜索失败' 
      },
      { status: 500 }
    )
  }
}

/**
 * 获取热门图片
 */
export async function GET() {
  try {
    console.log('🖼️ 获取Pexels热门图片')

    const response = await fetch(
      'https://api.pexels.com/v1/curated?per_page=15&page=1',
      {
        method: 'GET',
        headers: {
          'Authorization': PEXELS_API_KEY,
          'Content-Type': 'application/json'
        }
      }
    )

    if (!response.ok) {
      throw new Error(`Pexels API错误: ${response.status} ${response.statusText}`)
    }

    const data: PexelsSearchResponse = await response.json()

    console.log(`✅ 获取${data.photos.length}张热门图片`)

    return NextResponse.json({
      success: true,
      data: {
        photos: data.photos,
        total_results: data.total_results,
        page: data.page,
        per_page: data.per_page
      }
    })

  } catch (error) {
    console.error('❌ 获取热门图片失败:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : '获取图片失败' 
      },
      { status: 500 }
    )
  }
} 
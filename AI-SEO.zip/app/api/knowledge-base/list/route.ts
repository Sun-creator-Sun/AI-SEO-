import { NextRequest, NextResponse } from 'next/server'
import { FASTGPT_CONFIG } from '@/lib/fastgpt-config'

export interface KnowledgeBase {
  _id: string
  parentId: string | null
  avatar: string
  name: string
  intro: string
  type: string
  permission: string
  canWrite: boolean
  isOwner: boolean
  vectorModel: {
    model: string
    name: string
    charsPointsPrice: number
    defaultToken: number
    maxToken: number
    weight: number
  }
}

export interface KnowledgeBaseListResponse {
  code: number
  statusText: string
  message: string
  data: KnowledgeBase[]
}

/**
 * 获取知识库列表
 */
export async function POST(request: NextRequest) {
  try {
    const { parentId = '' } = await request.json()

    const response = await fetch(`${FASTGPT_CONFIG.BASE_URL}${FASTGPT_CONFIG.ENDPOINTS.DATASET_LIST}?parentId=${parentId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${FASTGPT_CONFIG.TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        parentId: parentId || ''
      })
    })

    if (!response.ok) {
      throw new Error(`获取知识库列表失败: ${response.statusText}`)
    }

    const data: KnowledgeBaseListResponse = await response.json()
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('获取知识库列表错误:', error)
    return NextResponse.json(
      { 
        error: '获取知识库列表失败',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    )
  }
} 
// 设置该路由为动态路由
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server'
import { FASTGPT_CONFIG } from '@/lib/fastgpt-config'

export interface KnowledgeBaseDetail {
  _id: string
  parentId: string | null
  teamId: string
  tmbId: string
  type: string
  status: string
  avatar: string
  name: string
  vectorModel: {
    model: string
    name: string
    charsPointsPrice: number
    defaultToken: number
    maxToken: number
    weight: number
  }
  agentModel: {
    model: string
    name: string
    maxContext: number
    maxResponse: number
    charsPointsPrice: number
  }
  intro: string
  permission: string
  updateTime: string
  canWrite: boolean
  isOwner: boolean
}

export interface KnowledgeBaseDetailResponse {
  code: number
  statusText: string
  message: string
  data: KnowledgeBaseDetail
}

/**
 * 获取知识库详情
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: '知识库ID不能为空' },
        { status: 400 }
      )
    }

    const response = await fetch(`${FASTGPT_CONFIG.BASE_URL}${FASTGPT_CONFIG.ENDPOINTS.DATASET_DETAIL}?id=${id}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${FASTGPT_CONFIG.TOKEN}`,
      }
    })

    if (!response.ok) {
      throw new Error(`获取知识库详情失败: ${response.statusText}`)
    }

    const data: KnowledgeBaseDetailResponse = await response.json()
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('获取知识库详情错误:', error)
    return NextResponse.json(
      { 
        error: '获取知识库详情失败',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    )
  }
} 
import { NextRequest, NextResponse } from 'next/server'
import { FASTGPT_CONFIG, generateChatId, generateResponseId } from '@/lib/fastgpt-config'

export interface ExtractKnowledgeRequest {
  knowledgeBaseId: string
  question: string
  questionImprovePrompt?: string
  extractKnowledgePrompt?: string
}

export interface ExtractKnowledgeResponse {
  id: string
  model: string
  usage: {
    prompt_tokens: number
    completion_tokens: number
    total_tokens: number
  }
  choices: Array<{
    message: {
      role: string
      content: string
    }
    finish_reason: string
    index: number
  }>
}

/**
 * 从知识库提取知识
 */
export async function POST(request: NextRequest) {
  try {
    const { 
      knowledgeBaseId, 
      question, 
      questionImprovePrompt = 'Please improve and optimize this question for better knowledge retrieval from the knowledge base.',
      extractKnowledgePrompt = 'Please extract and organize the relevant knowledge from the search results in a clear and structured format.'
    }: ExtractKnowledgeRequest = await request.json()

    if (!knowledgeBaseId || !question) {
      return NextResponse.json(
        { error: '知识库ID和问题不能为空' },
        { status: 400 }
      )
    }

    // 生成唯一的聊天ID和响应ID
    const chatId = generateChatId()
    const responseChatItemId = generateResponseId()

    const requestBody = {
      chatId,
      stream: false,
      detail: false,
      responseChatItemId,
      variables: {
        knowledge_base_id: [{"datasetId": knowledgeBaseId}],
        question_improve_prompt: questionImprovePrompt,
        extract_knowledge_prompt: extractKnowledgePrompt
      },
      messages: [
        {
          role: 'user',
          content: question
        }
      ]
    }
    console.log(requestBody)

    const response = await fetch(`${FASTGPT_CONFIG.BASE_URL}${FASTGPT_CONFIG.ENDPOINTS.CHAT_COMPLETIONS}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${FASTGPT_CONFIG.TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody)
    })

    if (!response.ok) {
      throw new Error(`从知识库提取知识失败: ${response.statusText}`)
    }

    const data: ExtractKnowledgeResponse = await response.json()
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('从知识库提取知识错误:', error)
    return NextResponse.json(
      { 
        error: '从知识库提取知识失败',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    )
  }
} 
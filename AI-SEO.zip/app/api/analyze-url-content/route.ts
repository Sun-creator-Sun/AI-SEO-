import { NextRequest, NextResponse } from 'next/server';
import { getGENERATIVE_AI_KEY, AI_MODEL } from '@/lib/config';
import { getProxyConfig } from '@/lib/proxy-helper';
import { callGeminiDirectly } from '@/lib/gemini-direct-api';

/**
 * 使用 Gemini 模型进行URL内容分析
 * 专门用于提取品牌、产品和相关信息
 * @param content 要分析的内容
 * @param customPrompt 自定义提示词（可选）
 * @returns Promise<{analysis: any, usingProxy: boolean, proxyMode: string}> 完整分析和代理使用信息
 */
async function analyzeUrlContent(content: string, customPrompt?: string): Promise<{analysis: any, usingProxy: boolean, proxyMode: string}> {
  console.log('🤖 使用Gemini直接API调用分析URL内容...');
  console.log('📝 内容长度:', content.length);
  console.log('📋 自定义提示词:', !!customPrompt);
  
  // 限制内容长度，防止API调用失败
  const maxContentLength = 32000; // URL内容分析可以处理更长的内容
  let processedContent = content;
  
  if (content.length > maxContentLength) {
    console.log(`⚠️ 内容过长 (${content.length}字符)，截取前${maxContentLength}字符`);
    processedContent = content.substring(0, maxContentLength) + '...';
  }

  // 构建分析提示词
  let question: string;
  
  if (customPrompt && customPrompt.trim()) {
    // 使用自定义提示词
    console.log('🎯 使用自定义提示词进行分析');
    question = `${customPrompt.trim()}

Web content to analyze:
${processedContent}`;
  } else {
    // 使用默认的URL内容分析提示词
    console.log('📋 使用默认URL内容分析提示词');
    question = `You are a professional SEO analyst and content strategist. Please analyze the following web content and extract comprehensive brand, product, and business information.

Please perform a detailed analysis for:

1. **Brand Information**:
   - Brand name: Accurately identify the main brand name
   - Brand positioning: How the brand positions itself in the market
   - Brand values: Core values or mission statements mentioned

2. **Product/Service Analysis**:
   - Product list: Extract specific product or service names
   - Product categories: Categorize products/services by type
   - Product descriptions: Detailed descriptions for each product/service
   - Key features: Important features or benefits highlighted
   - Pricing information: Any pricing details mentioned

3. **Business Intelligence**:
   - Target audience: Who the content is aimed at
   - Industry/sector: What industry or market sector
   - Competitive advantages: Unique selling points mentioned
   - Business model: How the business operates (if evident)

4. **Content Assets**:
   - Product images: Most suitable product image URLs (complete HTTP/HTTPS URLs only)
   - Key messaging: Important marketing messages or slogans
   - Call-to-actions: Main CTAs or conversion points

5. **SEO/Marketing Insights**:
   - Primary keywords: Main keywords used in the content
   - Content themes: Major topics or themes covered
   - User intent: What user needs the content addresses

Note: Please respond in English only. Provide detailed and actionable insights.

Web content to analyze:
${processedContent}`;
  }

  // 使用配置中的原始模型名称
  const modelName = AI_MODEL || 'gemini-1.5-flash';
  console.log('🔑 使用模型:', modelName);
  console.log('📋 分析模式: URL内容深度分析');

  // URL内容分析专用的generationConfig
  const urlAnalysisConfig = {
    temperature: 0.3,
    topK: 20,
    topP: 0.95,
    maxOutputTokens: 65536,
    // 强制JSON输出配置 - 专门用于URL内容分析
    responseMimeType: "application/json",
    responseSchema: {
      type: "object",
      properties: {
        brand: {
          type: "object",
          properties: {
            name: { type: "string", description: "Brand name in English" },
            positioning: { type: "string", description: "Brand positioning statement" },
            values: { type: "array", items: { type: "string" }, description: "Brand values or mission" }
          },
          required: ["name", "positioning", "values"]
        },
        products: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string", description: "Product/service name" },
              category: { type: "string", description: "Product category" },
              description: { type: "string", description: "Product description" },
              features: { type: "array", items: { type: "string" }, description: "Key features" },
              pricing: { type: "string", description: "Pricing information if available" }
            },
            required: ["name", "category", "description", "features"]
          },
          description: "Product and service information"
        },
        business: {
          type: "object",
          properties: {
            targetAudience: { type: "string", description: "Primary target audience" },
            industry: { type: "string", description: "Industry or market sector" },
            advantages: { type: "array", items: { type: "string" }, description: "Competitive advantages" },
            businessModel: { type: "string", description: "Business model description" }
          },
          required: ["targetAudience", "industry", "advantages", "businessModel"]
        },
        assets: {
          type: "object",
          properties: {
            productImages: { 
              type: "array", 
              items: { type: "string" }, 
              description: "Product image URLs (complete HTTP/HTTPS URLs only)" 
            },
            keyMessages: { type: "array", items: { type: "string" }, description: "Marketing messages" },
            callToActions: { type: "array", items: { type: "string" }, description: "Main CTAs" }
          },
          required: ["productImages", "keyMessages", "callToActions"]
        },
        seoInsights: {
          type: "object",
          properties: {
            primaryKeywords: { type: "array", items: { type: "string" }, description: "Main keywords" },
            contentThemes: { type: "array", items: { type: "string" }, description: "Content themes" },
            userIntent: { type: "string", description: "Primary user intent" }
          },
          required: ["primaryKeywords", "contentThemes", "userIntent"]
        },
        summary: {
          type: "string",
          description: "Comprehensive summary of the analyzed content and business"
        }
      },
      required: ["brand", "products", "business", "assets", "seoInsights", "summary"]
    }
  };

  try {
    console.log('🚀 开始URL内容分析API调用...');
    
    const apiKey = getGENERATIVE_AI_KEY();
    const directResult = await callGeminiDirectly(apiKey, modelName, question, urlAnalysisConfig);
    
    if (directResult.success && directResult.data) {
      console.log('✅ URL内容分析API调用成功');
      console.log('📄 响应长度:', directResult.data.length);
      
      // 解析完整的分析结果
      const fullAnalysis = JSON.parse(directResult.data);
      
      // 确定代理模式
      const proxyMode = directResult.proxyUsed ? 'ClashX代理 - 直接API调用' : '无代理 - 直接连接';
      
      return { 
        analysis: fullAnalysis,
        usingProxy: !!directResult.proxyUsed, 
        proxyMode
      };
    } else {
      throw new Error(directResult.error || '直接API调用失败');
    }
  } catch (error) {
    console.error('❌ URL内容分析API调用失败:', error);
    throw error;
  }
}

/**
 * URL内容分析API路由
 */
export async function POST(request: NextRequest) {
  console.log('=== URL内容分析API请求开始 ===');
  
  try {
    const { content, customPrompt } = await request.json();

    if (!content) {
      throw new Error('缺少content参数');
    }

    const apiKey = getGENERATIVE_AI_KEY();
    if (!apiKey) {
      throw new Error('未配置Gemini API密钥');
    }

    console.log('✅ 收到URL内容分析请求');
    console.log('📝 内容长度:', content.length);
    console.log('🔑 API密钥已配置');

    // 分析URL内容
    const { analysis, usingProxy, proxyMode } = await analyzeUrlContent(content, customPrompt);
    
    console.log('✅ 成功完成URL内容分析');
    
    // 提取产品图片（选择第一个有效的图片URL）
    let productImage = null;
    
    console.log('🔍 开始分析产品图片...');
    console.log('📊 分析结果结构:', {
      hasAnalysis: !!analysis,
      hasAssets: !!(analysis?.assets),
      hasProductImages: !!(analysis?.assets?.productImages),
      productImagesLength: analysis?.assets?.productImages?.length || 0,
      productImagesArray: analysis?.assets?.productImages || []
    });
    
    if (analysis.assets && analysis.assets.productImages && analysis.assets.productImages.length > 0) {
      console.log('🖼️ 原始产品图片数组:', analysis.assets.productImages);
      
      // 过滤有效的HTTP/HTTPS URL
      const validImages = analysis.assets.productImages.filter((url: string) => {
        const isValid = url && typeof url === 'string' && url.trim() && 
                       (url.startsWith('http://') || url.startsWith('https://'));
        console.log(`🔍 检查图片URL: ${url} -> ${isValid ? '有效' : '无效'}`);
        return isValid;
      });
      
      console.log('✅ 有效图片URLs:', validImages);
      
      if (validImages.length > 0) {
        productImage = validImages[0];
        console.log('🎯 选择的产品图片:', productImage);
      } else {
        console.log('⚠️ 没有找到有效的HTTP/HTTPS图片URL');
      }
    } else {
      console.log('⚠️ 分析结果中没有productImages数组');
    }
    
    // 如果没有找到图片，尝试从其他可能的位置提取
    if (!productImage) {
      console.log('🔄 尝试备用图片提取方法...');
      
      // 尝试从整个分析结果中搜索可能的图片URL
      const analysisText = JSON.stringify(analysis);
      const imageUrlRegex = /https?:\/\/[^\s<>"']+\.(?:jpg|jpeg|png|webp|gif)(?:\?[^\s<>"']*)?/gi;
      const foundUrls = analysisText.match(imageUrlRegex) || [];
      
      console.log('🔍 在分析结果中发现的图片URLs:', foundUrls);
      
      if (foundUrls.length > 0) {
        productImage = foundUrls[0];
        console.log('🎯 使用备用方法找到的图片:', productImage);
      } else {
        console.log('❌ 未找到任何有效的产品图片');
      }
    }
    
    console.log('🖼️ 最终提取的产品图片:', productImage || '无');
    
    // 获取代理信息并返回成功响应
    const proxyConfig = getProxyConfig();
    const actualModel = AI_MODEL || 'gemini-1.5-flash';
    
    return NextResponse.json({ 
      analysis: analysis,
      productImage: productImage,
      method: 'Direct API - URL Content Analysis',
      model: actualModel,
      note: customPrompt ? '使用自定义提示词的URL内容分析API' : '使用专门的URL内容分析API成功完成深度分析',
      usingProxy,
      proxy: proxyConfig.proxy || null,
      proxyMode
    });

  } catch (error) {
    console.error('❌ URL内容分析过程中出错:', error);
    
    // 获取代理信息并返回错误响应
    const proxyConfig = getProxyConfig();
    const actualModel = AI_MODEL || 'gemini-1.5-flash';
    const errorMessage = error instanceof Error ? error.message : 'URL内容分析失败';
    
    return NextResponse.json(
      { 
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown',
        method: 'Direct API - URL Content Analysis (失败)',
        model: actualModel,
        usingProxy: proxyConfig.detected,
        proxy: proxyConfig.proxy || null,
        proxyMode: proxyConfig.detected ? 'ClashX检测到但API调用失败' : '无代理检测到'
      },
      { status: 500 }
    );
  } finally {
    console.log('=== URL内容分析API请求结束 ===');
  }
} 
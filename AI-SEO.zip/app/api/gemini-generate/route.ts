import { NextRequest, NextResponse } from 'next/server'
import { getGENERATIVE_AI_KEY, AI_MODEL } from '@/lib/config'
import { callGeminiDirectly } from '@/lib/gemini-direct-api'
import { recordAPIResult } from '@/lib/api-key-manager'

/**
 * 文章生成专用的Gemini API调用路由
 */
export async function POST(request: NextRequest) {
  console.log('=== 文章生成Gemini API请求开始 ===')
  
  try {
    const { prompt, generationConfig } = await request.json()

    if (!prompt) {
      throw new Error('缺少prompt参数')
    }

    const apiKey = getGENERATIVE_AI_KEY();
    if (!apiKey) {
      throw new Error('未配置Gemini API密钥')
    }

    console.log('✅ 收到文章生成Gemini请求')
    console.log('📝 提示词长度:', prompt.length)
    console.log('🔑 API密钥已配置')

    // 使用配置中的模型
    const modelName = AI_MODEL || 'gemini-2.0-flash-exp'
    console.log('🤖 使用模型:', modelName)

    // 默认生成配置
    const defaultConfig = {
      temperature: 0.7,
      topK: 20,
      topP: 0.95,
      maxOutputTokens: 8192,
      responseMimeType: "application/json"
    }

    // 使用传入的配置或默认配置
    const finalConfig = generationConfig || defaultConfig

    // 调用Gemini API
    const startTime = Date.now();
    const result = await callGeminiDirectly(apiKey, modelName, prompt, finalConfig)
    const responseTime = Date.now() - startTime;
    
    if (result.success) {
      console.log('✅ 文章生成Gemini API调用成功')
      console.log('📄 响应长度:', result.data.length)
      
      // 记录成功的API调用
      recordAPIResult(apiKey, true, responseTime);
      
      return NextResponse.json({ 
        success: true,
        data: result.data,
        model: modelName,
        usingProxy: !!result.proxyUsed,
        proxyMode: result.proxyUsed || '无代理'
      })
    } else {
      // 记录失败的API调用
      recordAPIResult(apiKey, false, responseTime, result.error);
      throw new Error(result.error || 'Gemini API调用失败')
    }

  } catch (error) {
    console.error('❌ 文章生成Gemini API调用失败:', error)
    
    const errorMessage = error instanceof Error ? error.message : '未知错误'
    
    return NextResponse.json(
      { 
        success: false,
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown'
      },
      { status: 500 }
    )
  } finally {
    console.log('=== 文章生成Gemini API请求结束 ===')
  }
} 
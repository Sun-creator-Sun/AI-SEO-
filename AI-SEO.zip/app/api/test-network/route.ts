import { NextRequest, NextResponse } from 'next/server'
import { proxiedFetch, NetworkError } from '@/lib/request-proxy'

interface TestNetworkRequest {
  url: string
  method?: string
}

/**
 * 网络测试API端点
 * 用于测试代理功能和网络连接
 */
export async function POST(request: NextRequest) {
  try {
    const { url, method = 'GET' }: TestNetworkRequest = await request.json()

    if (!url) {
      return NextResponse.json(
        { error: 'URL不能为空' },
        { status: 400 }
      )
    }

    // 验证URL格式
    try {
      new URL(url)
    } catch {
      return NextResponse.json(
        { error: 'URL格式无效' },
        { status: 400 }
      )
    }

    console.log(`INFO: Testing network connection to ${url}`)

    const response = await proxiedFetch(url, {
      method: method.toUpperCase(),
      headers: {
        'User-Agent': 'Vertu-SEO-Network-Test/1.0'
      }
    })

    const responseData = {
      success: true,
      url: url,
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
      timestamp: new Date().toISOString()
    }

    console.log(`SUCCESS: Network test completed for ${url}`)

    return NextResponse.json(responseData)

  } catch (error) {
    console.error('Network test failed:', error)

    // 处理网络错误，提供详细信息
    if (error instanceof NetworkError) {
      return NextResponse.json(
        { 
          success: false,
          error: error.message,
          errorType: 'NetworkError',
          attemptedMethods: error.attemptedMethods,
          userSuggestion: error.userSuggestion,
          networkDetails: error.toJSON()
        },
        { status: 500 }
      )
    }

    const errorMessage = error instanceof Error ? error.message : '未知错误'
    
    return NextResponse.json(
      { 
        success: false,
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown'
      },
      { status: 500 }
    )
  }
} 
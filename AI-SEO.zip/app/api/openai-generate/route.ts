import { NextRequest, NextResponse } from 'next/server'
import { proxiedFetch, NetworkError } from '@/lib/request-proxy'

/**
 * OpenAI API调用路由
 * 用于智能AI调度引擎的故障转移，支持代理自动切换
 */
export async function POST(request: NextRequest) {
  console.log('=== OpenAI API请求开始 ===')
  
  try {
    const { prompt, model = 'gpt-4o', generationConfig } = await request.json()

    if (!prompt) {
      throw new Error('缺少prompt参数')
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY
    if (!OPENAI_API_KEY) {
      throw new Error('未配置OpenAI API密钥')
    }

    console.log('✅ 收到OpenAI生成请求')
    console.log('📝 提示词长度:', prompt.length)
    console.log('🤖 使用模型:', model)

    // 构建OpenAI API请求
    const openaiPayload = {
      model: model,
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: generationConfig?.temperature || 0.7,
      max_tokens: generationConfig?.maxOutputTokens || 4096,
      top_p: generationConfig?.topP || 1,
      frequency_penalty: 0,
      presence_penalty: 0
    }

    const response = await proxiedFetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(openaiPayload),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`OpenAI API错误 ${response.status}: ${errorData.error?.message || response.statusText}`)
    }

    const result = await response.json()
    const generatedContent = result.choices?.[0]?.message?.content

    if (!generatedContent) {
      throw new Error('OpenAI API返回空内容')
    }

    console.log('✅ OpenAI API调用成功')
    console.log('📄 响应长度:', generatedContent.length)

    return NextResponse.json({
      success: true,
      data: generatedContent,
      model: model,
      usage: result.usage
    })

  } catch (error) {
    console.error('❌ OpenAI API调用失败:', error)
    
    // 处理网络错误，提供详细信息
    if (error instanceof NetworkError) {
      return NextResponse.json(
        { 
          success: false,
          error: error.message,
          errorType: 'NetworkError',
          attemptedMethods: error.attemptedMethods,
          userSuggestion: error.userSuggestion,
          networkDetails: error.toJSON()
        },
        { status: 500 }
      )
    }
    
    const errorMessage = error instanceof Error ? error.message : '未知错误'
    
    return NextResponse.json(
      { 
        success: false,
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown'
      },
      { status: 500 }
    )
  } finally {
    console.log('=== OpenAI API请求结束 ===')
  }
} 
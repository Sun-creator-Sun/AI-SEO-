// 设置该路由为动态路由
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { callApiWithProxyRetry, createNetworkDiagnosticError } from '@/lib/proxy-helper';

// Google API配置
const SEARCH_API_KEY = 'AIzaSyBBKCVGhg-H9eIgtbNGmMsghM2Sr1gHiwY';
const SEARCH_ENGINE_ID = 'b12e1712f42cb4eb3';

/**
 * 代理Google Custom Search API调用（支持VPN代理）
 * 这样可以避免浏览器的referrer限制
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const num = searchParams.get('num') || '10';
    const start = searchParams.get('start') || '1';
    const gl = searchParams.get('gl') || 'us';
    const lr = searchParams.get('lr') || 'lang_en';

    if (!query) {
      return NextResponse.json(
        { error: '缺少搜索查询参数' },
        { status: 400 }
      );
    }

    // 构建Google Custom Search API URL
    const searchUrl = new URL('https://www.googleapis.com/customsearch/v1');
    searchUrl.searchParams.append('key', SEARCH_API_KEY);
    searchUrl.searchParams.append('cx', SEARCH_ENGINE_ID);
    searchUrl.searchParams.append('q', query);
    searchUrl.searchParams.append('num', num);
    searchUrl.searchParams.append('start', start);
    searchUrl.searchParams.append('gl', gl);
    searchUrl.searchParams.append('lr', lr);

    console.log('代理调用Google Search API:', searchUrl.toString().replace(SEARCH_API_KEY, 'API_KEY_HIDDEN'));

    try {
      // 先尝试直连
      let response: Response;
      try {
        response = await fetch(searchUrl.toString(), {
          method: 'GET',
          headers: {
            'User-Agent': 'vertu-seo/1.0',
            'Accept': 'application/json',
          },
          signal: AbortSignal.timeout(30000), // 30秒超时
        });
      } catch (directError) {
        console.log('直连失败，尝试使用代理:', directError);
        
        // 如果直连失败，使用代理助手
        const proxyResponse = await callApiWithProxyRetry(
          searchUrl.toString(), 
          null, // GET请求无需请求体
          'Google Search API',
          'GET'
        );
        
        return NextResponse.json({
          ...proxyResponse.data,
          proxy: proxyResponse.proxy,
          note: `使用代理成功: ${proxyResponse.proxy}`
        });
      }

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Google Search API错误:', errorText);
        return NextResponse.json(
          { error: `Google Search API错误: ${response.status}` },
          { status: response.status }
        );
      }

      const data = await response.json();
      return NextResponse.json({
        ...data,
        proxy: '直连成功'
      });

    } catch (apiError) {
      console.error('搜索API调用失败:', apiError);
      const networkDiagnostic = createNetworkDiagnosticError(apiError, 'Google Search API');
      return NextResponse.json(networkDiagnostic, { status: 502 });
    }

  } catch (error) {
    console.error('代理API错误:', error);
    return NextResponse.json(
      { error: '内部服务器错误' },
      { status: 500 }
    );
  }
} 
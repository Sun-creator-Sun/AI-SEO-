import { NextRequest, NextResponse } from 'next/server';
import { createGenAI, AI_MODEL } from '@/lib/config';

/**
 * 调试相关性检查的API端点
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content, title, keyword } = body;
    
    if (!content || !title) {
      return NextResponse.json(
        { success: false, error: 'Missing content or title' },
        { status: 400 }
      );
    }
    
    const genAI = createGenAI();
    const model = genAI.getGenerativeModel({ model: AI_MODEL });
    
    const prompt = `
请分析以下内容与标题的相关性：

**目标标题：** ${title}
${keyword ? `**关键词：** ${keyword}` : ''}

**内容：**
${content}

请从以下维度分析相关性：

1. **主题相关性**：内容主题与标题主题的匹配度
2. **关键词匹配**：标题中的关键词在内容中的出现情况
3. **语义相关性**：内容与标题在语义层面的关联度
4. **内容质量**：内容的完整性、准确性和有用性

请用以下JSON格式回复：
{
  "overallRelevance": "高/中/低",
  "relevanceScore": 0-100,
  "themeMatch": "主题匹配度描述",
  "keywordMatch": "关键词匹配情况",
  "semanticRelevance": "语义相关性分析",
  "contentQuality": "内容质量评估",
  "recommendation": "建议（继续使用/需要调整/重新抓取）",
  "reasoning": "详细分析理由"
}
`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    try {
      const cleanedText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const analysis = JSON.parse(cleanedText);
      
      return NextResponse.json({
        success: true,
        data: {
          analysis,
          rawResponse: text,
          contentLength: content.length,
          titleLength: title.length
        }
      });
    } catch (parseError) {
      return NextResponse.json({
        success: false,
        error: 'Failed to parse AI response',
        rawResponse: text
      });
    }
    
  } catch (error) {
    console.error('Debug relevance check failed:', error);
    return NextResponse.json(
      { success: false, error: 'Debug relevance check failed' },
      { status: 500 }
    );
  }
} 
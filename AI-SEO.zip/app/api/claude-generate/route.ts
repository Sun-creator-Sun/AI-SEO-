import { NextRequest, NextResponse } from 'next/server'
import { proxiedFetch, NetworkError } from '@/lib/request-proxy'

/**
 * Claude API调用路由
 * 用于智能AI调度引擎的故障转移，支持代理自动切换
 */
export async function POST(request: NextRequest) {
  console.log('=== Claude API请求开始 ===')
  
  try {
    const { prompt, model = 'claude-3-sonnet-20240229', generationConfig } = await request.json()

    if (!prompt) {
      throw new Error('缺少prompt参数')
    }

    const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY || process.env.ANTHROPIC_API_KEY
    if (!CLAUDE_API_KEY) {
      throw new Error('未配置Claude API密钥')
    }

    console.log('✅ 收到Claude生成请求')
    console.log('📝 提示词长度:', prompt.length)
    console.log('🤖 使用模型:', model)

    // 构建Claude API请求
    const claudePayload = {
      model: model,
      max_tokens: generationConfig?.maxOutputTokens || 4096,
      temperature: generationConfig?.temperature || 0.7,
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ]
    }

    const response = await proxiedFetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': CLAUDE_API_KEY,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(claudePayload),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`Claude API错误 ${response.status}: ${errorData.error?.message || response.statusText}`)
    }

    const result = await response.json()
    const generatedContent = result.content?.[0]?.text

    if (!generatedContent) {
      throw new Error('Claude API返回空内容')
    }

    console.log('✅ Claude API调用成功')
    console.log('📄 响应长度:', generatedContent.length)

    return NextResponse.json({
      success: true,
      data: generatedContent,
      model: model,
      usage: result.usage
    })

  } catch (error) {
    console.error('❌ Claude API调用失败:', error)
    
    // 处理网络错误，提供详细信息
    if (error instanceof NetworkError) {
      return NextResponse.json(
        { 
          success: false,
          error: error.message,
          errorType: 'NetworkError',
          attemptedMethods: error.attemptedMethods,
          userSuggestion: error.userSuggestion,
          networkDetails: error.toJSON()
        },
        { status: 500 }
      )
    }
    
    const errorMessage = error instanceof Error ? error.message : '未知错误'
    
    return NextResponse.json(
      { 
        success: false,
        error: errorMessage,
        errorType: error?.constructor?.name || 'Unknown'
      },
      { status: 500 }
    )
  } finally {
    console.log('=== Claude API请求结束 ===')
  }
} 
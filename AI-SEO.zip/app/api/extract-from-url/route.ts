import { NextRequest, NextResponse } from 'next/server'
import { proxiedFetch, NetworkError } from '@/lib/request-proxy'

interface ExtractFromUrlRequest {
  url: string
}

interface ExtractFromUrlResponse {
  success: boolean
  content?: string
  title?: string
  url: string
  error?: string
}

/**
 * 使用Jina API从URL提取文本内容
 * @param url 要分析的URL
 * @returns 网页的文本内容
 */
async function fetchUrlContent(url: string): Promise<{ content: string; title?: string }> {
  try {
    // 使用Jina Reader API
    const jinaUrl = `https://r.jina.ai/${url}`;
    const response = await proxiedFetch(jinaUrl, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer jina_5025f50722184017999eac2ce6f27831CuBCqqtl7tX8oKYECPZr7ueNHUSd',
        'X-Return-Format': 'text',
        'X-Target-Selector': 'article, main, .content, #content, .post, .entry-content, .article-content'
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch content: HTTP ${response.status}`);
    }

    const content = await response.text();
    
    // 从内容中提取标题（通常在开头）
    const lines = content.split('\n').filter(line => line.trim());
    const title = lines.length > 0 ? lines[0].trim() : undefined;

    return { content, title };
  } catch (error) {
    console.error('Jina API error:', error);
    throw error;
  }
}

/**
 * 清理和优化提取的文本内容
 * @param content 原始文本内容
 * @returns 清理后的文本内容
 */
function cleanContent(content: string): string {
  return content
    // 移除多余的空行
    .replace(/\n\s*\n\s*\n/g, '\n\n')
    // 移除导航相关的文本
    .replace(/^(Home|Navigation|Menu|Search|Login|Sign Up|Subscribe).*$/gm, '')
    // 移除社交媒体相关的文本
    .replace(/^(Follow us|Share|Tweet|Like|Facebook|Twitter|Instagram).*$/gm, '')
    // 移除页脚相关的文本
    .replace(/^(Copyright|© \d{4}|Privacy Policy|Terms of Service|Contact Us).*$/gm, '')
    // 移除广告相关的文本
    .replace(/^(Advertisement|Sponsored|Ad).*$/gm, '')
    // 移除过短的行（可能是无用内容）
    .split('\n')
    .filter(line => line.trim().length > 10)
    .join('\n')
    .trim();
}

/**
 * 从URL提取文本内容API端点
 */
export async function POST(request: NextRequest) {
  try {
    const { url }: ExtractFromUrlRequest = await request.json();

    if (!url) {
      return NextResponse.json(
        { 
          success: false,
          error: 'URL不能为空',
          url: ''
        } as ExtractFromUrlResponse,
        { status: 400 }
      );
    }

    // 验证URL格式
    try {
      new URL(url);
    } catch {
      return NextResponse.json(
        { 
          success: false,
          error: 'URL格式无效',
          url: url
        } as ExtractFromUrlResponse,
        { status: 400 }
      );
    }

    console.log(`INFO: Extracting content from URL: ${url}`);
    
    // 提取网页内容
    const { content, title } = await fetchUrlContent(url);
    
    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { 
          success: false,
          error: '无法从该URL提取到有效内容',
          url: url
        } as ExtractFromUrlResponse,
        { status: 400 }
      );
    }

    // 清理内容
    const cleanedContent = cleanContent(content);
    
    if (cleanedContent.length < 50) {
      return NextResponse.json(
        { 
          success: false,
          error: '提取的内容太少，可能不是有效的文章页面',
          url: url
        } as ExtractFromUrlResponse,
        { status: 400 }
      );
    }

    console.log(`SUCCESS: Extracted ${cleanedContent.length} characters from ${url}`);

    return NextResponse.json({
      success: true,
      content: cleanedContent,
      title: title,
      url: url
    } as ExtractFromUrlResponse);

  } catch (error) {
    console.error('Extract from URL error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: error instanceof Error ? error.message : '提取内容时发生未知错误',
        url: ''
      } as ExtractFromUrlResponse,
      { status: 500 }
    );
  }
} 
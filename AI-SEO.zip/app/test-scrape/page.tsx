'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';

interface ScrapeResult {
  url: string;
  content?: string;
  error?: string;
  retries?: number;
}

interface ScrapeResponse {
  success: boolean;
  results: ScrapeResult[];
  summary: {
    total: number;
    successful: number;
    failed: number;
  };
  recommendations?: string[];
}

export default function TestScrapePage() {
  const [urls, setUrls] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<ScrapeResponse | null>(null);
  const [error, setError] = useState<string>('');

  const handleScrape = async () => {
    if (!urls.trim()) {
      setError('请输入至少一个URL');
      return;
    }

    setIsLoading(true);
    setError('');
    setResults(null);

    try {
      const urlList = urls.split('\n').map(url => url.trim()).filter(url => url);
      
      const response = await fetch('/api/scrape', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          urls: urlList,
          maxConcurrency: 3
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '抓取失败');
      }

      setResults(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '未知错误');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (result: ScrapeResult) => {
    if (result.content) {
      return <Badge variant="default" className="bg-green-500">成功</Badge>;
    } else {
      return <Badge variant="destructive">失败</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">网页抓取测试</h1>
        <p className="text-gray-600">
          测试优化后的网页抓取功能，支持多种抓取策略
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 输入区域 */}
        <Card>
          <CardHeader>
            <CardTitle>输入URL</CardTitle>
            <CardDescription>
              每行一个URL，最多支持10个URL同时抓取
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="urls">URL列表</Label>
              <Textarea
                id="urls"
                placeholder="https://example.com&#10;https://example.org&#10;https://example.net"
                value={urls}
                onChange={(e) => setUrls(e.target.value)}
                rows={8}
                className="mt-2"
              />
            </div>
            
            <Button 
              onClick={handleScrape} 
              disabled={isLoading}
              className="w-full"
            >
              {isLoading ? '抓取中...' : '开始抓取'}
            </Button>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 结果区域 */}
        <Card>
          <CardHeader>
            <CardTitle>抓取结果</CardTitle>
            <CardDescription>
              显示每个URL的抓取状态和内容
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results ? (
              <div className="space-y-4">
                {/* 统计信息 */}
                <div className="flex gap-4 mb-4">
                  <Badge variant="outline">
                    总计: {results.summary.total}
                  </Badge>
                  <Badge variant="default" className="bg-green-500">
                    成功: {results.summary.successful}
                  </Badge>
                  <Badge variant="destructive">
                    失败: {results.summary.failed}
                  </Badge>
                </div>

                {/* 建议 */}
                {results.recommendations && results.recommendations.length > 0 && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                    <h4 className="font-medium text-yellow-800 mb-2">建议：</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      {results.recommendations.map((rec, index) => (
                        <li key={index}>• {rec}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* 详细结果 */}
                <div className="space-y-3">
                  {results.results.map((result, index) => (
                    <div key={index} className="border rounded-md p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700">
                          {result.url}
                        </span>
                        {getStatusBadge(result)}
                      </div>
                      
                      {result.content ? (
                        <div className="text-sm text-gray-600">
                          <p className="mb-2">
                            <strong>内容长度:</strong> {result.content.length} 字符
                            {result.retries !== undefined && result.retries > 0 && (
                              <span className="ml-2 text-orange-600">
                                (重试 {result.retries} 次)
                              </span>
                            )}
                          </p>
                          <details>
                            <summary className="cursor-pointer text-blue-600 hover:text-blue-800">
                              查看内容预览
                            </summary>
                            <div className="mt-2 p-2 bg-gray-50 rounded text-xs max-h-32 overflow-y-auto">
                              {result.content.substring(0, 500)}
                              {result.content.length > 500 && '...'}
                            </div>
                          </details>
                        </div>
                      ) : (
                        <div className="text-sm text-red-600">
                          <strong>错误:</strong> {result.error}
                          {result.retries !== undefined && result.retries > 0 && (
                            <span className="ml-2 text-orange-600">
                              (重试 {result.retries} 次)
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-8">
                {isLoading ? '正在抓取网页内容...' : '暂无抓取结果'}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 功能说明 */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>功能说明</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div>
              <h4 className="font-medium mb-1">抓取策略：</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                <li><strong>Jina.ai API:</strong> 主要抓取服务，支持高级功能</li>
                <li><strong>备用API:</strong> 使用免费服务作为备用方案</li>
                <li><strong>直接fetch:</strong> 直接访问网页作为最后尝试</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-1">优化特性：</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                <li>多种抓取策略自动切换</li>
                <li>智能错误处理和重试机制</li>
                <li>并发控制避免过载</li>
                <li>详细的错误诊断和建议</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 
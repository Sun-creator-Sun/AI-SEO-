'use client'

import { useEffect } from 'react'

export default function ArticleDraftError({ error, reset }: { error: Error & { digest?: string }, reset: () => void }) {
  useEffect(() => {
    // 可以上报错误到监控平台
    // console.error(error)
  }, [error])

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center bg-white rounded-lg shadow p-8">
      <div className="text-4xl mb-4">🤖</div>
      <h2 className="text-lg font-bold mb-2 text-gray-800">AI 内容生成失败</h2>
      <p className="text-gray-600 mb-4 text-center">很抱歉，生成文章草稿时发生错误。请检查您的网络连接或 API 密钥，然后重试。</p>
      <pre className="bg-gray-100 text-xs text-red-500 rounded p-2 mb-4 w-full overflow-x-auto max-h-32">
        {error?.message || '未知错误'}
      </pre>
      <button
        className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow"
        onClick={() => reset()}
      >
        重置当前步骤
      </button>
    </div>
  )
} 
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Toaster } from 'sonner'
import { ToastProvider } from '@/components/ui/toast'
import { QueryProvider } from '@/components/providers/QueryProvider'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Vertu SEO - 关键词驱动的智能博客创作',
  description: '使用AI技术分析关键词并生成高质量博客内容的SEO工具',
}

/**
 * 应用根布局组件
 * @param children - 子组件
 */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN">
      <body className={inter.className}>
        <QueryProvider>
          <ToastProvider>
            {children}
          </ToastProvider>
          <Toaster 
            position="top-right"
            richColors
            closeButton
            expand={true}
            duration={6000}
          />
        </QueryProvider>
      </body>
    </html>
  )
} 
"use client"

import { Button } from '@/components/ui/button'
import { Sparkles, Lightbulb, FileText, Settings } from 'lucide-react'
import { useAppState } from '@/hooks/useAppState'
import { useToast } from '@/components/ui/toast'
import AppLayout from '@/components/shared/AppLayout'
import { AppStep } from '@/components/shared/StepIndicator'
import KeywordInputPage from '@/components/pages/KeywordInputPage'
import SearchingPage from '@/components/pages/SearchingPage'
import BlogIdeasPage from '@/components/pages/BlogIdeasPage'
import { ArticleDraftStep } from '@/lib/content-generation'
import { motion, AnimatePresence } from 'framer-motion'
import { GlobalLoading } from '@/components/ui/global-loading'
import { useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { nanoid } from 'nanoid'
import { convertMarkdownToWordPressHTML, generateWordPressHTMLDocument } from '@/lib/html-converter'

// 懒加载的页面组件
import {
  LazyTitleGeneratingPage,
  LazyTitlesPage,
  LazyOutlineGeneratingPage,
  LazyOutlinePage,
  LazySettingsPage,
  LazyArticleGenerationProgress,
  LazyArticleDraftPage
} from '@/components/pages/lazy-pages'

/**
 * 主页面组件
 */
export default function HomePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const appState = useAppState()
  const { success, error } = useToast()

  // 处理首次访问（URL中没有sessionId）
  useEffect(() => {
    if (!searchParams.has('sessionId')) {
      const newSessionId = nanoid()
      // 使用 replace 而不是 push，这样用户的浏览器历史记录中不会有这个重定向步骤
      router.replace(`/?sessionId=${newSessionId}`)
    }
  }, [searchParams, router])

  // 如果还没有sessionId，显示加载状态
  if (!searchParams.has('sessionId')) {
    return (
      <div className="h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">正在初始化...</p>
        </div>
      </div>
    )
  }

  /**
   * 渲染当前步骤的内容
   */
  const renderCurrentStep = () => {
    switch (appState.currentStep) {
      case AppStep.INPUT:
        return (
          <KeywordInputPage
            keyword={appState.keyword}
            setKeyword={appState.setKeyword}
            targetMarket={appState.targetMarket}
            setTargetMarket={appState.setTargetMarket}
            targetLanguage={appState.targetLanguage}
            setTargetLanguage={appState.setTargetLanguage}
            pageCount={appState.pageCount}
            setPageCount={appState.setPageCount}
            timeRange={appState.timeRange}
            setTimeRange={appState.setTimeRange}
          />
        )

      case AppStep.SEARCHING:
        return <SearchingPage progress={appState.progress} pageCount={appState.pageCount} />

      case AppStep.IDEAS:
        return (
          <BlogIdeasPage
            keyword={appState.keyword}
            targetMarket={appState.targetMarket}
            targetLanguage={appState.targetLanguage}
            searchResults={appState.searchResults}
            blogIdeas={appState.blogIdeas}
            searchIntent={appState.searchIntent}
            customIdea={appState.customIdea}
            setCustomIdea={appState.setCustomIdea}
            selectedIdeaIndex={appState.selectedIdeaIndex}
            onIdeaSelect={appState.handleIdeaSelect}
            additionalInfo={appState.additionalInfo}
            setAdditionalInfo={appState.setAdditionalInfo}
            additionalRequirements={appState.additionalRequirements}
            setAdditionalRequirements={appState.setAdditionalRequirements}
            autoInsertLSI={appState.autoInsertLSI}
            setAutoInsertLSI={appState.setAutoInsertLSI}
            knowledgeSource={appState.knowledgeSource}
            setKnowledgeSource={appState.setKnowledgeSource}
            isLoading={appState.isLoading}
          />
        )

      case AppStep.TITLE_GENERATING:
        return (
          <LazyTitleGeneratingPage
            titleGenerationStep={appState.titleGenerationStep}
            titleGenerationProgress={appState.titleGenerationProgress}
          />
        )

      case AppStep.TITLES:
        return (
          <LazyTitlesPage
            keyword={appState.keyword}
            targetMarket={appState.targetMarket}
            targetLanguage={appState.targetLanguage}
            selectedIdeaIndex={appState.selectedIdeaIndex}
            blogIdeas={appState.blogIdeas}
            customIdea={appState.customIdea}
            extractedKnowledge={appState.extractedKnowledge}
            filteredBlogContent={appState.filteredBlogContent}
            generatedTitles={appState.generatedTitles}
            selectedTitleIndex={appState.selectedTitleIndex}
            setSelectedTitleIndex={appState.setSelectedTitleIndex}
            customTitle={appState.customTitle}
            setCustomTitle={appState.setCustomTitle}
            wordCount={appState.wordCount}
            setWordCount={appState.setWordCount}
            readabilityLevel={appState.readabilityLevel}
            setReadabilityLevel={appState.setReadabilityLevel}
            toneStyle={appState.toneStyle}
            setToneStyle={appState.setToneStyle}
            perspective={appState.perspective}
            setPerspective={appState.setPerspective}
            outlineRequirements={appState.outlineRequirements}
            setOutlineRequirements={appState.setOutlineRequirements}
          />
        )

      case AppStep.OUTLINE_GENERATING:
        return (
          <LazyOutlineGeneratingPage
            outlineGenerationStep={appState.outlineGenerationStep}
            outlineGenerationProgress={appState.outlineGenerationProgress}
            error={appState.outlineGenerationError}
            onRetry={appState.generateOutline}
          />
        )

      case AppStep.OUTLINE:
        return (
          <LazyOutlinePage
            keyword={appState.keyword}
            targetMarket={appState.targetMarket}
            targetLanguage={appState.targetLanguage}
            selectedTitle={
              appState.selectedTitleIndex !== null 
                ? appState.generatedTitles[appState.selectedTitleIndex].title 
                : appState.customTitle || ''
            }
            generatedOutline={appState.generatedOutline}
            articleAnalyses={appState.articleAnalyses}
            synthesisReport={appState.synthesisReport}
            extractedContents={appState.extractedContents}
            filteredBlogContent={appState.filteredBlogContent}
          />
        )

      case AppStep.SETTINGS:
        return (
          <LazySettingsPage
            keyword={appState.keyword}
            targetMarket={appState.targetMarket}
            targetLanguage={appState.targetLanguage}
            selectedTitle={
              appState.selectedTitleIndex !== null 
                ? appState.generatedTitles[appState.selectedTitleIndex].title 
                : appState.customTitle || ''
            }
            generatedOutline={appState.generatedOutline}
            filteredBlogContent={appState.filteredBlogContent}
            articleRequirements={appState.articleRequirements}
            setArticleRequirements={appState.setArticleRequirements}
            addFactsAndEvidence={appState.addFactsAndEvidence}
            setAddFactsAndEvidence={appState.setAddFactsAndEvidence}
            searchRegion={appState.searchRegion}
            setSearchRegion={appState.setSearchRegion}
            contentLanguage={appState.contentLanguage}
            setContentLanguage={appState.setContentLanguage}
            autoInsertInternalLinks={appState.autoInsertInternalLinks}
            setAutoInsertInternalLinks={appState.setAutoInsertInternalLinks}
            anchorTextAutomation={appState.anchorTextAutomation}
            setAnchorTextAutomation={appState.setAnchorTextAutomation}
            autoInsertExternalLinks={appState.autoInsertExternalLinks}
            setAutoInsertExternalLinks={appState.setAutoInsertExternalLinks}
            externalDomainWhitelist={appState.externalDomainWhitelist}
            setExternalDomainWhitelist={appState.setExternalDomainWhitelist}
            addBlogCoverImage={appState.addBlogCoverImage}
            setAddBlogCoverImage={appState.setAddBlogCoverImage}
            addImagesUnderH2={appState.addImagesUnderH2}
            setAddImagesUnderH2={appState.setAddImagesUnderH2}
            addKeyPoints={appState.addKeyPoints}
            setAddKeyPoints={appState.setAddKeyPoints}
            addFAQSection={appState.addFAQSection}
            setAddFAQSection={appState.setAddFAQSection}
            addMoreRecommendations={appState.addMoreRecommendations}
            setAddMoreRecommendations={appState.setAddMoreRecommendations}
            customLinks={appState.customLinks}
            setCustomLinks={appState.setCustomLinks}
            customAnchorLinks={appState.customAnchorLinks}
            setCustomAnchorLinks={appState.setCustomAnchorLinks}
            isGeneratingArticle={appState.isGeneratingArticle}
            articleGenerationStep={appState.articleGenerationStep}
            articleGenerationMessage={appState.articleGenerationMessage}
            generatedEvidence={appState.generatedEvidence}
          />
        )

      case AppStep.ARTICLE_GENERATING:
        return (
          <LazyArticleGenerationProgress
            articleGenerationStep={appState.articleGenerationStep}
            articleGenerationMessage={appState.articleGenerationMessage}
            generatedEvidence={appState.generatedEvidence}
          />
        )

      case AppStep.ARTICLE_DRAFT:
        return (
          <LazyArticleDraftPage
            keyword={appState.keyword}
            targetMarket={appState.targetMarket}
            targetLanguage={appState.targetLanguage}
            selectedTitle={
              appState.selectedTitleIndex !== null 
                ? appState.generatedTitles[appState.selectedTitleIndex].title 
                : appState.customTitle || ''
            }
            generatedOutline={appState.generatedOutline}
            generatedEvidence={appState.generatedEvidence}
            evidenceRequirements={appState.evidenceRequirements}
            currentStep={appState.articleDraftStep}
            stepMessage={appState.articleDraftMessage}
            generatedContent={appState.generatedContent}
            isGenerating={appState.isGeneratingContent}
            customAnchorLinks={appState.customAnchorLinks}
          />
        )

      default:
        return null
    }
  }

  /**
   * 渲染底部按钮
   */
  const renderBottomButtons = () => {
    switch (appState.currentStep) {
      case AppStep.INPUT:
        return (
          <div className="flex items-center space-x-4">
            <Button 
              onClick={appState.handleSearch}
              disabled={!appState.keyword.trim() || appState.isLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              生成创意
            </Button>
            {appState.canGoNext() && (
              <Button variant="outline" onClick={appState.handleNext}>
                下一步
              </Button>
            )}
          </div>
        )

      case AppStep.IDEAS:
        return (
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={appState.handleBack}>
              上一步
            </Button>
            <Button 
              onClick={appState.generateTitle}
              disabled={appState.selectedIdeaIndex === null && !appState.customIdea.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Lightbulb className="w-4 h-4 mr-2" />
              生成标题
            </Button>
            {appState.canGoNext() && (
              <Button variant="outline" onClick={appState.handleNext}>
                下一步
              </Button>
            )}
          </div>
        )

      case AppStep.TITLES:
        return (
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={appState.handleBack}>
              上一步
            </Button>
            <Button 
              onClick={appState.generateOutline}
              disabled={appState.selectedTitleIndex === null && !appState.customTitle.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <FileText className="w-4 h-4 mr-2" />
              生成大纲
            </Button>
            {appState.canGoNext() && (
              <Button variant="outline" onClick={appState.handleNext}>
                下一步
              </Button>
            )}
          </div>
        )

      case AppStep.OUTLINE:
        return (
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={appState.handleBack}>
              上一步
            </Button>
            <Button 
              onClick={appState.generateArticle}
              disabled={!appState.generatedOutline}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Settings className="w-4 h-4 mr-2" />
              优化设置
            </Button>
            {appState.canGoNext() && (
              <Button variant="outline" onClick={appState.handleNext}>
                下一步
              </Button>
            )}
          </div>
        )

      case AppStep.SETTINGS:
        return (
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={appState.handleBack}
              disabled={appState.isGeneratingArticle}
            >
              上一步
            </Button>

            <Button
              onClick={appState.generateArticleDraft}
              disabled={appState.isGeneratingArticle}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
            >
              {appState.isGeneratingArticle ? (
                <span className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>生成中...</span>
                </span>
              ) : (
                '生成文章草稿'
              )}
            </Button>
          </div>
        )

      case AppStep.ARTICLE_GENERATING:
        return null

      case AppStep.ARTICLE_DRAFT:
        return (
          <div className="flex items-center space-x-4">
            <Button
              onClick={async () => {
                // 复制Markdown格式内容到剪贴板
                if (appState.generatedContent) {
                  try {
                    await navigator.clipboard.writeText(appState.generatedContent)
                    success('复制成功', 'Markdown格式内容已复制到剪贴板')
                  } catch (err) {
                    console.error('复制失败:', err)
                    error('复制失败', '请手动复制文章内容')
                  }
                }
              }}
              disabled={!appState.generatedContent || appState.isGeneratingContent}
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
            >
              复制Markdown
            </Button>
            <Button
              onClick={async () => {
                // 复制WordPress HTML格式内容到剪贴板
                if (appState.generatedContent) {
                  try {
                    const selectedTitle = appState.selectedTitleIndex !== null 
                      ? appState.generatedTitles[appState.selectedTitleIndex].title 
                      : appState.customTitle || '未命名文章'
                    
                    const htmlContent = convertMarkdownToWordPressHTML(
                      appState.generatedContent, 
                      appState.customAnchorLinks
                    )
                    
                    await navigator.clipboard.writeText(htmlContent)
                    success('复制成功', 'WordPress HTML格式内容已复制到剪贴板')
                  } catch (err) {
                    console.error('复制失败:', err)
                    error('复制失败', '请手动复制文章内容')
                  }
                }
              }}
              disabled={!appState.generatedContent || appState.isGeneratingContent}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              复制全文
            </Button>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <>
      <AppLayout 
        currentStep={appState.currentStep}
        bottomButtons={renderBottomButtons()}
        onDirectGenerate={appState.generateArticleDirectly}
      >
        {renderCurrentStep()}
      </AppLayout>
      
      {/* 全局加载状态 */}
      <GlobalLoading
        isVisible={appState.isGeneratingArticle}
        message={appState.articleGenerationMessage}
        step={appState.articleGenerationStep}
        totalSteps={4}
      />
    </>
  )
} 
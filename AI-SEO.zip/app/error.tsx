'use client'

import { useEffect } from 'react'

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }, reset: () => void }) {
  useEffect(() => {
    // 可以上报错误到监控平台
    // console.error(error)
  }, [error])

  return (
    <html lang="zh-CN">
      <body className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="max-w-md w-full bg-white shadow-lg rounded-lg p-8 flex flex-col items-center">
          <div className="text-4xl mb-4">😢</div>
          <h2 className="text-xl font-bold mb-2 text-gray-800">出错了！</h2>
          <p className="text-gray-600 mb-4 text-center">很抱歉，应用发生了意外错误。请尝试刷新页面或稍后重试。</p>
          <pre className="bg-gray-100 text-xs text-red-500 rounded p-2 mb-4 w-full overflow-x-auto max-h-32">
            {error?.message || '未知错误'}
          </pre>
          <button
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow"
            onClick={() => reset()}
          >
            刷新重试
          </button>
        </div>
      </body>
    </html>
  )
} 